<?php
namespace Dual\Render;

use Seitenbau\Registry;
/**
 * Website
 *
 * @author       Heiko Schwarz <heiko.schwarz@seitenbau.com>
 * @copyright    Copyright &copy; 2010, Seitenbau GmbH
 * @package      Dual
 * @subpackage   Render
 */

class Website
{
  protected $data = array();
  protected $colors = null;

  public function setArray( $data )
  {
    $this->data = $data;
  }

  private function createColorValues( )
  {
    $this->colors = array( );
    if( isset($this->data['colorscheme']) )
    {
      // Bereits als Array vorhanden
      if( is_array($this->data['colorscheme']) )
      {
        $this->colors = $this->data['colorscheme'];
      }
      elseif( is_string($this->data['colorscheme']) )
      {
        try
        {
          // JSON decodieren und Array aufbereiten
          $colorscheme = \Zend_Json::decode($this->data['colorscheme']);
          foreach( $colorscheme as $colorId => $color )
          {
            $this->colors[$color['id']] = $color;
          }
        }
        catch( \Exception $e )
        {
          // Fehler
          Registry::getLogger()->log( __CLASS__
                                    , __METHOD__
                                    , 'Farbeschema konnte nicht erstellt werden: '.$e->errorMessage
                                    , \Zend_Log::WARN);
        }
      }
    }
  }
  
  public function get($attribute)
  {
    if( isset($this->data) && is_array($this->data)
        && isset($this->data[$attribute]) )
    {
      // Wert zurueckgeben
      return $this->data[$attribute];
    }
    
    // Nicht zum Zurueckgeben
    return;
  }

  /**
   * Farbe aus dem Farbschema der Website zurueckgeben
   * @param   string  $colorId    Id der gewuenschten Farbe
   * @access public
   */
  public function getColorById($colorId)
  {
    // evtl. Farb-Array erzeugen
    if( !isset($this->colors) && !is_array($this->colors) )
    {
      $this->createColorValues();
    }

    if( isset($this->colors) && is_array($this->colors)
        && isset($this->colors[$colorId])
      )
    {
      // Farbe zurueckgeben
      return $this->colors[$colorId]['value'];
    }

    // Nichts zum Zurueckgeben
    return;
  }
}