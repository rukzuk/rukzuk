<?php
/**
 * erzeugt alle notwendigen Konstanzen und Basis-Objekte
 *
 * @author      Heiko Schwarz <schwarz@seitenbau.com>
 * @date        02.07.2010
 * @copyright   Copyright &copy; 2010, Seitenbau GmbH
 */

/**
 * Grundlegende Definitionen
 */

// Zeitzone setzen
date_default_timezone_set('Europe/Berlin');

// Definition des Media Pfades
defined('IS_STATIC_SITE')
    || define('IS_STATIC_SITE', true );

// Umgebung definieren
defined('APPLICATION_ENV')
  || define('APPLICATION_ENV', 'live');
    

// Definition des Anwendungs Pfades
$docRoot = ( substr($_SERVER['DOCUMENT_ROOT'],-1,1) == DIRECTORY_SEPARATOR ? substr($_SERVER['DOCUMENT_ROOT'],0,-1) : $_SERVER['DOCUMENT_ROOT'] );
defined('DOCROOT_PATH')
    || define('DOCROOT_PATH', realpath($docRoot) );

// Definition des Anwendungs Pfades
defined('WEBSITE_PATH')
    || define('WEBSITE_PATH', realpath(dirname(__FILE__)) );

// Definition des Anwendungs Web-Pfades
$sCurWebRootPath = substr(WEBSITE_PATH, strlen(DOCROOT_PATH));
defined('WEBROOT_PATH')
    || define('WEBROOT_PATH', ($sCurWebRootPath == DIRECTORY_SEPARATOR ? '' : str_replace(DIRECTORY_SEPARATOR, '/',$sCurWebRootPath)) );

// Definition des Application Pfades
defined('APPLICATION_PATH')
  || define('APPLICATION_PATH', WEBSITE_PATH.DIRECTORY_SEPARATOR.'server'.DIRECTORY_SEPARATOR.'application' );

// Definition des Library Pfades
defined('LIBRARY_PATH')
    || define('LIBRARY_PATH', WEBSITE_PATH.DIRECTORY_SEPARATOR.'server'.DIRECTORY_SEPARATOR.'library' );

// Definition des Media Pfades
defined('MEDIA_PATH')
    || define('MEDIA_PATH', WEBSITE_PATH.DIRECTORY_SEPARATOR.'media' );

// Definition des Media-Cache Pfades
// In dieses Verzeichnis werden die geaenderten Bilder geschriebn
// d.H. dort muessen Schreibrechte vorhanden sein
defined('MEDIA_CACHE_PATH')
    || define('MEDIA_CACHE_PATH', WEBSITE_PATH.DIRECTORY_SEPARATOR.'media_cache' );

// Definition des Asset Web-Pfades
defined('ASSET_WEBPATH')
    || define('ASSET_WEBPATH', WEBROOT_PATH.'/assets' );

// Aufbau des include_path
set_include_path(implode(PATH_SEPARATOR, array(
    realpath(LIBRARY_PATH),
    get_include_path(),
)));

/*
echo "DOCUMENTE_ROOT".$_SERVER['DOCUMENT_ROOT']."<br />";
echo "DOCROOT_PATH: ".DOCROOT_PATH."<br />";
echo "WEBSITE_PATH: ".WEBSITE_PATH."<br />";
echo "WEBROOT_PATH: ".WEBROOT_PATH."<br />";
echo "LIBRARY_PATH: ".LIBRARY_PATH."<br />";
echo "MEDIA_PATH: ".MEDIA_PATH."<br />";
echo "MEDIA_CACHE_PATH: ".MEDIA_CACHE_PATH."<br />";
echo "ASSET_WEBPATH: ".ASSET_WEBPATH."<br />";
echo "PHP_SELF: ".$_SERVER['PHP_SELF']."<br />";
*/


/**
 * Zend Klassen
 */
require_once(LIBRARY_PATH.'/Zend/Exception.php');
require_once(LIBRARY_PATH.'/Zend/Registry.php');
require_once(LIBRARY_PATH.'/Zend/Log/Writer/Stream.php');
require_once(LIBRARY_PATH.'/Zend/Log/Formatter/Simple.php');
require_once(LIBRARY_PATH.'/Zend/Log.php');
require_once(LIBRARY_PATH.'/Zend/Config/Ini.php');
require_once(LIBRARY_PATH.'/Zend/Config.php');
require_once(LIBRARY_PATH.'/Zend/Json.php');


/**
 * Seitenbau-Klassen
 */
require_once(LIBRARY_PATH.'/Seitenbau/Registry.php');
require_once(LIBRARY_PATH.'/Seitenbau/Log.php');
require_once(LIBRARY_PATH.'/Seitenbau/Logger.php');


/**
 * Render-Klassen
 */
require_once(LIBRARY_PATH.'/Dual/Media/Item.php');
require_once(LIBRARY_PATH.'/Dual/Media/Type.php');
require_once(LIBRARY_PATH.'/Dual/Render/RenderContext.php');
require_once(LIBRARY_PATH.'/Dual/Render/BaseList.php');
require_once(LIBRARY_PATH.'/Dual/Render/RenderList.php');
require_once(LIBRARY_PATH.'/Dual/Render/RenderObject.php');
require_once(LIBRARY_PATH.'/Dual/Render/RenderModule.php');
require_once(LIBRARY_PATH.'/Dual/Render/MediaManager.php');
require_once(LIBRARY_PATH.'/Dual/Render/MediaDb.php');
require_once(LIBRARY_PATH.'/Dual/Render/PluginManager.php');
require_once(LIBRARY_PATH.'/Dual/Render/Website.php');
require_once(LIBRARY_PATH.'/Dual/Render/Webpage.php');
require_once(LIBRARY_PATH.'/Dual/Render/CurrentSite.php');
require_once(LIBRARY_PATH.'/Dual/Render/CurrentPage.php');
require_once(LIBRARY_PATH.'/Dual/Render/Navigation.php');



/**
 * Konfiguration auslesen
 */
$config = new Zend_Config_Ini(
  APPLICATION_PATH . '/configs/application.ini',
  APPLICATION_ENV
);
\Seitenbau\Registry::setConfig($config);


/**
 * Logger anlegen
 */
$logwriter = new \Zend_Log_Writer_Stream('php://stderr');
$logformatter = new \Zend_Log_Formatter_Simple($config->logging->format.PHP_EOL);
$logwriter->setFormatter($logformatter);
$logger = new \Seitenbau\Logger(new Zend_Log($logwriter));
$logger->setLevel((int) $config->logging->level);
\Seitenbau\Registry::setLogger($logger);


/**
 * Context erstellen
 */
$renderContext = new \Dual\Render\RenderContext();
$renderContext->setStatic();
$renderContext->setRenderMode( \Dual\Render\RenderContext::MODE_SHOW );


/**
 * Dem Mediamanager mitteilen das wir Statisch sind
 */
require('media/mediaItems.php');
\Dual\Render\MediaManager::setContext($renderContext);
\Dual\Render\MediaManager::setMediaList($mediaItems);
\Dual\Render\MediaManager::setStatic();
