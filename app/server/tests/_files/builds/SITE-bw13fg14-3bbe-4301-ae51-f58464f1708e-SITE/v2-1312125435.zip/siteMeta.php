<?php
/*
 * Site Meta
 *  Site: SITE-bw01fg14-3bbe-4301-ae51-f58464f1708e-SITE
 */

$siteMeta = 
array (
  'id' => 'SITE-bw01fg14-3bbe-4301-ae51-f58464f1708e-SITE',
  'name' => 'Website_Build_1',
  'description' => '',
  'colorscheme' => NULL,
);
