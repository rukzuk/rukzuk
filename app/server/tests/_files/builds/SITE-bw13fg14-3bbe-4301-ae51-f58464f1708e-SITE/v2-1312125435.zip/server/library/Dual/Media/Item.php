<?php
namespace Dual\Media;

use Seitenbau\Registry as Registry,
    Seitenbau\Log as Log;

/**
 * Image
 *
 * @author       Raphael Stolt <raphael.stolt@seitenbau.com>
 * @copyright    Copyright (c) 2011, Seitenbau GmbH
 * @package      Application
 * @subpackage   Controller
 */
class Item
{
  private $cacheDirectory;
  private $mediaDirectory;
  private $fileTypesIconDirectory;

  private $imageTypes = array();
  private $multimediaTypes = array();
  private $downloadTypes = array();

  public function __construct()
  {
    $config = Registry::getConfig();
    $this->cacheDirectory = $config->media->cache->directory;
    if (!is_dir($this->cacheDirectory)) {
      mkdir($this->cacheDirectory);
    }
    $this->mediaDirectory = $config->media->files->directory;
    if (!is_dir($this->mediaDirectory)) {
      mkdir($this->mediaDirectory);
    }
    $this->fileTypesIconDirectory = $config->file->types->icon->directory;

    $this->imageTypes = explode(',', $config->file->types->image);
    $this->multimediaTypes = explode(',', $config->file->types->multimedia);
    $this->downloadTypes = explode(',', $config->file->types->download);
  }
  /**
   * @param  string $filename
   * @return string
   */
  private function getExtensionFromFilename($filename)
  {
    return substr(strrchr(strtolower($filename), '.'), 1);
  }
  /**
   * @param  string  $filename
   * @param  string  $websiteId
   * @param  boolean $nameOnly
   * @return string
   */
  public function getIconFile($filename, $websiteId = null, $nameOnly = false)
  {
    $iconPath = null;
    $fileExtension = $this->getExtensionFromFilename($filename);

    switch ($fileExtension) {
      case in_array($fileExtension, $this->imageTypes):
        $iconPath = $filename;
        if (!$nameOnly) {
          if ($websiteId !== null) {
            $iconPath = $this->mediaDirectory . DIRECTORY_SEPARATOR
              . $websiteId . DIRECTORY_SEPARATOR . $filename;
          } else {
            $iconPath = $this->mediaDirectory . DIRECTORY_SEPARATOR . $filename;
          }
        }
        break;
      default:
        if (!empty($fileExtension) &&
            file_exists($this->fileTypesIconDirectory . DIRECTORY_SEPARATOR . 'icon_' . $fileExtension . '.png'))
        {
          $iconPath = 'icon_' . $fileExtension . '.png';
        } else {
          // Pdf ist Default-Icon
          $iconPath = 'icon_pdf.png';
        }
        if (!$nameOnly) {
          $iconPath = $this->fileTypesIconDirectory . DIRECTORY_SEPARATOR . $iconPath;
        }
        break;
    }
    return $iconPath;
  }

  /**
   * @param  string  $websiteId
   * @param  string  $id
   * @param  string  $filename
   * @param  integer $width
   * @param  integer $height
   * @param  integer $maxWidth
   * @param  integer $maxHeight
   * @param  boolean $icon
   * @return string
   */
  public function getImageUrl($websiteId, $id, $filename, $width = 0, $height = 0,
    $maxWidth = 0, $maxHeight = 0, $icon = false)
  {
    return $this->createImageUrl($this->getUrl($websiteId, $id, $filename, $icon), $width, $height,
      $maxWidth, $maxHeight);
  }
  /**
   *
   * @param string  $streamUrl
   * @param integer $width
   * @param integer $height
   * @param integer $maxWidth
   * @param integer $maxHeight
   * @return string
   */
  private function createImageUrl($streamUrl, $width = 0, $height = 0,
    $maxWidth = 0, $maxHeight = 0)
  {
    $requestData = array();
    $orginalStreamUrl = $streamUrl;
    
    if (!empty($streamUrl)) {
      if (intval($width) > 0) {
        $streamUrl .= '&width='.intval($width);
        $requestData[] = '"width":"' . intval($width) .'"';
      }
      if (intval($height) > 0) {
        $streamUrl .= '&height='.intval($height);
        $requestData[] = '"height":"' . intval($height) .'"';
      }
      if (intval($maxWidth) > 0) {
        $streamUrl .= '&maxwidth='.intval($maxWidth);
        $requestData[] = '"maxwidth":"' . intval($maxWidth) .'"';
      }
      if(intval($maxHeight) > 0) {
        $streamUrl .= '&maxheight='.intval($maxHeight);
        $requestData[] = '"maxheight":"' . intval($maxHeight) .'"';
      }
    }
    if (count($requestData) > 0 && APPLICATION_ENV !== 'live') {
      $additionalData = implode(',', $requestData);
      return str_replace('%7D', urlencode(',' . $additionalData).'%7D', $orginalStreamUrl);
    }
    return $streamUrl;
  }
  /**
   * @param string $websiteId
   * @param string $id
   * @param string $filename
   * @param string $icon
   * @return string
   */
  public function getUrl($websiteId, $id, $filename, $icon = false, $type = null)
  {
    $requestData = array();
    if (APPLICATION_ENV !== 'live') {
      $mediaUrl = sprintf(
        Registry::getConfig()->server->url . '/cdn/get/%s/',
        \Cms\Request\Base::REQUEST_PARAMETER
      );
      $requestData[] = sprintf(
        '"websiteId":"%s"',
        $websiteId
      );
    } else {
      $mediaUrl = Registry::getConfig()->media->streamer->url . '?';
      //$mediaUrl.= sprintf('websiteId=%s&', urlencode($websiteId));
    }

    $orginalMediaUrl = $mediaUrl;

    // Icon oder Medium selbst?
    if ($icon) {
      // Icon ausgeben
      $mediaUrl .= 'icon=';
      $requestData[] = '"type":"icon"';
    } else {
      $fileExtension = $this->getExtensionFromFilename($filename);

      if( !isset($type) )
      {
        if( in_array($fileExtension, $this->imageTypes) ) {
          $type = 'image';
        }
        if( in_array($fileExtension, $this->downloadTypes) ) {
          $type = 'download';
        }
        if( in_array($fileExtension, $this->multimediaTypes) ) {
          $type = 'stream';
        }
      }

      // Je nach Typ Endpoint ermitteln
      switch ($type) {
        case 'image':
          $mediaUrl.= 'image=';
          $requestData[] = '"type":"image"';
          break;
        case 'download':
          $mediaUrl.= 'download=';
          $requestData[] = '"type":"download"';
          break;
        case 'stream':
        default:
          $mediaUrl.= 'stream=';
          $requestData[] = '"type":"stream"';
          break;
      }
    }
    
    if (APPLICATION_ENV !== 'live') {
      $requestData[] = '"id":"' . urlencode($id) . '"';
      $requestDataPart = "{" . implode(',', $requestData) . "}";
      return $orginalMediaUrl . urlencode($requestDataPart);
    }
    return $mediaUrl . urlencode($id);
  }
  /**
   * @param string  $filename
   * @param integer $newWidth
   * @param integer $newHeight
   * @param integer $newMaxWidth
   * @param integer $newMaxHeight
   * @param boolean $icon
   * @return string
   */
  public function resize($websiteId, $filename, $newWidth = 0, $newHeight = 0,
    $newMaxWidth = 0, $newMaxHeight = 0, $icon = false)
  {
    $newWidth = intval($newWidth);
    $newHeight = intval($newHeight);
    $newMaxWidth = intval($newMaxWidth);
    $newMaxHeight = intval($newMaxHeight);

    // Orginal-Datei oder Icon
    if ($icon) {
      // Icon bzw. Thumbnail
      $streamFile = $this->getIconFile($filename, $websiteId);
      $streamFilename = $this->getIconFile($filename, $websiteId, true);
    } else {
      // Orginal-Datei
      if ($websiteId !== null) {
        $streamFile = $this->mediaDirectory . DIRECTORY_SEPARATOR
          . $websiteId . DIRECTORY_SEPARATOR . $filename;
      } else {
        $streamFile = $this->mediaDirectory . DIRECTORY_SEPARATOR . $filename;
      }
      $streamFilename = $filename;
    }

    if (file_exists($streamFile)) {
      // Bei Bildern evtl. resizen
      if (in_array($this->getExtensionFromFilename($filename), $this->imageTypes) || $icon) {
        if ($websiteId !== null) {
          $currentCacheDirectory  = $this->cacheDirectory .
                  DIRECTORY_SEPARATOR . $websiteId;
        } else {
          $currentCacheDirectory  = $this->cacheDirectory;
        }
        if (!is_dir($currentCacheDirectory)) {
          mkdir($currentCacheDirectory);
        }
        if (!empty($newWidth) || !empty($newHeight) ||
            !empty($newMaxWidth) || !empty($newMaxHeight)) {
          // Neuer Dateinamen fuer diese Bildgroesse erstellen
          if (!empty($newMaxWidth) || !empty($newMaxHeight)) {
            // Maximal Hoehe und Breite
            $cacheFile = $currentCacheDirectory . DIRECTORY_SEPARATOR
              . str_replace('.', '_m' . $newMaxWidth . '_m' . $newMaxHeight . '.', $streamFilename);
          } else {
            // Hoehe und Breite
            $cacheFile = $currentCacheDirectory . DIRECTORY_SEPARATOR
              . str_replace('.', '_' . $newWidth . '_' . $newHeight . '.', $streamFilename );
          }
          // Ist bereits ein Bild in dieser Groeße vorhanden?
          if (file_exists($cacheFile)) {
            // Ist das erzeugte Bild neuer als das Orginalbild
            $orgTime = @filemtime($streamFile);
            $cacheTime = @filemtime($cacheFile);
            if (!empty($orgTime) && !empty($cacheTime) && $orgTime < $cacheTime) {
              // Cache-Bild ist aktuell -> Cachebild-Pfad zurueckgeben
              return $cacheFile;
            }
          }

          // Bilddaten ermitteln
          if (function_exists('exif_imagetype'))
          {
            $imageType = exif_imagetype($streamFile);
          }
          else
          {
            $imageInfo = getimagesize($streamFile);
            $imageType = $imageInfo[2];
          }
          $saveFunction = false;
          switch ($imageType) {
            case IMAGETYPE_GIF:
              if (imagetypes() & IMG_GIF && function_exists('imagecreatefromgif')) {
                // GIF oeffnen
                $image = imagecreatefromgif($streamFile) ;
                $saveFunction = 'imagegif';
              }
              break;
            case IMAGETYPE_JPEG:
              if (imagetypes() & IMG_JPG && function_exists('imagecreatefromjpeg')) {
                // JPG oeffnen
                $image = imagecreatefromjpeg($streamFile) ;
                $saveFunction = 'imagejpeg';
              }
              break;
            case IMAGETYPE_PNG:
                if (imagetypes() & IMG_PNG && function_exists('imagecreatefrompng')) {
                  // PNG oeffnen
                  $image = imagecreatefrompng($streamFile) ;
                  $saveFunction = 'imagepng';
                }
                break;
            case IMAGETYPE_WBMP:
                if (imagetypes() & IMG_WBMP && function_exists('imagecreatefromwbmp')) {
                  // WBMP oeffnen
                  $image = imagecreatefromwbmp($streamFile) ;
                  $saveFunction = 'imagewbmp';
                }
                break;
            default:
                // Fehler! Bild-Type nicht unterstuetzt
                $saveFunction = false;
                break;
          }

          // Resamplen?
          if (!empty($saveFunction) && $image && function_exists($saveFunction)) {
            // neues Bild anlegen
            if (function_exists("imagecreatetruecolor") &&
               function_exists("imagecopyresampled")) {
              // Breite und Hoehe ermiteln
              $curWidth   = imagesx($image);
              $curHeight  = imagesy($image);

              // Maximale Breite oder Hoehe beachten?
              if (($newWidth == 0 && $newHeight == 0 )
                  &&
                  ( $newMaxWidth > 0 || $newMaxHeight > 0 )
                )
              {
                // Je nachdem was angegeben ist
                if( $newMaxHeight == 0 )
                {
                  // Nur Breite beachten
                  $newWidth   = $newMaxWidth;
                  $newHeight  = 0;
                }
                elseif( $newMaxWidth == 0 )
                {
                  // Nur Hoehe beachten
                  $newWidth   = 0;
                  $newHeight  = $newMaxHeight;
                }
                else
                {
                  // Verhaeltnisse ermitteln
                  $curProportion = $curHeight/$curWidth;
                  $newProportion = $newMaxHeight/$newMaxWidth;

                  // Gleiches Verhaeltnis oder Breiter
                  if( $curProportion == $newProportion || $newProportion > $curProportion )
                  {
                    // Breite verwenden
                    $newWidth   = $newMaxWidth;
                    $newHeight  = 0;
                  }
                  else
                  {
                    // Sonst -> Hoehe verwenden
                    $newWidth   = 0;
                    $newHeight  = $newMaxHeight;
                  }
                }

                // Nur Verkleinern nicht vergroessern
                if( ( $newWidth > 0 && $newWidth >= $curWidth )
                    ||
                    ( $newHeight > 0 && $newHeight >= $curHeight )
                  )
                {
                  // Nicht veraender
                  $newWidth  = 0;
                  $newHeight = 0;
                }
              }

                // Muss das Bild veraendert werden
              if( ($newWidth > 0 && $curWidth != $newWidth )
                  ||
                  ($newHeight > 0 && $curHeight != $newHeight)
                )
              {
                if( $newWidth <= 0 )
                {
                  $newWidth = intVal($curWidth / ($curHeight / $newHeight) );
                }
                if( $newHeight <= 0 )
                {
                  $newHeight = intVal($curHeight / ($curWidth / $newWidth) );
                }

                // Min und Max ueberpruefen
                $newWidth   = ( $newWidth <= 0 ? 1 : $newWidth );
                $newHeight  = ( $newHeight <= 0 ? 1 : $newHeight );

                // Neues Bild erzeugen
                $newImage = imagecreatetruecolor($newWidth, $newHeight);
                if ($newImage)
                {
                  // Transparenz uebernehmen
                  imagealphablending($newImage,true);
                  $transparencyIndex = imagecolortransparent($image);
                  if ($transparencyIndex >= 0
                      && $transparencyIndex < imagecolorstotal($image))
                  {
                    imagepalettecopy($image, $newImage);
                    imagefilledrectangle($newImage, 0, 0, $newWidth, $newHeight, $transparencyIndex);
                    imagecolortransparent($newImage, $transparencyIndex);
                    imagetruecolortopalette($newImage, true, 256);
                  }
                  // Transparenz fuer png oder gif uebernehmen
                  elseif ($imageType == IMAGETYPE_PNG
                          || $imageType == IMAGETYPE_GIF)
                  {
                    imagealphablending($newImage, false);
                    imagesavealpha($newImage, true);
                    $transparencyIndex = imagecolorallocatealpha($newImage, 255, 255, 255, 127);
                    //imagefill($newImage, 0, 0, $transparencyIndex);
                    imagefilledrectangle($newImage, 0, 0, $newWidth, $newHeight, $transparencyIndex);
                  }

                  // Bild kopieren
                  if (imagecopyresampled($newImage, $image, 0, 0, 0, 0, $newWidth, $newHeight, $curWidth, $curHeight))
                  {
                    // Bild wieder speichern
                    if (call_user_func($saveFunction, $newImage, $cacheFile)) {
                      // Neue Datei verwenden
                      $streamFile = $cacheFile;
                    }
                  }
                  // Cache-Bild aus dem Speicher loeschen
                  imagedestroy($newImage);
                }
              }
            }
            // OrginalBild aus dem Speicher loeschen
            imagedestroy($image);
          }
        }
      }
    }    
    return $streamFile;
  }
}