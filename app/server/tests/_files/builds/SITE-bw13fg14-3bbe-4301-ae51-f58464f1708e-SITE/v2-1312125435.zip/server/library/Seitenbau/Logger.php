<?php
namespace Seitenbau;

/**
 * Statische Wrapperklasse für Zend_Log
 *
 * @author       Raphael Stolt <raphael.stolt@seitenbau.com>
 * @copyright    Copyright (c) 2011, Seitenbau GmbH
 * @package      Seitenbau
 * @subpackage   Logger
 */
class Logger
{
   /**
    * Speichert ein Objekt der Klasse Zend_Log
    *
    * @var Zend_Log
    */
    private $logger = null;
   /**
    * @var integer
    */
    private $level = 0;

   /**
    * Konstruktor
    * @param Zend_Log $logger Objekt der Klasse Zend_Log
    */
    public function __construct(\Zend_Log $logger)
    {
      $this->logger = $logger;
    }

   /**
    * Schreibt einen Log-Eintrag
    *
    * @param string $method Funktions- oder Methodenname
    * @param int $line Zeilennummer
    * @param string $message Meldung
    * @param int $priority Level
    * @param string $logid ID des Logeintrag
    */
    public function log($method, $line, $message, $priority, $logid = '')
    {
      if ((int) $priority > (int) $this->level) {
        return;
      }
      $this->logger->setEventItem('method', $method);
      $this->logger->setEventItem('line', $line);
      $this->logger->setEventItem('logid', $logid);
      $this->logger->setEventItem('sessionId', session_id());
      $this->logger->log($message, $priority);
    }

   /**
    * Loggt eine Datenmenge (Array, assoziatives Array, Objekt)
    *
    * @param string $method Funktion oder Methode
    * @param integer $line Zeilennummer
    * @param string $info Information/Meldung
    * @param mixed $data Datenmenge (Array/Objekt)
    * @param integer $priority Debug-Level
    * @param string $logid ID des Logeintrag
    */
    public function logData($method, $line, $info, $data, $priority, $logid = '')
    {
      if ((int) $priority > (int) $this->level) {
        return;
      }

      $this->log($method, $line, " >>> $info ", $priority, $logid);
      $convData = explode("\n", print_r($data, true));
      foreach ($convData as $dataLine) {
        if ('' === $dataLine) {
          continue;
        }
        $this->log('~', '~', $dataLine, $priority, $logid);
      }
      $this->log($method, $line, "<<< $info", $priority, $logid);
    }
   /**
    * Loggt eine Exception inkl. Stacktrace
    *
    * @param string $method Funktion/Methode
    * @param integer $line Zeilennummer
    * @param Exception $exc Exception
    * @param integer $priority Debug-Level
    */
    public function logException($method, $line, \Exception $exc, $priority, $logid = '')
    {
      if ((int) $priority > (int) $this->level) {
        return;
      }
      $excClass = get_class($exc);

      $message = $exc->getMessage();
      if (method_exists($exc, 'getData'))
      {
        $data = $exc->getData();
        if (is_array($data) && count($data) > 0)
        {
          $message = $this->replaceVars($message, $exc->getData());
        }
      }

      $this->log($method, $line, $excClass . ': ' . $message, $priority, $logid);
      $backtrace = explode("\n", $exc->getTraceAsString());
      $message = "$excClass backtrace";
      $this->logData($method, $line, $message, $backtrace, $priority, $logid);
    }
   /**
    * Setzt das Logger-Objekt
    *
    * @param Zend_Log $logger Objekt der Klasse Zend_Log
    */
    public function setLogger(\Zend_Log $logger)
    {
      $this->logger = $logger;
    }
   /**
    * Liefert das Logger-Objekt zurueck
    *
    * @return Zend_Log Objekt der Klasse Zend_Log
    */
    public function getLogger()
    {
      return $this->logger;
    }
   /**
    * Setzt das Logging-Level
    *
    * @param integer $level Logging Level
    */
    public function setLevel($level)
    {
      $this->level = $level;
    }
   /**
    * Liefert das Logging-Level zurueck
    *
    * @return integer
    */
    public function getLevel()
    {
      return $this->level;
    }

    protected function replaceVars($message, $data)
    {
      if (is_array($data) && count($data) > 0)
      {
        foreach ($data as $key => $value)
        {
          if (is_string($value))
          {
            $message = str_replace('{' . $key . '}', $value, $message);
          }
        }
      }
      return $message;
    }
}
