<?php
namespace Seitenbau;

use Doctrine\ORM\EntityManager as DoctrineEntityManager,
    \Zend_Locale as Locale;

/**
 * @author       Raphael Stolt <raphael.stolt@seitenbau.com>
 * @copyright    Copyright (c) 2011, Seitenbau GmbH
 * @package      Seitenbau
 * @subpackage   Registry
 */
class Registry extends \Zend_Registry
{
  /**
   * Speichert ein Logger-Objekt
   * @var Seitenbau\Logger
   */
  private static $logger;
  
  /**
   * Speichert ein ActionLogger-Objekt
   * @var Seitenbau\Logger\Action
   */
  private static $actionLogger;

  /**
   * Speichert ein Konfigurations-Objekt
   * @var Zend_Config
   */
  private static $config;

  /**
   * Speichert einen Doctrine2 Entity Manager
   * @var Doctrine\ORM\EntityManager
   */
  private static $entityManager;

  /**
   * Speichert eine Zend_Locale
   * @var Zend_Locale
   */
  private static $locale;
  /**
   * Speichert eine Pdo Instanz
   * @var Pdo
   */
  private static $pdo;
  /**
   * Speichert eine Zend_Db_Adapter_Pdo Instanz
   * @var Zend_Db_Adapter_Pdo
   */
  private static $dbAdapter;

  /**
   * Setzt das Logger-Objekt
   * @param Seitenbau\Logger $logger Das Logger Objekt
   */
  public static function setLogger(Logger $logger)
  {
    self::$logger = $logger;
  }

  /**
   * Gibt das Logger-Objekt zurueck
   * @return Seitenbau\Logger
   */
  public static function getLogger()
  {
    return self::$logger;
  }
  /**
   * Setzt das ActionLogger-Objekt
   * @param Seitenbau\Logger\Action $logger Das Logger Objekt
   */
  public static function setActionLogger($logger)
  {
    self::$actionLogger = $logger;
  }

  /**
   * Gibt das ActionLogger-Objekt zurueck
   * @return Seitenbau\Logger\Action
   */
  public static function getActionLogger()
  {
    return self::$actionLogger;
  }

  /**
   * Setzt das Konfigurations-Objekt
   * @param Zend_Config $config Konfigurations-Objekt
   */
  public static function setConfig(\Zend_Config $config)
  {
    self::$config = $config;
  }

  /**
   * Gibt das Konfigurations-Objekt zurueck
   * @return Zend_Config
   */
  public static function getConfig()
  {
    return self::$config;
  }
  /**
   * Setzt den Doctrine2 Entity Manager
   * @param Doctrine\ORM\EntityManager $manager
   */
  public static function setEntityManager(DoctrineEntityManager $manager)
  {
    self::$entityManager = $manager;
  }
  /**
   * Gibt das Konfigurations-Objekt zurueck.
   * @return Doctrine\ORM\EntityManager
   */
  public static function getEntityManager()
  {
    return self::$entityManager;
  }
  /**
   * Setzt den Zend_Locale
   * @param Zend\Locale $locale
   */
  public static function setLocale(Locale $locale)
  {
    self::$locale = $locale;
  }
  /**
   * Gibt die Zend_Locale zurueck
   * @return Zend\Locale
   */
  public static function getLocale()
  {
    return self::$locale;
  }
  /**
   * @param Pdo $pdo
   */
  public static function setTestPdo(\Pdo $pdo)
  {
    self::$pdo = $pdo;
  }
  /**
   * @return $pdo
   */
  public static function getTestPdo()
  {
    return self::$pdo;
  }
  /**
   * @param Zend_Db_Adapter_Pdo_Mysql $db
   */
  public static function setDbAdapter($adpater)
  {
    self::$dbAdapter = $adpater;
  }
  /**
   * @return Zend_Db_Adapter_Pdo_Mysql
   */
  public static function getDbAdapter()
  {
    return self::$dbAdapter;
  }
}
