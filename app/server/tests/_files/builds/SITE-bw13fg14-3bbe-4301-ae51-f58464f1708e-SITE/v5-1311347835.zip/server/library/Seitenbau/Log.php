<?php
namespace Seitenbau;

/**
 * @author       Raphael Stolt <raphael.stolt@seitenbau.com>
 * @copyright    Copyright (c) 2011, Seitenbau GmbH
 * @package      Seitenbau
 * @subpackage   Log
 */
class Log extends \Zend_Log {}