<?php
namespace Dual\Render;

/**
 * RenderModule
 *
 * @author       Heiko Schwarz <schwarz@seitenbau.com>
 * @copyright    Copyright (c) 2011, Seitenbau GmbH
 * @package      Dual
 * @subpackage   Render
 */

class RenderModule extends RenderObject
{

  public function html( )
  {
    $sCode = $this->getRendererCode();

    // Module Rendern
    if( !empty($sCode) && trim($sCode) != '' )
    {
      $self =& $this;
      eval('namespace Dual\Render; ?>'.$sCode);
    }
  }

  public function head( )
  {
    // Wurde der Code dieses Modules bereits Ausgegeben
    if( !$this->checkRenderHeadState() )
    {
      $sCode = $this->getHeadCode();

      // Module Rendern
      if( !empty($sCode) && trim($sCode) != '' )
      {
        $self =& $this;
        eval('namespace Dual\Render; ?>'.$sCode);
      }
      
      // Head des Modul als gerender aufnehmen
      $this->addRenderHeadState();
    }

    // Auch den Head der Kindelemente rendern
    $this->renderChilds(self::RENDER_TYPE_HEAD);
  }

  public function css( &$css )
  {
    $sCode = $this->getCssCode();

    // CSS-Code ermitteln / Rendern
    $curCss = '';
    if( !empty($sCode) && trim($sCode) != '' )
    {
      ob_start();
      $self =& $this;
      eval('namespace Dual\Render; ?>'.$sCode);
      $curCss = ob_get_contents();
      ob_end_clean();
      if( $this->getMode() == RenderContext::MODE_EDIT )
      {
        $curCss  =  "\n/* {CSS-UNIT:".$this->getId()."} */\n" .
                    $curCss .
                    "\n/* {/CSS-UNIT:".$this->getId()."} */\n";
      }
    }
    
    // CSS-Code aufbereiten
    $this->runCssInterpreter( $curCss );
    
    // Aktuellen CSS-Code aufnehmen
    $css .= $curCss;

    // Auch den CSS der Kindelemente rendern
    $this->renderChildsCss( $css );
  }


}
