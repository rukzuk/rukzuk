<?php
namespace Dual\Render;

use Seitenbau\Registry;

/**
 * Render CurrentSite
 *
 * @author       Heiko Schwarz <schwarz@seitenbau.com>
 * @copyright    Copyright (c) 2011, Seitenbau GmbH
 * @package      Dual
 * @subpackage   Render
 */

class CurrentSite
{
  /**
   * Statische Variable mit der Instanz der aktuellen Website
   * @access private
   */
  private static $website = null;

  
  /**
   * Aktuelle Website ermitteln
   * @access public
   */
  public static function setSite( &$website )
  {
    // Website uebernehmen
    self::$website = $website;
  }

  /**
   * Attribute der aktuellen Website zurueckgeben
   * @param   string  $attribute    Name des Attributes welches zurueckgegeben werden soll
   * @access public
   */
  public static function get($attribute)
  {
    // Website-Instanz vorhanden?
    if( isset(self::$website) && is_object(self::$website) )
    {
      // Wert ermitteln und zurueckgeben
      return self::$website->get($attribute);
    }
    
    // Fehler -> Nichts zurueckgeben
    // (ToDo: Evtl. Dummy-Daten im Template-Modus zurueckgeben)
    return;
  }  

  /**
   * Farbe aus dem Farbschema der aktuellen Website zurueckgeben
   * @param   string  $colorId    Id der gewuenschten Farbe
   * @access public
   */
  public static function getColorById($colorId)
  {
    // Website-Instanz vorhanden?
    if( isset(self::$website) && self::$website instanceof \Dual\Render\Website )
    {
      // Farbe ermitteln und zurueckgeben
      return self::$website->getColorById($colorId);
    }

    // Fehler -> Nichts zurueckgeben
    return;
  }
}