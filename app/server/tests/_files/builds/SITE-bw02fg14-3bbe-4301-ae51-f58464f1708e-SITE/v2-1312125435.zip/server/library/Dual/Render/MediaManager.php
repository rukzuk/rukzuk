<?php
namespace Dual\Render;

use Seitenbau\Registry,
    Dual\Media\Item as MediaItem;
/**
 * Render MediaManager
 *
 * @author       Heiko Schwarz <schwarz@seitenbau.com>
 * @copyright    Copyright (c) 2011, Seitenbau GmbH
 * @package      Dual
 * @subpackage   Render
 */

class MediaManager
{
  /**
   * Flag Statische-Seite oder OnTheFly-Seite
   * @var boolean
   */
  private static $_static;

  /**
   * Statische Variable mit der Referenz auf das Renderer-Context-Objekt
   * @access private
   */
  private static $context = null;

  /**
   * Array mit den Daten der vorhandenen Medien
   *  (fuer die statische Versione)
   * @var array
   */
  private static $_mediaList = array();

  /**
   * Setzt das Statische-Seiten Flag
   */
  public static function setStatic()
  {
    self::$_static = true;
  }

  /**
   * Setzt das Statische-Seiten Flag zurueck auf "OnTheFly"-Seite
   */
  public static function resetStatic()
  {
    self::$_static = false;
  }

  /**
   * Liefert das Statische-Seiten Flag zurueck
   * @return boolean
   */
  public static function isStatic()
  {
    return self::$_static;
  }

  /**
   * Render-Context-Object setzen
   * @param   object  $context      Referenz auf das Context-Objekt
   * @access public
   */
  public static function setContext(&$context)
  {
    self::$context = $context;
  }
  
  /**
   * Setzt die Daten fuer die statische Version
   * @param array $mediaList    Lister der verfuegbaren Medien
   */
  public static function setMediaList($mediaList)
  {
    if( is_array($mediaList) )
    {
      self::$_mediaList = $mediaList;
    }
  }

  /**
   * Liefert ein MediaObjekt anhand der ID zurueck
   * wurde kein Eintrag gefunden wird null zurueck gegeben
   * 
   * @param string $id  ID des Mediums
   * @return  MediaItem|null
   */
  public static function findOneById($id)
  {
    // init
    $media = null;
    
    // ID uebergeben
    if( !empty($id) )
    {
      // Statische-Seite oder "OnTheFly"-Seite
      if( self::isStatic() )
      {
        // Medien-Infroamtion vorhanden
        if( isset(self::$_mediaList[$id]) && is_array(self::$_mediaList[$id]) )
        {
          // Statisches Medienobjekt anlegen und befuellen
          $media = self::$_mediaList[$id];
        }
      }
      else
      {
        try
        {
          // Medium ermitteln
          $media = Registry::getEntityManager()
                    ->getRepository('Orm\Media')
                    ->findOneBy(array(
                        'id' => $id,
                        'websiteid' => self::$context->getWebsiteId()
                    ));
        }
        catch( Doctrine_Record_Exception $e )
        {
          // Fehler
          throw $e;
        }
      }
    }

    // MedienObject zurueckgeben
    return $media;
  }

  /**
   * Ermittelt die URL eines Bildes
   * @param string $id  ID des Mediums
   * @param integer $width  Breite des Bildes
   * @param integer $height  Hoehe des Bildes
   */
  public static function getImageUrl( $id, $width=false, $height=false )
  {
    $imageUrl = '';

    // Id vorhanden
    if( !empty($id) )
    {
      try
      {
        // Medium ermitteln
        $media = MediaManager::findOneById( $id );

        // Medium gefunden?
        if( !isset($media) )
        {
          // Fehler
          Registry::getLogger()->log( __CLASS__
                                    , __METHOD__
                                    , 'Medium mit der id \''.$id.'\' nicht gefunden'
                                    , \Zend_Log::WARN);
        }
        else
        {
          // Item erstellen
          $item = new \Dual\Media\Item();

          // Statische-Seite oder "OnTheFly"-Seite
          if( self::isStatic() )
          {
            // URL ermitteln
            $imageUrl = $item->getImageUrl(
                    self::$context->getWebsiteId(),
                    $media['id'],
                    $media['filename'],
                    $width,
                    $height
                    );
          }
          else
          {
            // URL ermitteln (OnTheFly)
            $imageUrl = $item->getImageUrl(
                    $media->getWebsiteId(),
                    $media->getId(),
                    $media->getFilename(),
                    $width,
                    $height
                    );
          }
        }
      }
      catch( Exception $e )
      {
        // Fehler
        Registry::getLogger()->log( __CLASS__
                                  , __METHOD__
                                  , $e->errorMessage
                                  , \Zend_Log::WARN);
      }
    }

    // Bild-Url zurueckgeben
    return $imageUrl;
  }

  /**
   * Ermittelt die URL eines Mediums
   * @param string $id  ID des Mediums
   */
  public static function getUrl( $id )
  {
    $mediaUrl = '';

    // Id vorhanden
    if( !empty($id) )
    {
      try
      {
        // Medium ermitteln
        $media = MediaManager::findOneById( $id );

        // Medium gefunden?
        if( !isset($media) )
        {
          // Fehler
          Registry::getLogger()->log( __CLASS__
                                    , __METHOD__
                                    , 'Medium mit der id \''.$id.'\' nicht gefunden'
                                    , \Zend_Log::WARN);
        }
        else
        {
          // Item erstellen
          $item = new \Dual\Media\Item();

          // Statische-Seite oder "OnTheFly"-Seite
          if( self::isStatic() )
          {
            // URL ermitteln
            $mediaUrl = $item->getUrl(
                    self::$context->getWebsiteId(),
                    $media['id'],
                    $media['filename']
                    );
          }
          else
          {
            // URL ermitteln
            $mediaUrl = $item->getUrl(
                    $media->getWebsiteId(),
                    $media->getId(),
                    $media->getFilename()
                    );
          }
        }
      }
      catch( Exception $e )
      {
        // Fehler
        Registry::getLogger()->logData( __CLASS__
                                      , __METHOD__
                                      , 'Url ermitteln'
                                      , $e->getMessage()
                                      , \Zend_Log::WARN);
      }
    }

    // Url zurueckgeben
    return $mediaUrl;
  }

  /**
   * Ermittelt die URL eines Mediums zum direkten Download
   * @param string $id  ID des Mediums
   */
  public static function getDownloadUrl( $id )
  {
    $mediaUrl = '';

    // Id vorhanden
    if( !empty($id) )
    {
      try
      {
        // Medium ermitteln
        $media = MediaManager::findOneById( $id );

        // Medium gefunden?
        if( !isset($media) )
        {
          // Fehler
          Registry::getLogger()->log( __CLASS__
                                    , __METHOD__
                                    , 'Medium mit der id \''.$id.'\' nicht gefunden'
                                    , \Zend_Log::WARN);
        }
        else
        {
          // Item erstellen
          $item = new \Dual\Media\Item();

          // Statische-Seite oder "OnTheFly"-Seite
          if( self::isStatic() )
          {
            // URL ermitteln
            $mediaUrl = $item->getUrl(
                    self::$context->getWebsiteId(),
                    $media['id'],
                    $media['filename'],
                    null,
                    'download'
                    );
          }
          else
          {
            // URL ermitteln
            $mediaUrl = $item->getUrl(
                    $media->getWebsiteId(),
                    $media->getId(),
                    $media->getFilename(),
                    null,
                    'download'
                    );
          }
        }
      }
      catch( Doctrine_Record_Exception $e )
      {
        // Fehler
        Registry::getLogger()->logData( __CLASS__
                                      , __METHOD__
                                      , 'Url ermitteln'
                                      , $e->errorMessage
                                      , \Zend_Log::WARN);
      }
    }

    // Url zurueckgeben
    return $mediaUrl;
  }
}
