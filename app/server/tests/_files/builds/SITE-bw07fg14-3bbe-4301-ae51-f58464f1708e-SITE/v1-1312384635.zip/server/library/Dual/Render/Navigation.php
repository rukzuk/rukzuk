<?php
namespace Dual\Render;

use Seitenbau\Registry as Registry;

/**
 * Navigation
 *
 * @author       Heiko Schwarz <schwarz@seitenbau.com>
 * @copyright    Copyright (c) 2011, Seitenbau GmbH
 * @package      Dual
 * @subpackage   Render
 */

class Navigation
{
  // Navigations Konstanten
  const CURRENT_PAGE  = 'NAVI_CURRENTWEBPAGEID_NAVI';
  const ROOT          = 'ROOT';

  /**
   * Statische Variable mit der Referenz auf das Renderer-Context-Objekt
   * @access private
   */
  private static $context = null;

  /**
   * Statische Variable mit der Referenz auf das Navigations-Index-Array
   * @access private
   */
  private static $navigationIndex = array();

  /**
   * Statische Variable mit der Startseiten
   * @access private
   */
  private static $rootChildren = null;
  
  /**
   * Render-Context-Object setzen
   * @param   object  $context      Referenz auf das Context-Objekt
   * @access public
   */
  public static function setContext(&$context)
  {
    self::$context = $context;
  }

  public static function & getNavigator($pageId=null)
  {
    // Aktuelle Webpage ermitteln?
    if( !isset($pageId) || empty($pageId) || $pageId == self::CURRENT_PAGE )
    {
      // Aktuelle ermitteln
      $pageId  = CurrentPage::get('id');
    }
    
    // Navigator der uebergebenen Seite ermitteln
    $navigator = array();
    self::getNavigatorNode($pageId, $navigator);
    
    return $navigator;
  }

  protected static function getNavigatorNode($pageId, &$navigator)
  {
    if( !empty($pageId) && $pageId != self::ROOT  )
    {
      // Knoten ermitteln
      $node = self::getNodeById($pageId);
      if( isset($node) && isset($node['id']) )
      {
        // Parent zuerst ermitteln
        if( isset($node['parent']) )
        {
          self::getNavigatorNode($node['parent'], $navigator);
        }
    
        // Knoten aufnehmen
        $navigator[$node['id']] = $node;
      }
    }
    else
    {
      // Navigation bereits ermittelt?
      if( !isset(self::$rootChildren) )
      {
        // Navigations-Baum ermitteln?
        self::getNavigationTree(self::ROOT);
      }
    }
  }

  public static function & getChildren($pageId=null, $hiddenPages=false)
  {
    // init
    $children = array();
    $allChildren = array();
  
    // Aktuelle Webpage ermitteln?
    if( !isset($pageId) || empty($pageId) || $pageId == self::CURRENT_PAGE )
    {
      // Aktuelle ermitteln
      $pageId  = CurrentPage::get('id');
    }
    
    // Auf dem ROOT-Konten direkt die Startseiten zurueckgeben
    if( $pageId == self::ROOT )
    {
      // Bereits ermittelt?
      if( !isset(self::$rootChildren) )
      {
        // Navigations-Baum ermitteln?
        self::getNavigationTree(self::ROOT);
      }
      
      // ROOT-Children vorhanden
      if( isset(self::$rootChildren) && is_array(self::$rootChildren) )
      {
        // Kindelemente uebernehmen
        $allChildren = self::$rootChildren;
      }
    }
    else
    {
      // Knoten ermitteln
      $node = self::getNodeById($pageId);
      if( isset($node['children']) && is_array($node['children']) )
      {
        $allChildren = $node['children'];
      }
    }

    // Alle Seiten aufnehmen
    if( $hiddenPages === true )
    {
      $children = $allChildren;
    }
    // Nur Seiten aufnehmen, welche in der Navigation angezeigt werden sollen
    else
    {
      foreach( $allChildren as $key => &$nextChild )
      {
        if( isset($nextChild['data']) && $nextChild['data']->get('inNavigation') )
        {
          $children[$key] =& $nextChild;
        }
      }
    }

    // Kindelemente zurueckgeben
    return $children;
  }
  
  public static function & getNodeById($id)
  {
    // Id bereits im Navigations-Array vorhanden
    if( isset(self::$navigationIndex[$id]) )
    {
      // Knoten zurueckgeben
      return self::$navigationIndex[$id];
    }

    // Navigations-Baum ermitteln?
    self::getNavigationTree($id);
    
    // Id jetzt im Navigations-Array vorhanden?
    if( isset(self::$navigationIndex[$id]) )
    {
      // Knoten zurueckgeben
      return self::$navigationIndex[$id];
    }

    // Fehler
    $node = false;
    return $node;
  }
 
  protected static function getNavigationTree($id)
  {
    // init
    $navigation = array();
    $structure  = array();

    // Bei statischen Seiten nur die Navigation fuer den Knoten ermitteln
    if( is_object(self::$context) && self::$context->isStatic() )
    {
      // Navigation includieren
      include(WEBSITE_PATH.'/navigation.php');
      include(WEBSITE_PATH.'/structure.php');
    }
    // On the Fly
    else
    {
      // Navigation aus der Aktuellen Website ermitteln
      $navigation = CurrentSite::get('navigation');
      $navigation = \Zend_Json::decode($navigation);
    }

    // Navigations-Array aufbauen
    return self::createNavigation($navigation, $structure);
  }
  
  protected static function createNavigation( &$navi, &$structure )
  {
    // Navigation ermitteln
    self::createNavigationInternal($navi, $structure, self::$rootChildren);
  }

  protected static function createNavigationInternal( &$navi, &$structure, &$children, $parentId=self::ROOT )
  {
    // Navigations-Array vorhanden
    if( isset($navi) && is_array($navi) )
    {
      // init
      $children = array();
    
      // Knoten durchlaufen
      foreach($navi as $node)
      {
        // Webpage ermittel
        $webpage = new Webpage();
        
        // Bei statischen Seiten die Werte direkt aufnehmen
        if( is_object(self::$context) && self::$context->isStatic() )
        {
          // Webpage-Daten ermitteln
          $data = $node;
          $globalVars = array();

          // Globale-Daten includieren
          include(WEBSITE_PATH.DIRECTORY_SEPARATOR.'pages' .
                  DIRECTORY_SEPARATOR.$node['id'].DIRECTORY_SEPARATOR.'global.php');

          // Webpage-Daten  vorhanden
          if( isset($pageGlobalVars) && is_array($pageGlobalVars) )
          {
            // Daten uebernehmen
            $globalVars = $pageGlobalVars;
          }
          
          // Meta-Daten includieren
          include(WEBSITE_PATH.DIRECTORY_SEPARATOR.'pages' .
                  DIRECTORY_SEPARATOR.$node['id'].DIRECTORY_SEPARATOR.'meta.php');
          
          // Webpage-Daten  vorhanden
          if( isset($pageMeta) && is_array($pageMeta) )
          {
            // Daten uebernehmen
            $data = $pageMeta;
          }
          
          // Url aus der Navigation ermitteln
          if( isset($node['url']) && !empty($node['url'])
                  && file_exists(WEBSITE_PATH.$node['url']) )
          {
            // Ueber die Url auf die Seite
            $data['url'] = WEBROOT_PATH.$node['url'];
          }
          // Url aus der Struktur ermitteln
          elseif( is_array($structure)
              && isset($structure['page']) && is_array($structure['page'])
              && isset($structure['page'][$node['id']])
              && is_array($structure['page'][$node['id']])
              && isset($structure['page'][$node['id']]['url'])
              && !empty($structure['page'][$node['id']]['url'])
            )
          {
            // Ueber die Url auf die Seite
            $data['url'] = WEBROOT_PATH.$structure['page'][$node['id']]['url'];
          }
          // Url ueber die ID zusammenbauen
          else
          {
            // Ueber ID auf die Seite
            $data['url'] = WEBROOT_PATH.'/pages/'.$node['id'].'/index.html';
          }
        
          // Werte uebernehmen
          $webpage->setArray($data);
          $webpage->setGlobalArray($globalVars);
        }
        // On the Fly
        else
        {
          // Webpage-Daten ermitteln
          $data = $node;
          $globalVars = array();
          try
          {
            $config = Registry::getConfig();
            $serverUrl = $config->server->url;

            // Webpage ermitteln
            $cmsWebpage = self::$context->getService('page')->getById(
              $node['id'],
              self::$context->getWebsiteId()
            );

            // Webpage gefunden?
            if( is_object($cmsWebpage) )
            {
              // Daten uebernehmen
              $data = $cmsWebpage->toArray();
              $globalVars = \Zend_Json::decode($data['globalcontent']);

              // Einige Attribute entfernen
              unset($data['content']);
              unset($data['globalcontent']);
              unset($data['templateContent']);
            }
          }
          catch(Exception $e )
          {
            // ToDo: Error-Logging
          }
          
          // Url aufnehmen
          $urlParams = sprintf(
                  '{"pageid":"%s","websiteid":"%s"}',
                  $node['id'],
                  self::$context->getWebsiteId() );
          $data['url'] = sprintf(
                  '%s%s%s',
                  $serverUrl,
                  '/render/page/params/',
                  urlencode($urlParams) );

          // Werte aufnehmen
          $webpage->setArray($data);
          $webpage->setGlobalArray($globalVars);
        }

        // Knoten in den Index aufnehmen
        self::$navigationIndex[$node['id']] = array(  'id'      => $node['id']
                                                    , 'data'    => $webpage
                                                    , 'parent'  => $parentId
                                                    );
        
        // Diesen Knoten als Children aufnehmen
        $children[] =& self::$navigationIndex[$node['id']]; 

        // Kindelemente durchlaufen
        if( isset($node['children']) && is_array($node['children']) )
        {
          self::$navigationIndex[$node['id']]['children'] = null;
          if( !self::createNavigationInternal($node['children'], $structure, self::$navigationIndex[$node['id']]['children'], $node['id']) )
          {
            // Fehler -> Abbrechen
            return false;
          }
        }
      }
    }
    
    // Erfolgreich
    return true;
  }
  
}