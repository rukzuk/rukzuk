<?php
namespace Dual\Render;

use Cms\Service\Iface\Marker as Service;

/**
 * @author     Heiko Schwarz <schwarz@seitenbau.com>
 * @copyright  2011 Seitenbau GmbH (www.seitenbau.de)
 * @package    Dual
 * @subpackage Render
 */

class RenderContext
{
  // Render-Modus
  const MODE_EDIT     = 'EDIT';
  const MODE_PREVIEW  = 'PREVIEW';
  const MODE_SHOW     = 'SHOW';

  // Umgebung des Renders
  const CONTEXT_TYPE_TEMPLATE = 'TEMPLATE';
  const CONTEXT_TYPE_PAGE = 'PAGE';

  /**
   * Speichert das Seiten-ROOT-Objekt.
   * @var object
   */
  private $siteRoot;

  /**
   * Speichert den Render-Modus
   * @var string
   */
  private $renderMode;

  /**
   * Speichert die Umgebung, in der gerendert wird
   * @var string
   */
  private $contextType;

  /**
   * Flag Statische-Seite oder OnTheFly-Seite
   * @var boolean
   */
  private $static;

  /**
   * Flag Buffer on/off
   * @var string
   */
  private $bufferActive = false;

  /**
   * Ausgabe-Buffer
   * @var array
   */
  private $buffer = array();

  /**
   * Render-Status
   * @var array
   */
  private $renderState = array();

  /**
   * Array kann mehrere Services enhalten
   * @var array
   */
  private $services = array();

  /**
   * WebsiteId zum Auslesen verschiedener Daten (Bsp: Modul Service)
   * @var string
   */
  private $websiteId = null;

  /**
   * Konstruktor.
   */
  public function __construct()
  {
    // init
    $this->siteRoot = null;
    $this->renderMode = self::MODE_SHOW;
    $this->contextType = self::CONTEXT_TYPE_PAGE;
    $this->static = false;
    $this->buffer = array();
    $this->renderState = array();
  }

  public function getWebsiteId()
  {
    return $this->websiteId;
  }

  public function setWebsiteId($websiteId)
  {
    $this->websiteId = $websiteId;
  }

  /**
   * Setzt das Statische-Seiten Flag
   */
  public function setStatic()
  {
    $this->static = true;
  }

  /**
   * Setzt das Statische-Seiten Flag zurueck auf "OnTheFly"-Seite
   */
  public function resetStatic()
  {
    $this->static = false;
  }

  /**
   * Liefert das Statische-Seiten Flag zurueck
   * @return boolean
   */
  public function isStatic()
  {
    return $this->static;
  }

  /**
   * Setzt das Seiten-Root-Object
   * @param object $root Seiten-Root-Object
   */
  public function setRoot(&$root)
  {
    $this->siteRoot = $root;
  }

  /**
   * Gibt das Seiten-Root-Object zurueck.
   * @return object
   */
  public function getRoot()
  {
    return $this->siteRoot;
  }

  /**
   * Setzt den Render-Modus
   * @param string  $mode Render-Modus
   */
  public function setRenderMode($mode)
  {
    $this->renderMode = $mode;
  }

  /**
   * Gibt den Render-Modus zurueck.
   * @return string
   */
  public function getRenderMode()
  {
    return $this->renderMode;
  }

  public function setContextType($contextType)
  {
    $this->contextType = $contextType;
  }

  public function getContextType()
  {
    return $this->contextType;
  }

  public function setBufferState( $bufferActive=false )
  {
    $this->bufferActive = ($bufferActive===true ? true : false);
  }

  public function getBufferState( )
  {
    return $this->bufferActive;
  }

  public function startBuffer($type)
  {
    if( $this->bufferActive )
    {
      // Buffer anschalten
      ob_start();
    }
  }

  public function endBuffer($type)
  {
    if( $this->bufferActive )
    {
      // Buffer init
      if( !is_array($this->buffer[$type]) )
      {
        $this->buffer[$type] = array();
      }

      // Ausgabe uebernehmen
      $this->buffer[$type][] = ob_get_contents();
      ob_end_clean();
    }
  }

  public function & getBuffer($type)
  {
    return $this->buffer[$type];
  }


  /**
   * Fuegt einen weiteren Service hinzu
   *
   * @param string $name
   * @param Service $service
   */
  public function addService ($name, Service $service)
  {
    $this->services[$name] = $service;
  }

  /**
   * Gibt den angegebenen Service zurueck
   * Ist der Service nicht vorhanden wird null zurueckgegeben
   *
   * @param string $name
   * @return Cms\Service\Iface\Marker|null
   */
  public function getService($name = '')
  {
    if (\array_key_exists($name, $this->services))
    {
      return $this->services[$name];
    }
    return null;
  }

  public function checkRenderState($type, $id)
  {
    // Wurde der Typ und eine ID angegeben
    if( !empty($type) && !empty($id) )
    {
      // Typ vorhanden
      if( isset($this->renderState[$type]) && is_array($this->renderState[$type]) )
      {
        // Wurde diese ID bereits gerendert
        if( isset($this->renderState[$type][$id]) )
        {
          // Ja, status zurueckgeben
          return $this->renderState[$type][$id];
        }
      }
    }

    // Nein
    return false;
  }

  public function addRenderState($type, $id, $state)
  {
    // Typ vorhanden
    if( !isset($this->renderState[$type]) || !is_array($this->renderState[$type]) )
    {
      // Typ aufnehmen
      $this->renderState[$type] = array();
    }

    // Id aufnehmen
    $this->renderState[$type][$id] = $state;

    // Erfolgreich
    return true;
  }
}
