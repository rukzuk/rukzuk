<?php
namespace Dual\Render;

/**
 * @author       Heiko Schwarz <schwarz@seitenbau.com>
 * @copyright    2011 Seitenbau GmbH (www.seitenbau.de)
 * @package      Dual
 * @subpackage   Render
 */

class RenderList extends BaseList
{
  protected $renderContext  = null;
  private   $parentUnit     = null;

  /**
   * Konstruktor.
   * @param   object  $context  Referenz auf das Kontext-Objekt
   */
  public function __construct()
  {
    // ******************************************
    // Parent-Klasse aufrufen
    parent::__construct( );
    // ******************************************
  }

  public function setRenderContext( &$renderContext )
  {
    $this->renderContext = $renderContext;
  }

  public function getRenderContext( )
  {
    return $this->renderContext;
  }

  public function setParent( &$parentUnit )
  {
    $this->parentUnit = $parentUnit;
  }

  public function getParent( )
  {
    return $this->parentUnit;
  }

  public function setTree( $tree )
  {
    if( is_array($tree) )
    {
      foreach($tree as $nextElement)
      {
        // Statische Seiten
        if( $this->getRenderContext()->isStatic() === true )
        {
          // Klassennamen um den Namespace erweitern (liefert sonst PHP-Fehler)
          $nextElement = '\Dual\Render\\'.$nextElement; // Bringe sonst

          // Objekt erzeugen
          $oNextModul = new $nextElement();
          $renderContext = $this->getRenderContext();
          $oNextModul->setRenderContext($renderContext);
          $oNextModul->setParent($this->parentUnit);
          $oNextModul->initValues();
          $this->add( $oNextModul->getId(), $oNextModul );
        }
        else
        {
          // "OnTheFly"-Seite direkt die Module erzeugen und mit Daten fuellen

          // Objekt erzeugen
          $oNextModul = new RenderModule();
          $renderContext = $this->getRenderContext();
          $oNextModul->setRenderContext($renderContext);
          $oNextModul->setParent($this->parentUnit);
          $oNextModul->setArray($nextElement);
          $this->add( $oNextModul->getId(), $oNextModul );
        }
      }
    }
  }

  public function renderHtml( )
  {
    foreach( $this as $oNextElement )
    {
      $oNextElement->setWebsiteId($this->renderContext->getWebsiteId());
      $oNextElement->renderHtml();
    }
  }

  public function renderCss( &$css )
  {
    foreach( $this as $oNextElement )
    {
      $oNextElement->renderCss( $css );
    }
  }

  public function renderHead( )
  {
    foreach( $this as $oNextElement )
    {
      $oNextElement->renderHead( );
    }
  }
}
