<?php
namespace Dual\Render;

use \Seitenbau\Registry,
    Dual\Media\Item as MediaItem;

/**
 * Render MediaDb
 *
 * @author       Heiko Schwarz <schwarz@seitenbau.com>
 * @copyright    Copyright (c) 2011, Seitenbau GmbH
 * @package      Dual
 * @subpackage   Render
 */

class MediaDb
{
  /**
   * Ermittelt die URL eines Bildes
   * @param string $id  ID des Mediums
   * @param integer $width  Breite des Bildes
   * @param integer $height  Hoehe des Bildes
   */
  public static function getImageUrl( $id, $width=false, $height=false )
  {
    // Bild-Url ermitteln
    return MediaManager::getImageUrl( $id, $width, $height );
  }

  /**
   * Ermittelt die URL eines Mediums
   * @param string $id  ID des Mediums
   */
  public static function getUrl( $id )
  {
    // Url ermitteln
    return MediaManager::getUrl( $id );
  }

  /**
   * Ermittelt die URL eines Mediums zum direkten Download
   * @param string $id  ID des Mediums
   */
  public static function getDownloadUrl( $id )
  {
    // Download-Url ermitteln
    return MediaManager::getDownloadUrl( $id );
  }
}
