<?php
namespace Dual\Render;

use Seitenbau\Registry;

/**
 * Render-Objekt-Klasse
 *
 * @author       Heiko Schwarz <heiko.schwarz@seitenbau.com>
 * @copyright    Copyright &copy; 2010, Seitenbau GmbH
 * @package      Dual
 * @subpackage   Render
 */
class RenderObject
{
  private $Id                 = '';
  private $Name               = '';
  private $Values             = array();
  private $ModuleFormValues   = array();
  private $ModuleId           = '';
  private $WebsiteId          = '';
  private $RendererCode       = '';
  private $CssCode            = '';
  private $HeadCode           = '';
  private $Children           = array();
  private $ChildClassIds      = array();
  private $renderContext      = null;
  private $curRenderType      = null;
  private $internalFunctions  = array();
  private $parentUnit         = null;
  private $ghostContainer     = false;
  private $templateUnitId     = null;


  const RENDER_TYPE_HTML      = 'renderHtml';
  const RENDER_TYPE_HEAD      = 'renderHead';
  const RENDER_TYPE_CSS       = 'renderCss';
  
  const CSSTIDY_ACTIVE        = false;

  /**
   * Konstruktor.
   */
  public function __construct()
  {
    // Nothing ToDo
  }

  public function setRenderContext( &$renderContext )
  {
    $this->renderContext = $renderContext;
  }

  public function getRenderContext( )
  {
    return $this->renderContext;
  }

  public function setParent( &$parentUnit )
  {
    $this->parentUnit = $parentUnit;
  }

  public function getParent( )
  {
    return $this->parentUnit;
  }

  public function getMode( )
  {
    return $this->renderContext->getRenderMode();
  }

  public function isTemplate()
  {
    if ($this->renderContext->getContextType() == RenderContext::CONTEXT_TYPE_TEMPLATE)
    {
      return true;
    }
    return false;
  }

  public function isPage()
  {
    if ($this->renderContext->getContextType() == RenderContext::CONTEXT_TYPE_PAGE)
    {
      return true;
    }
    return false;
  }

  public function set( $Key, $Value )
  {
    $this->Values[$Key] = $Value;
  }

  public function get( $Key )
  {
    if( $Key == 'ID' )
    {
      return $this->getId();
    }

    if( isset($this->Values[$Key]) )
    {
      return $this->Values[$Key];
    }
    return;
  }

  public function getId( )
  {
    return $this->Id;
  }
  
  public function getName( )
  {
    return $this->Name;
  }

  public function isGhostContainer( )
  {
    return $this->ghostContainer;
  }

  public function getTemplateUnitId( )
  {
    return ( $this->isTemplate() ? $this->getId() : $this->templateUnitId );
  }

  public function getValues( )
  {
    return $this->Values;
  }

  public function getModuleId( )
  {
    return $this->ModuleId;
  }

  public function getWebsiteId()
  {
    return $this->WebsiteId;
  }

  public function setWebsiteId($websiteId)
  {
    $this->WebsiteId = $websiteId;
  }

  public function getChildren( )
  {
    return $this->Children;
  }

  public function getRendererCode( )
  {
    return $this->RendererCode;
  }

  public function getCssCode( )
  {
    return $this->CssCode;
  }
  
  public function getHeadCode( )
  {
    return $this->HeadCode;
  }

  public function p( $Key, $bHtmlEncode=false )
  {
    if( $bHtmlEncode )
    {
      echo htmlentities($this->get($Key), ENT_COMPAT, 'UTF-8');
    }
    else
    {
      echo $this->get($Key);
    }
  }

  public function pEditable( $fieldName, $tag, $attributes='' )
  {
    echo $this->getEditable($fieldName, $tag, $attributes);
  }

  public function getEditable( $fieldName, $tag, $attributes='' )
  {
    // init
    $htmlOutput = '';
    $tag = (empty($tag) ? 'div' : $tag);

    // Start-Tag
    $htmlOutput .= '<'.$tag;

    // editable-Attribute im Edit-Modus
    if ($this->getMode() === RenderContext::MODE_EDIT)
    {
      $htmlOutput .= ' data-cms-editable="'.$fieldName.'"';
    }

    // Weitere Attribute
    if( !empty($attributes))
    {
      $htmlOutput .= ' '.$attributes;
    }

    // Start-Tag-Ende
    $htmlOutput .= '>';

    // Eingegebener HTML-Code
    $fieldValue = $this->get($fieldName);
    $this->replaceLinks($fieldValue);
    $htmlOutput .= $fieldValue;

    // End-Tag
    $htmlOutput .= '</'.$tag.'>';

    // Gesammter HTML-Code zurueckgeben
    return $htmlOutput;
  }

  public function getAssetUrl()
  {
    $config = Registry::getConfig();

    if( $this->getRenderContext()->isStatic() === true )
    {
      return ASSET_WEBPATH.'/modules/'.$this->getModuleId();
    }
    else
    {
      $websiteId = $this->getRenderContext()->getWebsiteId();
      return $config->assets->modules->webpath . '/' .
               $websiteId . '/' .
               'modules/' .
               $this->getModuleId();
    }
  }
  
  public function getAssetPath()
  {
    if( $this->getRenderContext()->isStatic() === true )
    {
      return DOCROOT_PATH.ASSET_WEBPATH.'/modules/'.$this->getModuleId();
    }
    else
    {
      $config = Registry::getConfig();

      $websiteId = $this->getRenderContext()->getWebsiteId();
      return DOCUMENT_ROOT.
               $config->assets->modules->webpath . '/' .
               $websiteId . '/' .
               'modules/' .
               $this->getModuleId();
    }
  }

  public function setArray( $NewValues )
  {
    $this->Id             = $NewValues['id'];
    $this->Name           = $NewValues['name'];
    $this->ghostContainer = ( isset($NewValues['ghostContainer']) && $NewValues['ghostContainer'] ? true : false );
    $this->templateUnitId = ( isset($NewValues['templateUnitId']) ? $NewValues['templateUnitId'] : null );
    $this->Values         = $NewValues['formValues'];
    $this->ModuleId       = $NewValues['moduleId'];
    $this->Children       = ( isset($NewValues['children']) ? $NewValues['children'] : array() );
  }

  public function insertJsApi()
  {
    if ($this->getMode() === RenderContext::MODE_EDIT)
    {
      $config = Registry::getConfig();
      echo '<script type="text/javascript" src="'.$config->client->api_url.'"></script>';
    }
  }

  protected function insertCss()
  {
    // Rendern wir bereits das CSS?
    if( $this->curRenderType != self::RENDER_TYPE_CSS )
    {
      // Nein -> CSS-Rendern
      $root = $this->renderContext->getRoot();
      if( is_object($root) )
      {
        $css_code = '';
        $root->renderCss( $css_code );
        if( self::CSSTIDY_ACTIVE )
        {
          $tidy = new csstidy();
          $tidy->set_cfg('remove_last_;',TRUE);
          $tidy->parse($css_code);
          echo $tidy->print->plain();
        }
        else
        {
          echo $css_code;
        }
      }
    }
  }

  protected function insertHead()
  {
    // Rendern wir bereits den Head?
    if( $this->curRenderType != self::RENDER_TYPE_HEAD )
    {
      // Nein -> Head rendren
      $root = $this->renderContext->getRoot();
      if( is_object($root) )
      {
        $root->renderHead( );
      }
    }
  }

  protected function html()
  {
    // Do nothing
  }

  protected function css( &$css )
  {
    // Do nothing
  }

  protected function head()
  {
    // Do nothing
  }

  public function renderHtml( )
  {
    

    // Render-Typ merken
    $this->curRenderType = self::RENDER_TYPE_HTML;
    
    // Muessen die Default-Werte noch ermittelt werden
    if( $this->getRenderContext()->isStatic() !== true )
    {
      // Default-Werte ermitteln
      $this->getBaseValues();

      // Werte zusammenfuehren
      $this->mergeFormValues();
    }

    // Ausgabe Buffern
    $this->renderContext->startBuffer(self::RENDER_TYPE_HTML);
    
    // HTML rendern
    $this->html();
    
    // Ausgabe Buffern
    $this->renderContext->endBuffer(self::RENDER_TYPE_HTML);
  }

  public function renderCss( &$css )
  {
    // Render-Typ merken
    $this->curRenderType = self::RENDER_TYPE_CSS;

    // Muessen die Default-Werte noch ermittelt werden
    if( $this->getRenderContext()->isStatic() !== true )
    {
      // Default-Werte ermitteln
      $this->getBaseValues();

      // Werte zusammenfuehren
      $this->mergeFormValues();
    }

    // CSS-Rendern
    $this->css( $css );
  }

  public function renderHead( )
  {
    // Render-Typ merken
    $this->curRenderType = self::RENDER_TYPE_HEAD;

    // Muessen die Default-Werte noch ermittelt werden
    if( $this->getRenderContext()->isStatic() !== true )
    {
      // Default-Werte ermitteln
      $this->getBaseValues();

      // Werte zusammenfuehren
      $this->mergeFormValues();
    }

    // Ausgabe Buffern
    $this->renderContext->startBuffer(self::RENDER_TYPE_HEAD);
    
    // HTML rendern
    $this->head();
    
    // Ausgabe Buffern
    $this->renderContext->endBuffer(self::RENDER_TYPE_HEAD);
  }

  protected function renderChilds( $type=self::RENDER_TYPE_HTML )
  {
    $this->renderChildren($type);
  }
  
  protected function renderChildren( $type=self::RENDER_TYPE_HTML )
  {
    // Ausgabe Buffern
    $this->renderContext->endBuffer($type);

    $oChildren = new RenderList();
    $renderContext = $this->getRenderContext();
    $oChildren->setRenderContext($renderContext);
    $oChildren->setParent($this);
    $oChildren->setTree($this->Children);

    // Rendern
    $oChildren->$type();

    // Ausgabe Buffern
    $this->renderContext->startBuffer($type);
  }

  protected function renderChildsCss( &$css )
  {
    $oChilds = new RenderList();
    $renderContext = $this->getRenderContext();
    $oChilds->setRenderContext($renderContext);
    $oChilds->setParent($this);
    $oChilds->setTree($this->Children);

    // Rendern
    $oChilds->renderCss( $css );
  }

  protected function getBaseValues( )
  {
    // Basiswerte ermitteln (nur OnTheFly)
    if( $this->getRenderContext()->isStatic() !== true )
    {
      // Hier z.B. den Render-und Css-Code aus dem Modul ermitteln
      $this->RendererCode = '';
      $this->CssCode      = '';
      $this->HeadCode     = '';
      try
      {
        // Modul ermitteln
        $modul = $this->getRenderContext()
                      ->getService('modul')
                      ->getById($this->ModuleId,
                         $this->getRenderContext()->getWebsiteId());

        // Modul gefunden?
        if( is_object($modul) )
        {
          // Renderer-Code uebernehmen
          $this->RendererCode = $modul->getRenderer();

          // CSS-Code uebernehmen
          $this->CssCode = $modul->getCss();

          // Head-Code uebernehmen
          $this->HeadCode = $modul->getHeader();

          // Form-Werte uebernhemen
          $this->ModuleFormValues = $modul->decode('formValues');
        }
      }
      catch( Doctrine_Record_Exception $e )
      {
        // Fehler
        echo "Fehler: ".$e."<br />";

        // ToDo
      }
    }
  }

  protected function mergeFormValues( )
  {
    // Form-Werte zusammenfuehren
    if( is_array($this->ModuleFormValues) )
    {
      if( is_array($this->Values) )
      {
        // Module-Form-Defaultwerte und Modul-Instanz-Werte zusammenfuegen
        $aNewValue = array_replace_recursive($this->ModuleFormValues, $this->Values);
        if( is_array($aNewValue) )
        {
          $this->Values = $aNewValue;
        }
        else
        {
          // Fehler
          Seitenbau_Registry::getLogger()->log(   __FILE__
                                                , __LINE__
                                                , 'Fehler beim zusammenfuegen der Formwerte'
                                                , Zend_Log::ERR);
        }
      }
      else
      {
        // Nur Module-Form-Defaultwerte uebernehmen
        $this->Values = $this->ModuleFormValues;
      }
    }
  }
  
  protected function checkRenderHeadState()
  {
    // Wurde der Head dieses Modul (nicht Unit) bereits gerendert
    return $this->getRenderContext()->checkRenderState( self::RENDER_TYPE_HEAD
                                                      , $this->getModuleId()
                                                      );
  }
  protected function addRenderHeadState()
  {
    // Head-Render Status dieses Modul (nicht Unit) setzen
    return $this->getRenderContext()->addRenderState( self::RENDER_TYPE_HEAD
                                                    , $this->getModuleId()
                                                    , true
                                                    );
  }

  
  /*
   * Hilfsfunktionen fuer den HTML/CSS/HEAD-Renderer
   */

  // Ersetzen von Links des HTML-Editors
  protected function replaceLinks(&$data)
  {
    // entsprechende Link-Tags suchen und ersetzen
    $data = preg_replace_callback( '/(<\s*a\s+)([^>]*?)(data-cms-link-type\s*=\s*["\'](internalPage|internalMedia|mail|external)["\'])([^>]*?)(>)/i', array($this, 'replaceLinkTagCallback'), $data );
  }
  private function replaceLinkTagCallback($linkCode)
  {
    // init
    $output   = '';
    $linkType = (isset($linkCode[4]) ? strtolower($linkCode[4]) : 'default');
    $replaceCmsDataAttributes = ($this->getMode() === RenderContext::MODE_EDIT
                                  ? false : true);

    // Wichtige Link-Daten ermitteln
    $cmsDataAttributes = array();
    $this->findCmsDataAttributes(
            $linkCode[2],
            $cmsDataAttributes,
            $replaceCmsDataAttributes);
    $this->findCmsDataAttributes(
            $linkCode[5],
            $cmsDataAttributes,
            $replaceCmsDataAttributes);

    // interner Link oder Media und Link-Daten vorhanden
    if ( ($linkType == 'internalpage' || $linkType == 'internalmedia')
         && isset($cmsDataAttributes['link']) )
    {
      $newHref = '';

      // Neuer Href ermitteln
      if ($linkType == 'internalpage')
      {
        // Url der Page ermitteln
        $page = Navigation::getNodeById($cmsDataAttributes['link']);
        if (is_array($page) && isset($page['data']) && is_object($page['data']))
        {
          $newHref = $page['data']->get('url');
        }
      }
      elseif ($linkType == 'internalmedia')
      {
        // Download-Url des MediaDB Items ermitteln
        $newHref = MediaDb::getDownloadUrl($cmsDataAttributes['link']);
      }
      
      if (empty($newHref))
      {
        $newHref = '#';
      }

      // Html-encodieren
      $newHref = htmlentities($newHref, ENT_COMPAT, 'UTF-8');

      // Neuer Href ermittelt -> ersetzen
      $this->replaceLinkHref($linkCode[2], $newHref);
      $this->replaceLinkHref($linkCode[5], $newHref);
    }

    // Ausherhalb des Edit-Modus das 'data-cms-link' Attribut entfernen
    if ($replaceCmsDataAttributes)
    {
      $output = $linkCode[1].$linkCode[2].$linkCode[5].$linkCode[6];
    }
    // Im Edit-Modus den Link-Tag neu erstellen
    else
    {
      $output = $linkCode[1].$linkCode[2].$linkCode[3].$linkCode[5].$linkCode[6];
    }

    return $output;
  }
  private function findCmsDataAttributes(&$code, &$cmsData, $replace=true)
  {
    // cms-Data Attribute ermitteln
    $findRegExp = '/ data-cms-(link|type)\s*=\s*"([^"]*)"|\'([^\']*)\'/i';
    if (preg_match_all($findRegExp, $code, $treffer, PREG_SET_ORDER))
    {
      // cms-data Attribute aufnehmen
      foreach ($treffer as $nextAttribute)
      {
        $cmsData[strtolower($nextAttribute[1])] ='';
        if (isset($nextAttribute[2]))
        {
          $cmsData[strtolower($nextAttribute[1])] .= $nextAttribute[2];
        }
        if (isset($nextAttribute[3]))
        {
          $cmsData[strtolower($nextAttribute[1])] .= $nextAttribute[3];
        }
      }

      // ggf. cms-data Attribute entfernen
      if ($replace)
      {
        $code = preg_replace($findRegExp, '', $code);
      }
    }
  }
  private function replaceLinkHref(&$code, $newHref)
  {
    $code = preg_replace( '/ href\s*=\s*("[^"]*"|\'[^\']*\')/i', ' href="'.$newHref.'"', $code);
  }
  
  // CSS-Interpreter
  protected function runCssInterpreter( &$curCss )
  {
    // MedienDB Objecte ersetzen
    $curCss = preg_replace_callback( '/<!--PRINT:(.*?)-->/', array($this, 'replaceField'), $curCss );

    // MedienDB Objecte ersetzen
    $curCss = preg_replace_callback( '/<!--MDB:(.*?)-->/', array($this, 'replaceCssMdb'), $curCss );

    // MedienDB Objecte anhand der ID ersetzen
    $curCss = preg_replace_callback( '/<!--MDB-ID:(.*?)-->/', array($this, 'replaceCssMdb'), $curCss );
  }
  private function replaceField($mdbCode)
  {
    // init
    $output = '';
    
    // Wurde etwas angegeben
    if( !empty($mdbCode[1]) )
    {
      // Feldwert uebernehmen
      $output .= $this->get($mdbCode[1]);
    }
    
    // Neuer Wert zurueckgeben
    return $output;
  }
  private function replaceCssMdbId($mdbCode)
  {
    return $this->replaceCssMdbId($mdbCode,true);
  }
  private function replaceCssMdb($mdbCode, $byId=false)
  {
    // init
    $output = '';
    
    // Wurde etwas angegeben
    if( !empty($mdbCode[1]) )
    {
      // Einzelne Werte ermitteln
      if( strpos($mdbCode[1],':') === false )
      {
        // Nur ein Parameter vorhanden
        $values = array($mdbCode[1]);
      }
      else
      {
        // Mehrere Parameter vorhanden
        $values = preg_split('/:/', $mdbCode[1]);
      }
      // Werte vorhanden
      if( is_array($values) && !empty($values[0]) )
      {
        // Feldwert uebernehmen
        if( $byId )
        {
          // Wert ermitteln
          $fieldValue = $this->get($values[0]);
        }
        else
        {
          // Wert als ID direkt verwenden
          $fieldValue = $values[0];
        }
        
        // Bild ausgeben
        if( count($values) > 1 )
        {
          // Breitenangabe ermitteln
          $width  = ( (isset($values[1]) && $values[1] != 'false') ? intval($values[1]) : false );
          $height = ( (isset($values[2]) && $values[2] != 'false') ? intval($values[2]) : false );

          // Bildurl ermitteln
          $output .= MediaDb::getImageUrl( $fieldValue, $width, $height );
        }
        // Normale URL ausgeben
        else
        {
          // Bildurl ermitteln
          $output .= MediaDb::getUrl( $fieldValue );
        }
      }
    }
    
    // Neuer Wert zurueckgeben
    return $output;
  }

  // Eigene Funktionen fuer das Modul/Unit aufnehmen
  public function addFunction($method, $callback) 
  { 
    $this->internalFunctions[$method] =& $callback;
  }  
  
  // Eigene Funktionen ausfuehren
  public function __call($method, $args = array()) 
  {
    
    if( isset($this->internalFunctions[$method])
        && 
        is_callable($this->internalFunctions[$method])
      ) 
    {
      return call_user_func_array($this->internalFunctions[$method], $args); 
    }
  }
}
