<?php
namespace Dual\Render;

/**
 * Grundlegende Definitionen und Objekte anlegen
 */
require_once('bootstrap.php');


/**
 * Context-Object dem Navigations-Objekt zuweisen
 */
Navigation::setContext($renderContext);


/**
 * Auf die erste Seite springen
 */
$nodes  = Navigation::getChildren(Navigation::ROOT);
$url    = $nodes[0]['data']->get('url');
if( !empty($url) && $url != $_SERVER['PHP_SELF'] )
{
  // Query anhaengen
  if( isset($_SERVER['QUERY_STRING']) && !empty($_SERVER['QUERY_STRING']) )
  {
    $url .= '?'.$_SERVER['QUERY_STRING'];
  }

  // Weiterleiten
  header("Location:".$url);
  exit;
}

echo "Keine Start-Page zum Anzeigen gefunden\n";
