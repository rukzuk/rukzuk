<?php
namespace Dual\Render;

/**
 * Dieses Skript dient zum Streamen der Medien
 *
 * @author       Heiko Schwarz <schwarz@seitenbau.com>
 * @copyright    Copyright (c) 2011, Seitenbau GmbH
 */
 
/**
 * Grundlegende Definitionen und Objekte anlegen
 */
require_once('bootstrap.php');

// HTTP-Cache verwenden
define( 'HTTP_CACHE', true );

/**
 * Grundlegende Definitionen und Objekte anlegen
 */
require_once(LIBRARY_PATH.'/Dual/Render/MediaManager.php');
require_once(LIBRARY_PATH.'/Seitenbau/Mimetype.php');


/**
 * init
 */
$aRequestData   = array();
$bFoundMedia    = false;
$sMediaId       = false;
$newWidth       = 0;
$newHeight      = 0;
$newMaxWidth    = 0;
$newMaxHeight   = 0;
$aHeader        = array( 'HTTP/1.0 404 Not Found' );
$bIcon          = false;



/**
 * Art des sendens ermitteln
 */
if( !empty($_REQUEST['image']) || !empty($_REQUEST['icon']) )
{
  // Bild senden
  $streamAction = 'view';
  $bIcon        = ( empty($_REQUEST['image']) && !empty($_REQUEST['icon']) ? true : false );
  $sMediaId     = ( $bIcon ? $_REQUEST['icon'] : $_REQUEST['image'] );
  $newWidth     = (int) (!empty($_REQUEST['width']) ? $_REQUEST['width'] : 0 );
  $newHeight    = (int) (!empty($_REQUEST['height']) ? $_REQUEST['height'] : 0 );
  $newMaxWidth  = (int) (!empty($_REQUEST['maxwidth']) ? $_REQUEST['maxwidth'] : 0 );
  $newMaxHeight = (int) (!empty($_REQUEST['maxheight']) ? $_REQUEST['maxheight'] : 0 );
}
elseif( !empty($_REQUEST['download']) )
{
  // Download streamen
  $streamAction = 'download';
  $sMediaId   = $_REQUEST['download'];
}
else
{
  // Datei direkt streamen
  $streamAction = 'stream';
  $sMediaId   = ( !empty($_REQUEST['stream']) ? $_REQUEST['stream'] : $_REQUEST['id'] );
}


/**
 * ID vorhanden
 */
if( !empty($sMediaId) )
{
  try
  {
    // Medium ermitteln
    $media = MediaManager::findOneByid( $sMediaId );
    
    // Medium gefunden?
    if( !isset($media) )
    {
      // Fehler

      // ToDo Logging
    }
    else
    {
      // Media-Item Object anlegen
      $item = new \Dual\Media\Item();
    
      // Bei Bildern evtl. resizen
      if( ($media['type'] == 'image' || $bIcon)
          &&
          ($newWidth > 0 || $newHeight > 0 || $newMaxWidth > 0 || $newMaxHeight > 0 )
        )
      {
        // Pfad zur Veraenderten Datei ermitteln
        $sStreamFile = $item->resize( null, $media['file'], $newWidth, $newHeight, $newMaxWidth, $newMaxHeight, $bIcon );
      }
      else
      {
        // Datei streamen
        if( $bIcon )
        {
          // Icon bzw. Thumbnail
          $sStreamFile = $item->getIconFile($media['file']);
        }
        else
        {
          // Orginal-Datei verwenden
          $sStreamFile = MEDIA_PATH.'/'.$media['file'];
        }
      }
      
      // Dateiname uebernehmen
      if( $bIcon )
      {
        // Icon
        $sFileName = $item->getIconFile($media['file'], null, true);
      }
      else
      {
        // Media-Darei
        $sFileName = $media['filename'];
      }

      // Header ermitteln
      $aHeader = array( );
      
      /*
       * HTTP-Caching beachten
       */
      if( defined('HTTP_CACHE') && HTTP_CACHE === true )
      {
        // Aenderungsdatum vorahnden
        if( empty($fileModTime) )
        {
          // Nein -> Dateidatum verwenden
          $fileModTime = filemtime($sStreamFile);
        }
        $fileModTimeString  = gmdate( "D, j M Y H:i:s T", $fileModTime );
        if( isset($_SERVER['HTTP_IF_MODIFIED_SINCE']) )
        {
          // Wurdedie Datei geaendert
          $requestModTime = strtotime( $_SERVER['HTTP_IF_MODIFIED_SINCE']);
          if( ($requestModTime > 0) && ($requestModTime == $fileModTime) )
          {
            // falls ja, brauchen wir nichts zu senden, nur etwas am Request-Header zu drehen.
            header( "HTTP/1.0 304 Not Modified");
            header( "Content-Length: 0" );
            header( "Cache-Control: max-age=0, must-revalidate, private " );
            exit(0);
          }
        }
        // Aenderungsdatum setzen
        $aHeader[] = "Last-Modified: ".$fileModTimeString;
      }

      // Cache setzen
      $aHeader[] = "Cache-Control: max-age=0, must-revalidate, private";
      
      // Content-Type
      $aHeader[] = "Content-Type: " . \Seitenbau\Mimetype::getMimetype($sStreamFile);

      // Streaming oder Download
      if( $streamAction == 'download' )
      {
        // Attachment
        $aHeader[] = "Content-Disposition: attachment; filename=\"" . urlencode($sFileName) . "\"";
      }
      else
      {
        // Streaming
        $aHeader[] = "Content-Disposition: inline; filename=\"" . urlencode($sFileName) . "\"";
      }
    }
  }
  catch( Exception $e )
  {
    // Fehler
    Seitenbau_Registry::getLogger()->log(   __FILE__
                                          , __LINE__
                                          , $e->getMessage()
                                          , Zend_Log::WARN);
  }
}

/**
 * Header ausgeben
 */
foreach( $aHeader as $sNextHeader )
{
  header($sNextHeader);
}

/**
 * Ermitteltes Medium streamen
 */
if( !empty($sStreamFile) && file_exists($sStreamFile) )
{
  // Datei streamen
  $fd=fopen($sStreamFile,'rb');
  if( $fd !== false )
  {
    while( isset($fd) && $fd !== false && !feof($fd))
    {
      print fgets($fd, 4096);
    }
    fclose($fd);
    exit();
  }
}


