<?php
/**
 * Author: Heiko Schwarz <heiko.schwarz@rukzuk.com>
 * Date: 16.01.15
 * (c) 2015 rukzuk AG
 */

namespace Render\InfoStorage\WebsiteInfoStorage;

interface IWebsiteInfoStorage
{

  /**
   * @param string $websiteSettingsId
   *
   * @return array
   */
  public function getWebsiteSettings($websiteSettingsId);

  /**
   * ArrayBasedWebsiteInfoStorage constructor compatible array representation
   *
   * @return array
   */
  public function toArray();
}
