<?php
/**
 * Author: Michael Trunner <michael.trunner@rukzuk.com>
 * Date: 14.01.14
 * (c) 2014 rukzuk AG
 */

namespace Render\InfoStorage\ColorInfoStorage;

interface IColorInfoStorage
{

  /**
   * @param string $colorId
   *
   * @return string
   */
  public function getColor($colorId);

  /**
   * All color ids known by this info storage
   * @return string[]
   */
  public function getColorIds();
}
