<?php
/**
 * (c) 2014 rukzuk AG
 * page global variables
 * page id: PAGE-26918879-8c46-4d19-bf60-13b2f7ae01c9-PAGE
 */
return
array (
  'lang' => 
  array (
    0 => 
    array (
      'unitId' => 'MUNIT-025e6533-c885-4418-8ae7-a897c782b0a9-MUNIT',
      'templateUnitId' => 'MUNIT-7afafb67-119e-4e95-a538-81a140899255-MUNIT',
      'moduleId' => 'rz_root',
      'value' => 'en-US',
      'isUnitValue' => true,
    ),
  ),
)
;