<?php
/**
 * Author: Michael Trunner <michael.trunner@rukzuk.com>
 * Date: 25.11.13
 * (c) 2013 rukzuk AG
 */

namespace Render\Exceptions;

/**
 * Exception thrown when the defined module api type is not know.
 *
 * Class ModuleAPITypeNotFound
 * @package Render\Exceptions
 */
class ModuleAPITypeNotFound extends \Exception
{

}
