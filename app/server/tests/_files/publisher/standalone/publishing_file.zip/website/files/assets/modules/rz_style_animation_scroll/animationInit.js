define(['rz_style_animation_scroll/animationHelper'], function (animationHelper) {
    return {
        init: function () {
            animationHelper.initAllAnimations();
        }
    };
});