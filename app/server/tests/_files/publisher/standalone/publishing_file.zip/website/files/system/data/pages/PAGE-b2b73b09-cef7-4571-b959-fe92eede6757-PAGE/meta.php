<?php
/**
 * (c) 2014 rukzuk AG
 * page meta
 * page id: PAGE-b2b73b09-cef7-4571-b959-fe92eede6757-PAGE
 */
return
array (
  'id' => 'PAGE-b2b73b09-cef7-4571-b959-fe92eede6757-PAGE',
  'websiteId' => 'SITE-8a779fba-bd52-44ef-8c15-433af76f4504-SITE',
  'templateId' => 'TPL-f03e6c83-3534-46a7-a01b-12955d48447b-TPL',
  'name' => 'Home',
  'description' => '',
  'date' => '1411077600',
  'inNavigation' => true,
  'navigationTitle' => '',
  'mediaId' => '',
  'type' => 'page',
  'legacy' => false,
  'css' => 
  array (
    'file' => '27ad87a738ca2d7403b0cb87be63e7c4.css',
    'url' => '27ad87a738ca2d7403b0cb87be63e7c4.css?m=1434548417',
  ),
)
;