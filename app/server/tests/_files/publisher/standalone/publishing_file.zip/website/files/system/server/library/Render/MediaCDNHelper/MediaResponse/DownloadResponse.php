<?php
 /**
 * Author: Heiko Schwarz <heiko.schwarz@rukzuk.com>
 * Date: 04.02.14
 * (c) 2014 rukzuk AG
 */

namespace Render\MediaCDNHelper\MediaResponse;

class DownloadResponse extends StreamResponse
{
  protected function addContentDispositionHeader()
  {
    $this->addHeader(
        'Content-Disposition',
        'attachment; filename="'.$this->getFileNameForHeader().'"'
    );
  }
}
