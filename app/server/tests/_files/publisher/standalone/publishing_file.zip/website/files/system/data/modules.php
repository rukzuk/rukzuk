<?php
/**
 * (c) 2014 rukzuk AG
 * modules info array
 * site: SITE-8a779fba-bd52-44ef-8c15-433af76f4504-SITE
 */
return
array (
  'rz_root' => 
  array (
    'manifest' => 
    array (
      'id' => 'rz_root',
      'name' => '{"de":"Basismodul","en":"Root Module"}',
      'description' => '{"de":"Grundgerüst jedes Layout. Bietet grundlegende Einstellungen wie Sprache, Favicon und Seitentitel.","en":"Base of every layout. Offers fundamental settings like language, favicon and page title."}',
      'version' => 'dev',
      'category' => '{"de":"Basismodule","en":"Root Modules"}',
      'icon' => 'root.png',
      'moduleType' => 'root',
      'allowedChildModuleType' => '*',
      'reRenderRequired' => true,
      'apiType' => 'RootAPIv1',
      'ghostContainerMode' => 'force_off',
      'sessionRequired' => NULL,
    ),
    'codePath' => 'rz_root',
    'mainClassFilePath' => 'rz_root/rz_root.php',
    'mainClassName' => '\\Rukzuk\\Modules\\rz_root',
    'customData' => 
    array (
      'assets' => 
      array (
        'js' => 
        array (
          0 => 
          array (
            'file' => 'notlive/dyncss/absurd.js',
            'type' => 'script',
            'mode' => 'edit',
          ),
          1 => 
          array (
            'file' => 'notlive/dyncss/absurdhat.js',
            'type' => 'script',
            'mode' => 'edit',
          ),
          2 => 
          array (
            'file' => 'notlive/dyncss/dyncss.js',
            'type' => 'script',
            'mode' => 'edit',
          ),
          3 => 
          array (
            'file' => 'notlive/js/jquery.event.drag-2.2.js',
            'mode' => 'edit',
            'type' => 'script',
          ),
          4 => 
          array (
            'file' => 'notlive/js/cssAutoRefresh.js',
            'type' => 'module',
            'mode' => 'edit',
          ),
          5 => 
          array (
            'file' => 'js/wkFixTableLayout.js',
            'type' => 'script',
          ),
          6 => 
          array (
            'file' => 'notlive/js/visualStateInit.js',
            'type' => 'module',
            'mode' => 'edit',
          ),
          7 => 
          array (
            'file' => 'notlive/js/toolbar.js',
            'type' => 'script',
            'mode' => 'edit',
          ),
        ),
        'css' => 
        array (
          0 => 
          array (
            'file' => 'notlive/css/editmode.css',
            'mode' => 'edit',
          ),
          1 => 
          array (
            'file' => 'notlive/css/toolbar.css',
            'mode' => 'edit',
          ),
          2 => 
          array (
            'file' => 'css/reset.css',
          ),
          3 => 
          array (
            'file' => 'css/base.css',
          ),
        ),
      ),
    ),
    'defaultFormValues' => 
    array (
    ),
  ),
  'rz_style_padding_margin' => 
  array (
    'manifest' => 
    array (
      'id' => 'rz_style_padding_margin',
      'name' => '{"de":"Abstände","en":"Padding and Margin"}',
      'description' => '{"de":"Innen- und Außenabstände in Pixeln oder Prozent.","en":"Padding and margin in pixel or percent."}',
      'version' => 'dev',
      'category' => '10',
      'icon' => 'style-abstaende.png',
      'moduleType' => 'extension',
      'allowedChildModuleType' => '',
      'reRenderRequired' => false,
      'apiType' => 'APIv1',
      'ghostContainerMode' => 'force_off',
      'sessionRequired' => NULL,
    ),
    'codePath' => 'rz_style_padding_margin',
    'mainClassFilePath' => 'rz_style_padding_margin/rz_style_padding_margin.php',
    'mainClassName' => '\\Rukzuk\\Modules\\rz_style_padding_margin',
    'customData' => 
    array (
    ),
    'defaultFormValues' => 
    array (
    ),
  ),
  'rz_style_font' => 
  array (
    'manifest' => 
    array (
      'id' => 'rz_style_font',
      'name' => '{"de":"Schriftformat","en":"Font Style"}',
      'description' => '{"de":"Schriftart, -farbe, -größe, -auszeichnung, sowie Textausrichtung, -transformation, Zeilenhöhe und Zeichenabstand bestimmen.","en":"Define fonts and their style, color, size, letter spacing, line height or text transformation and alignment."}',
      'version' => 'dev',
      'category' => '10',
      'icon' => 'style.png',
      'moduleType' => 'extension',
      'allowedChildModuleType' => '',
      'reRenderRequired' => false,
      'apiType' => 'APIv1',
      'ghostContainerMode' => 'force_off',
      'sessionRequired' => NULL,
    ),
    'codePath' => 'rz_style_font',
    'mainClassFilePath' => 'rz_style_font/rz_style_font.php',
    'mainClassName' => '\\Rukzuk\\Modules\\rz_style_font',
    'customData' => 
    array (
      'assets' => 
      array (
        'js' => 
        array (
          0 => 
          array (
            'file' => 'notlive/fonts.js',
            'type' => 'module',
            'mode' => 'edit',
          ),
        ),
      ),
    ),
    'defaultFormValues' => 
    array (
    ),
  ),
  'rz_selector_elements' => 
  array (
    'manifest' => 
    array (
      'id' => 'rz_selector_elements',
      'name' => '{"de":"Selektor","en":"Selector"}',
      'description' => '{"de":"Zur Auswahl einzelner Elemente eines Moduls auf die sich untergeordnete Styles auswirken sollen. So können allen Modulen und Modulelementen übergeordnet oder spezifisch Styles zugewiesen werden.","en":"Select single elements of a module where subordinate styles are applied to. By doing this every module and module element can be styled supervisory and explicitly."}',
      'version' => 'dev',
      'category' => '30',
      'icon' => 'style-filter.png',
      'moduleType' => 'extension',
      'allowedChildModuleType' => 'extension',
      'reRenderRequired' => false,
      'apiType' => 'APIv1',
      'ghostContainerMode' => 'force_off',
      'sessionRequired' => NULL,
    ),
    'codePath' => 'rz_selector_elements',
    'mainClassFilePath' => 'rz_selector_elements/rz_selector_elements.php',
    'mainClassName' => '\\Rukzuk\\Modules\\rz_selector_elements',
    'customData' => 
    array (
      'i18n' => 
      array (
        'selector.other' => 
        array (
          'de' => 'Sonstige',
          'en' => 'Other',
        ),
        'selector.allChildModules' => 
        array (
          'de' => 'Alle Kindmodule',
          'en' => 'All child modules',
        ),
        'selector.allFirstLevelChildModules' => 
        array (
          'de' => 'Kindmodule der 1. Ebene',
          'en' => 'Child modules on 1st level',
        ),
        'selector.allXModules' => 
        array (
          'de' => 'Alle „{moduleName}“-Module',
          'en' => 'All “{moduleName}” modules',
        ),
      ),
      'assets' => 
      array (
        'js' => 
        array (
          0 => 
          array (
            'file' => 'notlive/selectors.js',
            'type' => 'module',
            'mode' => 'edit',
          ),
        ),
      ),
    ),
    'defaultFormValues' => 
    array (
    ),
  ),
  'rz_selector_pseudo_class' => 
  array (
    'manifest' => 
    array (
      'id' => 'rz_selector_pseudo_class',
      'name' => '{"de":"Zustandsselektor","en":"State Selector"}',
      'description' => '{"de":"Die untergeordneten Styles wirken sich abhängig vom Zustand des Moduls/Elements (Mouseover, Fokussiert, Gedrückt) aus.","en":"Subordinate styles are applied depending on the state of the module/element (mouseover, focussed, pressed)."}',
      'version' => 'dev',
      'category' => '30',
      'icon' => 'style-filter.png',
      'moduleType' => 'extension',
      'allowedChildModuleType' => 'extension',
      'reRenderRequired' => false,
      'apiType' => 'APIv1',
      'ghostContainerMode' => 'force_off',
      'sessionRequired' => NULL,
    ),
    'codePath' => 'rz_selector_pseudo_class',
    'mainClassFilePath' => 'rz_selector_pseudo_class/rz_selector_pseudo_class.php',
    'mainClassName' => '\\Rukzuk\\Modules\\rz_selector_pseudo_class',
    'customData' => 
    array (
      'i18n' => 
      array (
        'state.hover' => 
        array (
          'de' => 'Mouseover',
          'en' => 'Mouseover',
        ),
        'state.active' => 
        array (
          'de' => 'Gedrückt',
          'en' => 'Pressed',
        ),
        'state.focus' => 
        array (
          'de' => 'Fokussiert',
          'en' => 'Focused',
        ),
      ),
      'assets' => 
      array (
        'js' => 
        array (
          0 => 
          array (
            'file' => 'notlive/pseudo-class.js',
            'type' => 'module',
            'mode' => 'edit',
          ),
        ),
      ),
    ),
    'defaultFormValues' => 
    array (
    ),
  ),
  'rz_grid' => 
  array (
    'manifest' => 
    array (
      'id' => 'rz_grid',
      'name' => '{"de":"Grid","en":"Grid"}',
      'description' => '{"de":"Grundlegendes Layoutmodul welches die untergeordneten Module anhand eines Rasters verteilt. Die Anzahl der Rasterspalten sowie Zwischenräume können angegeben werden. Die Verteilung kann auch für mehrere Zeilen definiert werden.","en":"Basic layout module which arranges the subordinate modules according to the defined grid pattern. The number of grid columns and gaps can be defined. The distribution can also be set for multiple rows."}',
      'version' => 'dev',
      'category' => '{"de":" Layout","en":" Layout"}',
      'icon' => 'grid-layout.png',
      'moduleType' => 'default',
      'allowedChildModuleType' => '*',
      'reRenderRequired' => false,
      'apiType' => 'APIv1',
      'ghostContainerMode' => 'force_off',
      'sessionRequired' => NULL,
    ),
    'codePath' => 'rz_grid',
    'mainClassFilePath' => 'rz_grid/rz_grid.php',
    'mainClassName' => '\\Rukzuk\\Modules\\rz_grid',
    'customData' => 
    array (
      'assets' => 
      array (
        'js' => 
        array (
          0 => 
          array (
            'file' => 'notlive/editMode.js',
            'mode' => 'edit',
            'type' => 'module',
          ),
        ),
        'css' => 
        array (
          0 => 
          array (
            'file' => 'style.css',
          ),
          1 => 
          array (
            'file' => 'notlive/editMode.css',
            'mode' => 'edit',
          ),
        ),
      ),
      'i18n' => 
      array (
        'selector.cells' => 
        array (
          'de' => 'Zellen',
          'en' => 'Cells',
        ),
      ),
      'selectors' => 
      array (
        0 => 
        array (
          'title' => '__i18n_selector.cells',
          'selector' => '.gridElements > div',
          'enableNthTypeOf' => true,
        ),
      ),
    ),
    'defaultFormValues' => 
    array (
    ),
  ),
  'rz_style_width_height' => 
  array (
    'manifest' => 
    array (
      'id' => 'rz_style_width_height',
      'name' => '{"de":"Breite und Höhe","en":"Width and Height"}',
      'description' => '{"de":"Anpassen der Breite und Höhe in Pixeln oder Prozent.","en":"Adjust the width and height in pixel or percentage."}',
      'version' => 'dev',
      'category' => '40',
      'icon' => 'box-1.png',
      'moduleType' => 'extension',
      'allowedChildModuleType' => '',
      'reRenderRequired' => false,
      'apiType' => 'APIv1',
      'ghostContainerMode' => 'force_off',
      'sessionRequired' => NULL,
    ),
    'codePath' => 'rz_style_width_height',
    'mainClassFilePath' => 'rz_style_width_height/rz_style_width_height.php',
    'mainClassName' => '\\Rukzuk\\Modules\\rz_style_width_height',
    'customData' => 
    array (
    ),
    'defaultFormValues' => 
    array (
    ),
  ),
  'rz_svg' => 
  array (
    'manifest' => 
    array (
      'id' => 'rz_svg',
      'name' => '{"de":"SVG-Vektorgrafik","en":"SVG Vector Graphic"}',
      'description' => '{"de":"Einbindung von Vektorgrafiken im SVG-Format. Diese werden unabhängig von der Darstellungsgröße immer in optimaler Schärfe angezeigt.","en":"Embedding of SVG vector graphics. They always render in optimal sharpness, independent of the size."}',
      'version' => 'dev',
      'category' => '{"de":" Inhalt","en":" Content"}',
      'icon' => 'image.png',
      'moduleType' => 'default',
      'allowedChildModuleType' => 'extension',
      'reRenderRequired' => false,
      'apiType' => 'APIv1',
      'ghostContainerMode' => 'force_off',
      'sessionRequired' => NULL,
    ),
    'codePath' => 'rz_svg',
    'mainClassFilePath' => 'rz_svg/rz_svg.php',
    'mainClassName' => '\\Rukzuk\\Modules\\rz_svg',
    'customData' => 
    array (
      'assets' => 
      array (
        'css' => 
        array (
          0 => 
          array (
            'file' => 'style.css',
          ),
        ),
      ),
    ),
    'defaultFormValues' => 
    array (
    ),
  ),
  'rz_navigation' => 
  array (
    'manifest' => 
    array (
      'id' => 'rz_navigation',
      'name' => '{"de":"Navigation","en":"Navigation"}',
      'description' => '{"de":"Für klassische Seitennavigationen, Navigationsbäume und Sitemaps.","en":"For regular page navigation, navigation trees and sitemaps."}',
      'version' => 'dev',
      'category' => '{"de":"Navigation","en":"Navigation"}',
      'icon' => 'sitemap_color.png',
      'moduleType' => 'default',
      'allowedChildModuleType' => 'extension',
      'reRenderRequired' => false,
      'apiType' => 'APIv1',
      'ghostContainerMode' => 'force_off',
      'sessionRequired' => NULL,
    ),
    'codePath' => 'rz_navigation',
    'mainClassFilePath' => 'rz_navigation/rz_navigation.php',
    'mainClassName' => '\\Rukzuk\\Modules\\rz_navigation',
    'customData' => 
    array (
      'assets' => 
      array (
        'css' => 
        array (
          0 => 
          array (
            'file' => 'main.css',
          ),
        ),
        'js' => 
        array (
          0 => 
          array (
            'file' => 'notlive/editMode.js',
            'mode' => 'edit',
            'type' => 'module',
          ),
        ),
      ),
      'i18n' => 
      array (
        'selector.navLink' => 
        array (
          'de' => 'Alle Navigationslinks',
          'en' => 'All navigation links',
        ),
        'selector.navLinkActive' => 
        array (
          'de' => 'Aktiver Navigationslink',
          'en' => 'Active navigation link',
        ),
        'selector.navLinkCurrent' => 
        array (
          'de' => 'Aktueller Navigationslink',
          'en' => 'Current navigation link',
        ),
        'selector.navItem' => 
        array (
          'de' => 'Alle Navigationselemente',
          'en' => 'All navigation elements',
        ),
        'selector.navItemActive' => 
        array (
          'de' => 'Aktives Navigationselement',
          'en' => 'Active navigation element',
        ),
        'selector.navItemCurrent' => 
        array (
          'de' => 'Aktuelles Navigationselement',
          'en' => 'Current navigation element',
        ),
        'selector.navLevel1' => 
        array (
          'de' => 'Ebene 1',
          'en' => 'Level 1',
        ),
        'selector.navLevel2' => 
        array (
          'de' => 'Ebene 2',
          'en' => 'Level 2',
        ),
        'selector.navLevel3' => 
        array (
          'de' => 'Ebene 3',
          'en' => 'Level 3',
        ),
        'selector.navLevel4' => 
        array (
          'de' => 'Ebene 4',
          'en' => 'Level 4',
        ),
        'selector.navLevel5' => 
        array (
          'de' => 'Ebene 5',
          'en' => 'Level 5',
        ),
        'error.noPages' => 
        array (
          'de' => 'In dieser Website wurden noch keine Seiten angelegt.',
          'en' => 'This website doesn’t have pages yet.',
        ),
      ),
      'selectors' => 
      array (
        0 => 
        array (
          'title' => '__i18n_selector.navLink',
          'selector' => '.navLink',
        ),
        1 => 
        array (
          'title' => '__i18n_selector.navLinkActive',
          'selector' => '.navLink.navLinkActive',
        ),
        2 => 
        array (
          'title' => '__i18n_selector.navLinkCurrent',
          'selector' => '.navLink.navLinkCurrent',
        ),
        3 => 
        array (
          'title' => '__i18n_selector.navItem',
          'selector' => '.navItem',
          'enableNthTypeOf' => true,
        ),
        4 => 
        array (
          'title' => '__i18n_selector.navItemActive',
          'selector' => '.navItem.navItemActive',
        ),
        5 => 
        array (
          'title' => '__i18n_selector.navItemCurrent',
          'selector' => '.navItem.navItemCurrent',
        ),
        6 => 
        array (
          'title' => '__i18n_selector.navLevel1',
          'selector' => '.navLevel1',
        ),
        7 => 
        array (
          'title' => '__i18n_selector.navLevel2',
          'selector' => '.navLevel2',
        ),
        8 => 
        array (
          'title' => '__i18n_selector.navLevel3',
          'selector' => '.navLevel3',
        ),
        9 => 
        array (
          'title' => '__i18n_selector.navLevel4',
          'selector' => '.navLevel4',
        ),
        10 => 
        array (
          'title' => '__i18n_selector.navLevel5',
          'selector' => '.navLevel5',
        ),
      ),
    ),
    'defaultFormValues' => 
    array (
    ),
  ),
  'rz_style_border' => 
  array (
    'manifest' => 
    array (
      'id' => 'rz_style_border',
      'name' => '{"de":"Rahmen","en":"Border"}',
      'description' => '{"de":"Konturen mit verschiedenen Stärken, Farben und Stilen.","en":"Outlines with different widths, colors and styles."}',
      'version' => 'dev',
      'category' => '10',
      'icon' => 'style-border.png',
      'moduleType' => 'extension',
      'allowedChildModuleType' => '',
      'reRenderRequired' => false,
      'apiType' => 'APIv1',
      'ghostContainerMode' => 'force_off',
      'sessionRequired' => NULL,
    ),
    'codePath' => 'rz_style_border',
    'mainClassFilePath' => 'rz_style_border/rz_style_border.php',
    'mainClassName' => '\\Rukzuk\\Modules\\rz_style_border',
    'customData' => 
    array (
    ),
    'defaultFormValues' => 
    array (
    ),
  ),
  'rz_ghost_container' => 
  array (
    'manifest' => 
    array (
      'id' => 'rz_ghost_container',
      'name' => '{"de":"Page-Block-Bereich","en":"Page Block Area"}',
      'description' => '{"de":"Alle direkt unterhalb des Page-Block-Bereichs liegenden Module werden zu Page-Blocks. Page-Blocks kannst du auf einer Seite beliebig oft einfügen und sortieren. Bei neuen Seiten ist dieser Bereich zunächst leer.","en":"All subordinate modules of the page block area are page blocks. Page blocks can be added and sorted multiple times in every page. In new pages this area is empty."}',
      'version' => 'dev',
      'category' => '{"de":" Layout","en":" Layout"}',
      'icon' => 'folder.png',
      'moduleType' => 'default',
      'allowedChildModuleType' => '*',
      'reRenderRequired' => false,
      'apiType' => 'APIv1',
      'ghostContainerMode' => 'force_on',
      'sessionRequired' => NULL,
    ),
    'codePath' => 'rz_ghost_container',
    'mainClassFilePath' => 'rz_ghost_container/rz_ghost_container.php',
    'mainClassName' => '\\Rukzuk\\Modules\\rz_ghost_container',
    'customData' => 
    array (
      'assets' => 
      array (
        'css' => 
        array (
          0 => 
          array (
            'file' => 'style.css',
          ),
          1 => 
          array (
            'file' => 'notlive/editMode.css',
            'mode' => 'edit',
          ),
        ),
        'js' => 
        array (
          0 => 
          array (
            'file' => 'notlive/editMode.js',
            'type' => 'module',
            'mode' => 'edit',
          ),
        ),
      ),
      'i18n' => 
      array (
        'msg.emptyInEditMode' => 
        array (
          'de' => 'Alle direkt unterhalb des Page-Block-Bereichs liegenden Module werden zu Page-Blocks. Page-Blocks kannst du auf einer Seite beliebig oft einfügen und sortieren. Bei neuen Seiten ist dieser Bereich zunächst leer.',
          'en' => 'All subordinate modules of the page block area are page blocks. Page blocks can be added and sorted multiple times in every page. In new pages this area is empty.',
        ),
        'toolbar.actionMoveUp' => 
        array (
          'de' => 'Nach oben',
          'en' => 'Move up',
        ),
        'toolbar.actionMoveDown' => 
        array (
          'de' => 'Nach unten',
          'en' => 'Move down',
        ),
        'toolbar.actionInsert' => 
        array (
          'de' => 'Page-Block einfügen',
          'en' => 'Insert page block',
        ),
        'toolbar.actionDuplicate' => 
        array (
          'de' => 'Duplizieren',
          'en' => 'Clone',
        ),
        'toolbar.actionRemove' => 
        array (
          'de' => 'Löschen',
          'en' => 'Delete',
        ),
      ),
    ),
    'defaultFormValues' => 
    array (
    ),
  ),
  'rz_headline' => 
  array (
    'manifest' => 
    array (
      'id' => 'rz_headline',
      'name' => '{"de":"Überschrift","en":"Heading"}',
      'description' => '{"de":"Überschriften mit einer bestimmten semantischen Bedeutung erstellen. H1 ist die Überschrift mit der höchsten Gewichtung.","en":"Create headings with a specific semantic meaning. H1 defines the most important heading."}',
      'version' => 'dev',
      'category' => '{"de":" Inhalt","en":" Content"}',
      'icon' => 'font.png',
      'moduleType' => 'default',
      'allowedChildModuleType' => 'extension',
      'reRenderRequired' => false,
      'apiType' => 'APIv1',
      'ghostContainerMode' => 'force_off',
      'sessionRequired' => NULL,
    ),
    'codePath' => 'rz_headline',
    'mainClassFilePath' => 'rz_headline/rz_headline.php',
    'mainClassName' => '\\Rukzuk\\Modules\\rz_headline',
    'customData' => 
    array (
      'assets' => 
      array (
        'css' => 
        array (
          0 => 
          array (
            'file' => 'style.css',
          ),
        ),
        'js' => 
        array (
          0 => 
          array (
            'file' => 'notlive/headline.js',
            'type' => 'module',
            'mode' => 'edit',
          ),
        ),
      ),
      'i18n' => 
      array (
        'selector.headline1' => 
        array (
          'de' => 'Überschrift 1',
          'en' => 'Heading 1',
        ),
        'selector.headline1Text' => 
        array (
          'de' => 'Überschrift 1: nur Text',
          'en' => 'Heading 1: only text',
        ),
        'selector.headline2' => 
        array (
          'de' => 'Überschrift 2',
          'en' => 'Heading 2',
        ),
        'selector.headline2Text' => 
        array (
          'de' => 'Überschrift 2: nur Text',
          'en' => 'Heading 2: only text',
        ),
        'selector.headline3' => 
        array (
          'de' => 'Überschrift 3',
          'en' => 'Heading 3',
        ),
        'selector.headline3Text' => 
        array (
          'de' => 'Überschrift 3: nur Text',
          'en' => 'Heading 3: only text',
        ),
        'selector.headline4' => 
        array (
          'de' => 'Überschrift 4',
          'en' => 'Heading 4',
        ),
        'selector.headline4Text' => 
        array (
          'de' => 'Überschrift 4: nur Text',
          'en' => 'Heading 4: only text',
        ),
        'selector.headline5' => 
        array (
          'de' => 'Überschrift 5',
          'en' => 'Heading 5',
        ),
        'selector.headline5Text' => 
        array (
          'de' => 'Überschrift 5: nur Text',
          'en' => 'Heading 5: only text',
        ),
        'selector.headline6' => 
        array (
          'de' => 'Überschrift 6',
          'en' => 'Heading 6',
        ),
        'selector.headline6Text' => 
        array (
          'de' => 'Überschrift 6: nur Text',
          'en' => 'Heading 6: only text',
        ),
      ),
      'selectors' => 
      array (
        0 => 
        array (
          'title' => '__i18n_selector.headline1',
          'selector' => ' .headline1',
        ),
        1 => 
        array (
          'title' => '__i18n_selector.headline1Text',
          'selector' => ' .headline1Text',
        ),
        2 => 
        array (
          'title' => '__i18n_selector.headline2',
          'selector' => ' .headline2',
        ),
        3 => 
        array (
          'title' => '__i18n_selector.headline2Text',
          'selector' => ' .headline2Text',
        ),
        4 => 
        array (
          'title' => '__i18n_selector.headline3',
          'selector' => ' .headline3',
        ),
        5 => 
        array (
          'title' => '__i18n_selector.headline3Text',
          'selector' => ' .headline3Text',
        ),
        6 => 
        array (
          'title' => '__i18n_selector.headline4',
          'selector' => ' .headline4',
        ),
        7 => 
        array (
          'title' => '__i18n_selector.headline4Text',
          'selector' => ' .headline4Text',
        ),
        8 => 
        array (
          'title' => '__i18n_selector.headline5',
          'selector' => ' .headline5',
        ),
        9 => 
        array (
          'title' => '__i18n_selector.headline5Text',
          'selector' => ' .headline5Text',
        ),
        10 => 
        array (
          'title' => '__i18n_selector.headline6',
          'selector' => ' .headline6',
        ),
        11 => 
        array (
          'title' => '__i18n_selector.headline6Text',
          'selector' => ' .headline6Text',
        ),
      ),
    ),
    'defaultFormValues' => 
    array (
    ),
  ),
  'rz_textfield' => 
  array (
    'manifest' => 
    array (
      'id' => 'rz_textfield',
      'name' => '{"de":"Textfeld","en":"Text"}',
      'description' => '{"de":"Texte eingeben und bearbeiten. Erlaubte Schriftauszeichnungen und Elemente wie Links und Überschriften müssen zunächst im Modul aktiviert werden.","en":"Enter and edit text. Allowed font styles and elements as links and headlines have to be activated before used."}',
      'version' => 'dev',
      'category' => '{"de":" Inhalt","en":" Content"}',
      'icon' => 'page_white_text.png',
      'moduleType' => 'default',
      'allowedChildModuleType' => 'extension',
      'reRenderRequired' => false,
      'apiType' => 'APIv1',
      'ghostContainerMode' => 'force_off',
      'sessionRequired' => NULL,
    ),
    'codePath' => 'rz_textfield',
    'mainClassFilePath' => 'rz_textfield/rz_textfield.php',
    'mainClassName' => '\\Rukzuk\\Modules\\rz_textfield',
    'customData' => 
    array (
      'assets' => 
      array (
        'css' => 
        array (
          0 => 
          array (
            'file' => 'style.css',
          ),
        ),
        'js' => 
        array (
          0 => 
          array (
            'file' => 'notlive/textField.js',
            'type' => 'module',
            'mode' => 'edit',
          ),
        ),
      ),
      'i18n' => 
      array (
        'selector.paragraph' => 
        array (
          'de' => 'Absatz',
          'en' => 'Paragraph',
        ),
        'selector.links' => 
        array (
          'de' => 'Links',
          'en' => 'Links',
        ),
        'selector.linkExternal' => 
        array (
          'de' => 'Link extern',
          'en' => 'External link',
        ),
        'selector.lists' => 
        array (
          'de' => 'Listen',
          'en' => 'Lists',
        ),
        'selector.listItems' => 
        array (
          'de' => 'Listen-Elemente',
          'en' => 'List items',
        ),
        'selector.listUnordered' => 
        array (
          'de' => 'Ungeordnete Listen',
          'en' => 'Unordered lists',
        ),
        'selector.listUnorderedItems' => 
        array (
          'de' => 'Ungeordnete Liste: Elemente',
          'en' => 'Unordered list items',
        ),
        'selector.listOrdered' => 
        array (
          'de' => 'Geordnete Listen',
          'en' => 'Ordered lists',
        ),
        'selector.listOrderedItems' => 
        array (
          'de' => 'Geordnete Liste: Elemente',
          'en' => 'Ordered list items',
        ),
        'selector.headlines' => 
        array (
          'de' => 'Überschriften (1-6)',
          'en' => 'Headings (1-6)',
        ),
        'selector.headline1' => 
        array (
          'de' => 'Überschrift 1',
          'en' => 'Heading 1',
        ),
        'selector.headline2' => 
        array (
          'de' => 'Überschrift 2',
          'en' => 'Heading 2',
        ),
        'selector.headline3' => 
        array (
          'de' => 'Überschrift 3',
          'en' => 'Heading 3',
        ),
        'selector.headline4' => 
        array (
          'de' => 'Überschrift 4',
          'en' => 'Heading 4',
        ),
        'selector.headline5' => 
        array (
          'de' => 'Überschrift 5',
          'en' => 'Heading 5',
        ),
        'selector.headline6' => 
        array (
          'de' => 'Überschrift 6',
          'en' => 'Heading 6',
        ),
        'selector.customStyle1' => 
        array (
          'de' => 'Formatvorlage 1',
          'en' => 'Custom style 1',
        ),
        'selector.customStyle2' => 
        array (
          'de' => 'Formatvorlage 2',
          'en' => 'Custom style 2',
        ),
        'selector.customStyle3' => 
        array (
          'de' => 'Formatvorlage 3',
          'en' => 'Custom style 3',
        ),
        'selector.customStyle4' => 
        array (
          'de' => 'Formatvorlage 4',
          'en' => 'Custom style 4',
        ),
        'selector.table' => 
        array (
          'de' => 'Tabelle',
          'en' => 'Table',
        ),
        'selector.tableRow' => 
        array (
          'de' => 'Zeile',
          'en' => 'Row',
        ),
        'selector.tableColumn' => 
        array (
          'de' => 'Spalte',
          'en' => 'Column',
        ),
      ),
      'selectors' => 
      array (
        0 => 
        array (
          'title' => '__i18n_selector.paragraph',
          'selector' => '.text p',
          'enableNthTypeOf' => true,
        ),
        1 => 
        array (
          'title' => '__i18n_selector.links',
          'selector' => '.text a',
          'enableNthTypeOf' => true,
          'items' => 
          array (
            0 => 
            array (
              'title' => '__i18n_selector.linkExternal',
              'selector' => '.text a[href^="http"]',
              'enableNthTypeOf' => true,
            ),
          ),
        ),
        2 => 
        array (
          'title' => '__i18n_selector.lists',
          'selector' => '.text ul, .text ol',
          'items' => 
          array (
            0 => 
            array (
              'title' => '__i18n_selector.listItems',
              'selector' => 'div.text li',
              'enableNthTypeOf' => true,
            ),
            1 => 
            array (
              'title' => '__i18n_selector.listUnordered',
              'selector' => 'div.text ul',
              'items' => 
              array (
                0 => 
                array (
                  'title' => '__i18n_selector.listUnorderedItems',
                  'selector' => '.text ul li',
                  'enableNthTypeOf' => true,
                ),
              ),
            ),
            2 => 
            array (
              'title' => '__i18n_selector.listOrdered',
              'selector' => 'div.text ol',
              'items' => 
              array (
                0 => 
                array (
                  'title' => '__i18n_selector.listOrderedItems',
                  'selector' => '.text ol li',
                  'enableNthTypeOf' => true,
                ),
              ),
            ),
          ),
        ),
        3 => 
        array (
          'title' => '__i18n_selector.headlines',
          'selector' => '.text h1, .text h2, .text h3, .text h4, .text h5, .text h6',
          'items' => 
          array (
            0 => 
            array (
              'title' => '__i18n_selector.headline1',
              'selector' => 'div.text h1',
              'enableNthTypeOf' => true,
            ),
            1 => 
            array (
              'title' => '__i18n_selector.headline2',
              'selector' => 'div.text h2',
              'enableNthTypeOf' => true,
            ),
            2 => 
            array (
              'title' => '__i18n_selector.headline3',
              'selector' => 'div.text h3',
              'enableNthTypeOf' => true,
            ),
            3 => 
            array (
              'title' => '__i18n_selector.headline4',
              'selector' => 'div.text h4',
              'enableNthTypeOf' => true,
            ),
            4 => 
            array (
              'title' => '__i18n_selector.headline5',
              'selector' => 'div.text h5',
              'enableNthTypeOf' => true,
            ),
            5 => 
            array (
              'title' => '__i18n_selector.headline6',
              'selector' => 'div.text h6',
              'enableNthTypeOf' => true,
            ),
          ),
        ),
        4 => 
        array (
          'title' => '__i18n_selector.customStyle1',
          'selector' => '.text .rteStyle1',
        ),
        5 => 
        array (
          'title' => '__i18n_selector.customStyle2',
          'selector' => '.text .rteStyle2',
        ),
        6 => 
        array (
          'title' => '__i18n_selector.customStyle3',
          'selector' => '.text .rteStyle3',
        ),
        7 => 
        array (
          'title' => '__i18n_selector.customStyle4',
          'selector' => '.text .rteStyle4',
        ),
        8 => 
        array (
          'title' => '__i18n_selector.table',
          'selector' => '.text table',
          'items' => 
          array (
            0 => 
            array (
              'title' => '__i18n_selector.tableRow',
              'selector' => '.text tr',
              'enableNthTypeOf' => true,
            ),
            1 => 
            array (
              'title' => '__i18n_selector.tableColumn',
              'selector' => '.text td',
              'enableNthTypeOf' => true,
            ),
          ),
        ),
      ),
    ),
    'defaultFormValues' => 
    array (
    ),
  ),
  'rz_google_maps' => 
  array (
    'manifest' => 
    array (
      'id' => 'rz_google_maps',
      'name' => '{"de":"Google Maps","en":"Google Maps"}',
      'description' => '{"de":"Zeigt eine Adresse in Google Maps an.", "en":"Shows a specific address in Google Maps."}',
      'version' => 'dev',
      'category' => '{"de":"Externe Inhalte","en":"External Content"}',
      'icon' => 'google-maps.png',
      'moduleType' => 'default',
      'allowedChildModuleType' => 'extension',
      'reRenderRequired' => false,
      'apiType' => 'APIv1',
      'ghostContainerMode' => 'force_off',
      'sessionRequired' => NULL,
    ),
    'codePath' => 'rz_google_maps',
    'mainClassFilePath' => 'rz_google_maps/rz_google_maps.php',
    'mainClassName' => '\\Rukzuk\\Modules\\rz_google_maps',
    'customData' => 
    array (
      'selectors' => true,
      'assets' => 
      array (
        'css' => 
        array (
          0 => 
          array (
            'file' => 'style.css',
          ),
        ),
      ),
    ),
    'defaultFormValues' => 
    array (
    ),
  ),
  'rz_style_animation_scroll' => 
  array (
    'manifest' => 
    array (
      'id' => 'rz_style_animation_scroll',
      'name' => '{"de":"Scroll-In-Animation","en":"Scroll-In Animation"}',
      'description' => '{"de":"Animiere Module wenn sie durch Scrollen sichtbar werden.","en":"Animate modules when they become visible by scrolling the page."}',
      'version' => 'dev',
      'category' => '60',
      'icon' => 'animation.png',
      'moduleType' => 'extension',
      'allowedChildModuleType' => '',
      'reRenderRequired' => false,
      'apiType' => 'APIv1',
      'ghostContainerMode' => '',
      'sessionRequired' => NULL,
    ),
    'codePath' => 'rz_style_animation_scroll',
    'mainClassFilePath' => 'rz_style_animation_scroll/rz_style_animation_scroll.php',
    'mainClassName' => '\\Rukzuk\\Modules\\rz_style_animation_scroll',
    'customData' => 
    array (
      'assets' => 
      array (
        'css' => 
        array (
          0 => 
          array (
            'file' => 'animate.css',
          ),
          1 => 
          array (
            'file' => 'style.css',
          ),
        ),
        'js' => 
        array (
          0 => 
          array (
            'file' => 'notlive/animation.js',
            'type' => 'module',
            'mode' => 'edit',
          ),
          1 => 
          array (
            'file' => 'jquery.fracs-0.15.0.js',
            'type' => 'script',
          ),
          2 => 
          array (
            'file' => 'animationInit.js',
            'type' => 'module',
            'mode' => 'live',
          ),
        ),
      ),
      'i18n' => 
      array (
        'error.insideExtensionModule' => 
        array (
          'de' => 'Hinweis: Der Style „Scroll-In-Animation“ funktioniert nicht innerhalb eines Selektors. Bitte den Style verschieben.',
          'en' => 'Note: The style “Scroll-In-Animation” doesn\'t work inside selectors. Please move the style.',
        ),
      ),
    ),
    'defaultFormValues' => 
    array (
    ),
  ),
  'rz_image' => 
  array (
    'manifest' => 
    array (
      'id' => 'rz_image',
      'name' => '{"de":"Bild","en":"Image"}',
      'description' => '{"de":"Einbetten von Bildern und Grafiken (Dateiformate: jpg, png, gif). Bildtitel, Bildqualität und Höhe können eingestellt werden. Die Bildbreite ergibt sich vom übergeordneten Modul. Die Bildauflösung wird automatisch für die verschiedenen Endgeräte optimiert.","en":"Embedding of images and graphics (supported file formats: jpg, png, gif). Image title, quality and height can be set. The image width is determined from the superior module. The optimal image resolution will be choosen automatically depending on the device."}',
      'version' => 'dev',
      'category' => '{"de":" Inhalt","en":" Content"}',
      'icon' => 'image.png',
      'moduleType' => 'default',
      'allowedChildModuleType' => '*',
      'reRenderRequired' => false,
      'apiType' => 'APIv1',
      'ghostContainerMode' => 'force_off',
      'sessionRequired' => NULL,
    ),
    'codePath' => 'rz_image',
    'mainClassFilePath' => 'rz_image/rz_image.php',
    'mainClassName' => '\\Rukzuk\\Modules\\rz_image',
    'customData' => 
    array (
      'assets' => 
      array (
        'js' => 
        array (
          0 => 
          array (
            'file' => 'notlive/jquery.panzoom.js',
            'mode' => 'edit',
            'type' => 'module',
          ),
          1 => 
          array (
            'file' => 'notlive/jquery.mousewheel.js',
            'mode' => 'edit',
            'type' => 'module',
          ),
          2 => 
          array (
            'file' => 'notlive/editMode.js',
            'mode' => 'edit',
            'type' => 'module',
          ),
        ),
        'css' => 
        array (
          0 => 
          array (
            'file' => 'main.css',
          ),
          1 => 
          array (
            'file' => 'notlive/editMode.css',
            'mode' => 'edit',
          ),
        ),
      ),
      'i18n' => 
      array (
        'button.cropIconTitle' => 
        array (
          'de' => 'Bildausschnitt wählen',
          'en' => 'Select image section',
        ),
        'selector.imageElement' => 
        array (
          'de' => 'Bild-Element',
          'en' => 'Image element',
        ),
      ),
      'selectors' => 
      array (
        0 => 
        array (
          'title' => '__i18n_selector.imageElement',
          'selector' => 'img.imageModuleImg',
        ),
      ),
    ),
    'defaultFormValues' => 
    array (
    ),
  ),
  'rz_lightbox' => 
  array (
    'manifest' => 
    array (
      'id' => 'rz_lightbox',
      'name' => '{"de":"Lightbox","en":"Lightbox"}',
      'description' => '{"de":"Ermöglicht die Großansicht von Bildern. Alle Bilder in untergeordneten Modulen werden beim Klick bildschirmfüllend angezeigt.","en":"Enables the enlarged view of images. The lightbox opens after clicking on images of the submodules."}',
      'version' => 'dev',
      'category' => '{"de":"Bildergalerie","en":"Image gallery"}',
      'icon' => 'lightbox.png',
      'moduleType' => 'default',
      'allowedChildModuleType' => '*',
      'reRenderRequired' => false,
      'apiType' => 'APIv1',
      'ghostContainerMode' => 'force_off',
      'sessionRequired' => NULL,
    ),
    'codePath' => 'rz_lightbox',
    'mainClassFilePath' => 'rz_lightbox/rz_lightbox.php',
    'mainClassName' => '\\Rukzuk\\Modules\\rz_lightbox',
    'customData' => 
    array (
      'assets' => 
      array (
        'css' => 
        array (
          0 => 
          array (
            'file' => 'style.css',
          ),
          1 => 
          array (
            'file' => 'swipebox.css',
          ),
          2 => 
          array (
            'file' => 'notlive/editMode.css',
            'mode' => 'edit',
          ),
        ),
        'js' => 
        array (
          0 => 
          array (
            'file' => 'jquery.swipebox.js',
            'type' => 'script',
          ),
          1 => 
          array (
            'file' => 'lightboxInit.js',
            'type' => 'module',
            'mode' => 'live',
          ),
          2 => 
          array (
            'file' => 'notlive/swipebox.extended.js',
            'type' => 'module',
            'mode' => 'edit',
          ),
        ),
      ),
      'i18n' => 
      array (
        'error.noLightboxModuleInheritance' => 
        array (
          'de' => 'Dieses Modul darf sich nicht innerhalb eines anderen Lightbox-Moduls befinden.',
          'en' => 'This module may not be used inside a Lightbox module.',
        ),
        'selector.overlay' => 
        array (
          'de' => 'Overlay',
          'en' => 'Overlay',
        ),
        'selector.image' => 
        array (
          'de' => 'Bild',
          'en' => 'Image',
        ),
        'selector.close' => 
        array (
          'de' => 'Schließen-Button',
          'en' => 'Close button',
        ),
        'selector.nextButton' => 
        array (
          'de' => 'Vor-Button',
          'en' => 'Next button',
        ),
        'selector.prevButton' => 
        array (
          'de' => 'Zurück-Button',
          'en' => 'Previous button',
        ),
        'selector.caption' => 
        array (
          'de' => 'Überschrift',
          'en' => 'Caption',
        ),
        'selector.loader' => 
        array (
          'de' => 'Ladeanzeige',
          'en' => 'Loader',
        ),
      ),
      'selectors' => 
      array (
        0 => 
        array (
          'title' => '__i18n_selector.overlay',
          'selector' => '#swipebox-overlay',
        ),
        1 => 
        array (
          'title' => '__i18n_selector.image',
          'selector' => '#swipebox-overlay .slide img',
        ),
        2 => 
        array (
          'title' => '__i18n_selector.close',
          'selector' => '#swipebox-close',
        ),
        3 => 
        array (
          'title' => '__i18n_selector.nextButton',
          'selector' => '#swipebox-next',
        ),
        4 => 
        array (
          'title' => '__i18n_selector.prevButton',
          'selector' => '#swipebox-prev',
        ),
        5 => 
        array (
          'title' => '__i18n_selector.caption',
          'selector' => '#swipebox-caption',
        ),
        6 => 
        array (
          'title' => '__i18n_selector.loader',
          'selector' => '#swipebox-slider .slide',
        ),
      ),
    ),
    'defaultFormValues' => 
    array (
    ),
  ),
)
;