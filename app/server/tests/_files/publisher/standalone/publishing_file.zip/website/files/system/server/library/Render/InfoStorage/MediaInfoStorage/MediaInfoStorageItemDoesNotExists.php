<?php
/**
 * Author: Michael Trunner <michael.trunner@rukzuk.com>
 * Date: 17.12.13
 * (c) 2013 rukzuk AG
 */

namespace Render\InfoStorage\MediaInfoStorage;

class MediaInfoStorageItemDoesNotExists extends \Exception
{

}
