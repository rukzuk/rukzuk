<?php
/**
 * (c) 2014 rukzuk AG
 * page attributes
 * page id: PAGE-b2b73b09-cef7-4571-b959-fe92eede6757-PAGE
 */
return
array (
  '_name' => '',
  '_inNavigation' => true,
  '_navigationTitle' => '',
  '_date' => NULL,
  '_description' => '',
  '_mediaId' => NULL,
)
;