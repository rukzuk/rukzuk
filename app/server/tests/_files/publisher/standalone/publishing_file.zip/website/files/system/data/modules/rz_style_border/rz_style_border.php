<?php
namespace Rukzuk\Modules;

class rz_style_border extends SimpleModule { }
