<?php
/**
 * (c) 2014 rukzuk AG
 * page meta
 * page id: PAGE-a8e00fc9-7e5d-4ca6-a3f3-2a0f8ced47e8-PAGE
 */
return
array (
  'id' => 'PAGE-a8e00fc9-7e5d-4ca6-a3f3-2a0f8ced47e8-PAGE',
  'websiteId' => 'SITE-8a779fba-bd52-44ef-8c15-433af76f4504-SITE',
  'templateId' => 'TPL-f03e6c83-3534-46a7-a01b-12955d48447b-TPL',
  'name' => 'Gallery',
  'description' => '',
  'date' => '1413842400',
  'inNavigation' => true,
  'navigationTitle' => '',
  'mediaId' => '',
  'type' => 'page',
  'legacy' => false,
  'css' => 
  array (
    'file' => 'b0b44c8c16e5d7bf439bb469a19660b1.css',
    'url' => 'b0b44c8c16e5d7bf439bb469a19660b1.css?m=1434548417',
  ),
)
;