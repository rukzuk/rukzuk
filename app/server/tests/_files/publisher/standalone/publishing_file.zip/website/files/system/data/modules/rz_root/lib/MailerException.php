<?php
/**
 * Author: Heiko Schwarz <heiko.schwarz@rukzuk.com>
 * Date: 18.02.15
 * (c) 2015 rukzuk AG
 */

namespace Rukzuk\Modules;


class MailerException extends \RuntimeException
{

}