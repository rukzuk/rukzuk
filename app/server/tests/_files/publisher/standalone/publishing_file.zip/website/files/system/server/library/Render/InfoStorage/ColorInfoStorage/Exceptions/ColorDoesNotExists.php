<?php
 /**
 * Author: Heiko Schwarz <heiko.schwarz@rukzuk.com>
 * Date: 14.02.14
 * (c) 2014 rukzuk AG
 */

namespace Render\InfoStorage\ColorInfoStorage\Exceptions;

class ColorDoesNotExists extends \Exception
{

}
