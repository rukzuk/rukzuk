<?php
/**
 * Author: Michael Trunner <michael.trunner@rukzuk.com>
 * Date: 10.01.14
 * (c) 2014 rukzuk AG
 */

namespace Render\IconHelper;

interface IIconHelper
{

  /**
   * Returns the filePath to the related icon
   *
   * @param string $mediaFilePath
   *
   * @return string
   */
  public function getIconFilePath($mediaFilePath);
}
