<?php
 /**
 * Author: Heiko Schwarz <heiko.schwarz@rukzuk.com>
 * Date: 04.02.14
 * (c) 2014 rukzuk AG
 */

namespace Render\MediaCDNHelper\MediaResponse;

class ErrorResponse implements ResponseInterface
{

  /**
   * Returns the http status code
   *
   * @return int
   */
  public function getResponseCode()
  {
    return 500;
  }

  /**
   * Returns the http headers
   *
   * @return array
   */
  public function getHeaders()
  {
    return array();
  }

  /**
   * Output the requested media item
   */
  public function outputBody()
  {
    // do nothing
  }
}
