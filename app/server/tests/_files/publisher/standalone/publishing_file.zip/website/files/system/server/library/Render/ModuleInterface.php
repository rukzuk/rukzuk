<?php
 /**
 * Author: Heiko Schwarz <heiko.schwarz@rukzuk.com>
 * Date: 21.01.14
 * (c) 2014 rukzuk AG
 */

namespace Render;

interface ModuleInterface
{
  public function provideModuleData($api, $moduleInfo);

  public function provideUnitData($api, $unit, $moduleInfo);

  public function render($renderApi, $unit, $moduleInfo);

  public function css($cssApi, $unit, $moduleInfo);
}
