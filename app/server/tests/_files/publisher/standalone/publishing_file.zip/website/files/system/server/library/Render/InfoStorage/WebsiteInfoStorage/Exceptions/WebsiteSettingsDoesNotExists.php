<?php
 /**
 * Author: Heiko Schwarz <heiko.schwarz@rukzuk.com>
 * Date: 16.01.15
 * (c) 2015 rukzuk AG
 */

namespace Render\InfoStorage\WebsiteInfoStorage\Exceptions;

class WebsiteSettingsDoesNotExists extends \Exception
{

}
