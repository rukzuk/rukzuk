<?php
/**
 * (c) 2014 rukzuk AG
 * page global variables
 * page id: PAGE-09c5dddd-ce7c-4d7a-b9e1-4909f209c09f-PAGE
 */
return
array (
  'lang' => 
  array (
    0 => 
    array (
      'unitId' => 'MUNIT-b2565fbe-5361-4406-bdc4-0b88a17f5b07-MUNIT',
      'templateUnitId' => 'MUNIT-7afafb67-119e-4e95-a538-81a140899255-MUNIT',
      'moduleId' => 'rz_root',
      'value' => 'en-US',
      'isUnitValue' => true,
    ),
  ),
)
;