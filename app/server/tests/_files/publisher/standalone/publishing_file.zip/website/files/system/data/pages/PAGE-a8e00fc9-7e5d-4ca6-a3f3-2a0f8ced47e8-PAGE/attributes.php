<?php
/**
 * (c) 2014 rukzuk AG
 * page attributes
 * page id: PAGE-a8e00fc9-7e5d-4ca6-a3f3-2a0f8ced47e8-PAGE
 */
return
array (
  '_name' => '',
  '_inNavigation' => true,
  '_navigationTitle' => '',
  '_date' => NULL,
  '_description' => '',
  '_mediaId' => NULL,
)
;