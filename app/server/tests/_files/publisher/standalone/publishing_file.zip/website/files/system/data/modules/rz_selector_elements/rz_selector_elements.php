<?php
namespace Rukzuk\Modules;

class rz_selector_elements extends SimpleModule { }
