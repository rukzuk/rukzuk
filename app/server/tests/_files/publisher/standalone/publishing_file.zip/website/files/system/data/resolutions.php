<?php
/**
 * (c) 2014 rukzuk AG
 * resolutions info array
 * site: SITE-8a779fba-bd52-44ef-8c15-433af76f4504-SITE
 */
return
array (
  'enabled' => true,
  'data' => 
  array (
    0 => 
    array (
      'id' => 'res1',
      'width' => 980,
      'name' => 'Tablet',
    ),
    1 => 
    array (
      'id' => 'res2',
      'width' => 750,
      'name' => 'Smartphone',
    ),
    2 => 
    array (
      'id' => 'res3',
      'width' => 500,
      'name' => 'Smartphone small',
    ),
  ),
)
;