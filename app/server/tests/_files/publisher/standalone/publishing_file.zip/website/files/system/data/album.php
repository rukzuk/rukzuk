<?php
/**
 * (c) 2014 rukzuk AG
 * album info array
 * site: SITE-8a779fba-bd52-44ef-8c15-433af76f4504-SITE
 */
return
array (
)
;