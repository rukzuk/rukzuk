<?php
namespace Rukzuk\Modules;

class rz_selector_pseudo_class extends SimpleModule { }
