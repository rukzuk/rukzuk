<?php
/**
 * (c) 2014 rukzuk AG
 * page meta
 * page id: PAGE-26918879-8c46-4d19-bf60-13b2f7ae01c9-PAGE
 */
return
array (
  'id' => 'PAGE-26918879-8c46-4d19-bf60-13b2f7ae01c9-PAGE',
  'websiteId' => 'SITE-8a779fba-bd52-44ef-8c15-433af76f4504-SITE',
  'templateId' => 'TPL-f03e6c83-3534-46a7-a01b-12955d48447b-TPL',
  'name' => 'Menu',
  'description' => '',
  'date' => '1413842400',
  'inNavigation' => true,
  'navigationTitle' => '',
  'mediaId' => '',
  'type' => 'page',
  'legacy' => false,
  'css' => 
  array (
    'file' => 'd04d771222e63af391ff4bff620f3dbe.css',
    'url' => 'd04d771222e63af391ff4bff620f3dbe.css?m=1434548416',
  ),
)
;