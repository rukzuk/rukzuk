<?php
 /**
 * Author: Heiko Schwarz <heiko.schwarz@rukzuk.com>
 * Date: 20.01.14
 * (c) 2014 rukzuk AG
 */

namespace Render\InfoStorage\ModuleInfoStorage\Exceptions;

class ModuleDoesNotExists extends \Exception
{

}
