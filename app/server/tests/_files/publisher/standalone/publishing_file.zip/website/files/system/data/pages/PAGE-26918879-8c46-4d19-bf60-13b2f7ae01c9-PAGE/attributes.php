<?php
/**
 * (c) 2014 rukzuk AG
 * page attributes
 * page id: PAGE-26918879-8c46-4d19-bf60-13b2f7ae01c9-PAGE
 */
return
array (
  '_name' => '',
  '_inNavigation' => true,
  '_navigationTitle' => '',
  '_date' => NULL,
  '_description' => '',
  '_mediaId' => NULL,
)
;