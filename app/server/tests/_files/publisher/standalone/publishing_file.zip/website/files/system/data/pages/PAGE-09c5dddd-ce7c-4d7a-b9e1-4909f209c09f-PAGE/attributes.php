<?php
/**
 * (c) 2014 rukzuk AG
 * page attributes
 * page id: PAGE-09c5dddd-ce7c-4d7a-b9e1-4909f209c09f-PAGE
 */
return
array (
  '_name' => '',
  '_inNavigation' => true,
  '_navigationTitle' => '',
  '_date' => NULL,
  '_description' => '',
  '_mediaId' => NULL,
)
;