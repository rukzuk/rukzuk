<?php
/**
 * Author: Michael Trunner <michael.trunner@rukzuk.com>
 * Date: 07.01.14
 * (c) 2014 rukzuk AG
 */

namespace Render\MediaUrlHelper;

class UnknownOperation extends \Exception
{

}
