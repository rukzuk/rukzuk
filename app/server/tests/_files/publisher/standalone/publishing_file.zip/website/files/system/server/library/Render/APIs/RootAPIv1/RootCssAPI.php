<?php
namespace Render\APIs\RootAPIv1;

use Render\APIs\APIv1\CSSAPI;

class RootCssAPI extends CSSAPI
{

}
