<?php
/**
 * Author: Michael Trunner <michael.trunner@rukzuk.com>
 * Date: 25.11.13
 * (c) 2013 rukzuk AG
 */

namespace Render\Exceptions;

/**
 * Class ModuleNotFoundException
 *
 * Thrown when the requested module could not be found by the cms system.
 *
 * @package Render\Exceptions
 */
class ModuleNotFoundException extends \Exception
{

}
