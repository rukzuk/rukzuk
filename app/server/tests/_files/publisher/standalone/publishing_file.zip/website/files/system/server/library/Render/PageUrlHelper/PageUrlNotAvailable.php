<?php
namespace Render\PageUrlHelper;

class PageUrlNotAvailable extends \Exception
{

}
