<?php
/**
 * (c) 2014 rukzuk AG
 * colors info array
 * site: SITE-8a779fba-bd52-44ef-8c15-433af76f4504-SITE
 */
return
array (
  'COLOR-a7bf0575-55f4-42aa-b53c-b0ab2cb100c7--000000000000--COLOR' => 
  array (
    'id' => 'COLOR-a7bf0575-55f4-42aa-b53c-b0ab2cb100c7--000000000000--COLOR',
    'value' => 'rgba(255,255,255,1)',
    'name' => 'weiß',
  ),
  'COLOR-d89e3651-f4fb-4cc1-8734-de56c41c9a6d--000000000000--COLOR' => 
  array (
    'id' => 'COLOR-d89e3651-f4fb-4cc1-8734-de56c41c9a6d--000000000000--COLOR',
    'value' => 'rgba(0,0,0,1)',
    'name' => 'schwarz',
  ),
  'COLOR-56562ce6-d7a7-4fdc-8e76-d7c51587a8f1--000000000000--COLOR' => 
  array (
    'id' => 'COLOR-56562ce6-d7a7-4fdc-8e76-d7c51587a8f1--000000000000--COLOR',
    'value' => 'rgba(0,185,203,1)',
    'name' => 'blau',
  ),
  'COLOR-05524024-1f7e-4fca-a109-16328ea0b8c9--000000000000--COLOR' => 
  array (
    'id' => 'COLOR-05524024-1f7e-4fca-a109-16328ea0b8c9--000000000000--COLOR',
    'value' => 'rgba(77,77,77,1)',
    'name' => 'grau',
  ),
)
;