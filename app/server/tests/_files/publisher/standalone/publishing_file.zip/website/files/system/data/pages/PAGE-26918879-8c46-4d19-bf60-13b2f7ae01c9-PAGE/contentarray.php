<?php
/**
 * (c) 2014 rukzuk AG
 * page content
 * page id: PAGE-26918879-8c46-4d19-bf60-13b2f7ae01c9-PAGE
 */
return
array (
  'id' => 'MUNIT-025e6533-c885-4418-8ae7-a897c782b0a9-MUNIT',
  'moduleId' => 'rz_root',
  'name' => '',
  'templateUnitId' => 'MUNIT-7afafb67-119e-4e95-a538-81a140899255-MUNIT',
  'ghostContainer' => false,
  'formValues' => 
  array (
    'titlePrefix' => '',
    'titleSuffix' => ' - Cafe by the Lake',
    'lang' => 'en-US',
    'favicon' => NULL,
    'appleTouchIcon' => NULL,
    'enablePHPSession' => false,
    'debugShowPhpErrors' => false,
    'debugShowDynCssErrors' => false,
  ),
  'htmlClass' => '',
  'children' => 
  array (
    0 => 
    array (
      'id' => 'MUNIT-f56467c6-f588-4180-8e96-feb6fb5109e3-MUNIT',
      'moduleId' => 'rz_style_padding_margin',
      'name' => '',
      'templateUnitId' => 'MUNIT-399cfa86-0638-4814-a6d1-85b8ede51d1f-MUNIT',
      'ghostContainer' => false,
      'formValues' => 
      array (
        'cssEnablePadding' => 
        array (
          'type' => 'bp',
          'default' => true,
        ),
        'cssPaddingLeft' => 
        array (
          'type' => 'bp',
          'default' => '3%',
        ),
        'cssPaddingRight' => 
        array (
          'type' => 'bp',
          'default' => '3%',
        ),
        'cssPaddingTop' => 
        array (
          'type' => 'bp',
          'default' => '3%',
        ),
        'cssPaddingBottom' => 
        array (
          'type' => 'bp',
          'default' => '0px',
        ),
        'cssEnableMargin' => 
        array (
          'type' => 'bp',
          'default' => false,
        ),
        'cssMarginLeft' => 
        array (
          'type' => 'bp',
          'default' => '0px',
        ),
        'cssMarginRight' => 
        array (
          'type' => 'bp',
          'default' => '0px',
        ),
        'cssMarginTop' => 
        array (
          'type' => 'bp',
          'default' => '0px',
        ),
        'cssMarginBottom' => 
        array (
          'type' => 'bp',
          'default' => '0%',
        ),
      ),
      'htmlClass' => '',
    ),
    1 => 
    array (
      'id' => 'MUNIT-7e3eb7d1-e671-4ef4-b379-c38a2f49fcfc-MUNIT',
      'moduleId' => 'rz_style_font',
      'name' => '',
      'templateUnitId' => 'MUNIT-6e292ef7-2126-48ad-84e3-41852ebf82df-MUNIT',
      'ghostContainer' => false,
      'formValues' => 
      array (
        'cssEnableFontFamily' => 
        array (
          'type' => 'bp',
          '[object Object]' => true,
          'default' => true,
        ),
        'cssWebFontId' => 
        array (
          'type' => 'bp',
          'default' => '',
        ),
        'cssFontFamilyGoogle' => 
        array (
          'type' => 'bp',
          '[object Object]' => '',
          'default' => 'Arvo',
        ),
        'cssFontFamily' => 
        array (
          'type' => 'bp',
          'default' => 'Arial, Helvetica, sans-serif',
        ),
        'cssEnableFontStyle' => 
        array (
          'type' => 'bp',
          'default' => false,
        ),
        'cssFontWeight' => 
        array (
          'type' => 'bp',
          'default' => 400,
        ),
        'cssEnableItalic' => 
        array (
          'type' => 'bp',
          'default' => false,
        ),
        'cssEnableCaps' => 
        array (
          'type' => 'bp',
          'default' => false,
        ),
        'cssEnableFontSize' => 
        array (
          'type' => 'bp',
          '[object Object]' => true,
          'default' => true,
        ),
        'cssFontSize' => 
        array (
          'type' => 'bp',
          'default' => '16px',
        ),
        'cssEnableFontSizeVw' => 
        array (
          'type' => 'bp',
          'default' => false,
        ),
        'cssFontSizeVw' => 
        array (
          'type' => 'bp',
          'default' => '1vw',
        ),
        'cssEnableColor' => 
        array (
          'type' => 'bp',
          '[object Object]' => false,
          'default' => true,
        ),
        'cssColor' => 
        array (
          'type' => 'bp',
          'default' => 'COLOR-05524024-1f7e-4fca-a109-16328ea0b8c9--000000000000--COLOR',
        ),
        'cssEnableTextDecoration' => 
        array (
          'type' => 'bp',
          'default' => false,
        ),
        'cssEnableUnderline' => 
        array (
          'type' => 'bp',
          'default' => NULL,
        ),
        'cssEnableOverline' => 
        array (
          'type' => 'bp',
          'default' => NULL,
        ),
        'cssEnableLineThrough' => 
        array (
          'type' => 'bp',
        ),
        'cssEnableTextTransform' => 
        array (
          'type' => 'bp',
          'default' => false,
        ),
        'cssTextTransform' => 
        array (
          'type' => 'bp',
          'default' => 'uppercase',
        ),
        'cssEnableTextAlign' => 
        array (
          'type' => 'bp',
          'default' => false,
        ),
        'cssTextAlign' => 
        array (
          'type' => 'bp',
          'default' => 'left',
        ),
        'cssEnableLineHeight' => 
        array (
          'type' => 'bp',
          'default' => true,
        ),
        'cssLineHeight' => 
        array (
          'type' => 'bp',
          'default' => '140%',
        ),
        'cssEnableLetterSpacing' => 
        array (
          'type' => 'bp',
          'default' => false,
        ),
        'cssLetterSpacing' => 
        array (
          'type' => 'bp',
          'default' => '0px',
        ),
      ),
      'htmlClass' => '',
    ),
    2 => 
    array (
      'id' => 'MUNIT-dcfb1ed6-6198-437c-b84c-621fa85b84c7-MUNIT',
      'moduleId' => 'rz_selector_elements',
      'name' => '{"de":"Selektor (Links)","en":"Selector (Links)"}',
      'templateUnitId' => 'MUNIT-4d07fa1d-c34f-49fb-9a56-d1b9b5d227f4-MUNIT',
      'ghostContainer' => false,
      'formValues' => 
      array (
        'module' => 'rz_textfield',
        'selectorChooser' => '.text a',
        'nthChildEnable' => false,
        'type' => 'preset',
        'presets' => 'first-of-type',
        'customPseudoClass' => 'nth-of-type',
        'customType' => 'single',
        'singleStartIndex' => '1',
        'multipleCount' => '1',
        'allStartIndex' => '1',
        'multipleOffsetStartIndex' => '1',
        'multipleOffsetNth' => '1',
        'additionalSelector' => '.text a',
      ),
      'htmlClass' => '',
      'children' => 
      array (
        0 => 
        array (
          'id' => 'MUNIT-27d46c23-11ef-4dac-8cac-ffceec379b0c-MUNIT',
          'moduleId' => 'rz_style_font',
          'name' => '',
          'templateUnitId' => 'MUNIT-f3a7efc1-a0a4-4bb5-894b-c35a5836a88a-MUNIT',
          'ghostContainer' => false,
          'formValues' => 
          array (
            'cssEnableFontFamily' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssWebFontId' => 
            array (
              'type' => 'bp',
              'default' => '',
            ),
            'cssFontFamilyGoogle' => 
            array (
              'type' => 'bp',
              'default' => NULL,
            ),
            'cssFontFamily' => 
            array (
              'type' => 'bp',
              'default' => 'Arial, Helvetica, sans-serif',
            ),
            'cssEnableFontStyle' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssFontWeight' => 
            array (
              'type' => 'bp',
              'default' => 400,
            ),
            'cssEnableItalic' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssEnableCaps' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssEnableFontSize' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssFontSize' => 
            array (
              'type' => 'bp',
              'default' => '16px',
            ),
            'cssEnableFontSizeVw' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssFontSizeVw' => 
            array (
              'type' => 'bp',
              'default' => '1vw',
            ),
            'cssEnableColor' => 
            array (
              'type' => 'bp',
              '[object Object]' => false,
              'default' => true,
            ),
            'cssColor' => 
            array (
              'type' => 'bp',
              'default' => 'COLOR-56562ce6-d7a7-4fdc-8e76-d7c51587a8f1--000000000000--COLOR',
            ),
            'cssEnableTextDecoration' => 
            array (
              'type' => 'bp',
              '[object Object]' => true,
              'default' => false,
            ),
            'cssEnableUnderline' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssEnableOverline' => 
            array (
              'type' => 'bp',
              'default' => NULL,
            ),
            'cssEnableLineThrough' => 
            array (
              'type' => 'bp',
            ),
            'cssEnableTextTransform' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssTextTransform' => 
            array (
              'type' => 'bp',
              'default' => 'uppercase',
            ),
            'cssEnableTextAlign' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssTextAlign' => 
            array (
              'type' => 'bp',
              'default' => 'left',
            ),
            'cssEnableLineHeight' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssLineHeight' => 
            array (
              'type' => 'bp',
              'default' => '130%',
            ),
            'cssEnableLetterSpacing' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssLetterSpacing' => 
            array (
              'type' => 'bp',
              'default' => '0px',
            ),
          ),
          'htmlClass' => '',
        ),
        1 => 
        array (
          'id' => 'MUNIT-704c946f-7363-4331-99fd-1b4ee6a021ec-MUNIT',
          'moduleId' => 'rz_selector_pseudo_class',
          'name' => '{"de":"Zustandsselektor (Mouseover)","en":"State Selector (Mouseover)"}',
          'templateUnitId' => 'MUNIT-a9b3e0f0-7eec-4711-a106-9759ac4c5485-MUNIT',
          'ghostContainer' => false,
          'formValues' => 
          array (
            'pseudoClass' => 'hover',
            'additionalSelector' => ':hover',
          ),
          'htmlClass' => '',
          'children' => 
          array (
            0 => 
            array (
              'id' => 'MUNIT-87552828-d834-44b6-84ef-937362a9990c-MUNIT',
              'moduleId' => 'rz_style_font',
              'name' => '',
              'templateUnitId' => 'MUNIT-662f6e07-e7eb-499c-a3ca-201d92f07fb9-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'cssEnableFontFamily' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssWebFontId' => 
                array (
                  'type' => 'bp',
                  'default' => '',
                ),
                'cssFontFamilyGoogle' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssFontFamily' => 
                array (
                  'type' => 'bp',
                  'default' => 'Arial, Helvetica, sans-serif',
                ),
                'cssEnableFontStyle' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssFontWeight' => 
                array (
                  'type' => 'bp',
                  'default' => 400,
                ),
                'cssEnableItalic' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssEnableCaps' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssEnableFontSize' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssFontSize' => 
                array (
                  'type' => 'bp',
                  'default' => '16px',
                ),
                'cssEnableFontSizeVw' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssFontSizeVw' => 
                array (
                  'type' => 'bp',
                  'default' => '1vw',
                ),
                'cssEnableColor' => 
                array (
                  'type' => 'bp',
                  '[object Object]' => false,
                  'default' => false,
                ),
                'cssColor' => 
                array (
                  'type' => 'bp',
                  'default' => 'COLOR-56562ce6-d7a7-4fdc-8e76-d7c51587a8f1--000000000000--COLOR',
                ),
                'cssEnableTextDecoration' => 
                array (
                  'type' => 'bp',
                  '[object Object]' => true,
                  'default' => true,
                ),
                'cssEnableUnderline' => 
                array (
                  'type' => 'bp',
                  'default' => true,
                ),
                'cssEnableOverline' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssEnableLineThrough' => 
                array (
                  'type' => 'bp',
                ),
                'cssEnableTextTransform' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssTextTransform' => 
                array (
                  'type' => 'bp',
                  'default' => 'uppercase',
                ),
                'cssEnableTextAlign' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssTextAlign' => 
                array (
                  'type' => 'bp',
                  'default' => 'left',
                ),
                'cssEnableLineHeight' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssLineHeight' => 
                array (
                  'type' => 'bp',
                  'default' => '130%',
                ),
                'cssEnableLetterSpacing' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssLetterSpacing' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
              ),
              'htmlClass' => '',
            ),
          ),
        ),
      ),
    ),
    3 => 
    array (
      'id' => 'MUNIT-edd7cdc2-952f-403e-92b5-3e14ff68d3db-MUNIT',
      'moduleId' => 'rz_grid',
      'name' => '{"de":"Grid mit Maximalbreite","en":"Grid with max-width"}',
      'templateUnitId' => 'MUNIT-6688c9fb-398b-4ff4-9043-28fe50d7019a-MUNIT',
      'ghostContainer' => false,
      'formValues' => 
      array (
        'gridSize' => 12,
        'cssGridDefinition' => 
        array (
          'type' => 'bp',
          'default' => '4-4-4
12
12
12',
          'res2' => '5-2-5
12
12
12',
          'res3' => '4-4-4
12
12
12',
        ),
        'cssHSpace' => 
        array (
          'type' => 'bp',
          'default' => '3%',
        ),
        'cssVSpace' => 
        array (
          'type' => 'bp',
          'default' => '5%',
        ),
        'cssMinHeight' => 
        array (
          'type' => 'bp',
          'default' => '0%',
        ),
        'cssVerticalAlign' => 
        array (
          'type' => 'bp',
          'default' => 'top',
        ),
        'cssEnableHorizontalAlign' => true,
        'cssHorizontalAlign' => 
        array (
          'type' => 'bp',
          'default' => 'center',
        ),
      ),
      'htmlClass' => '',
      'children' => 
      array (
        0 => 
        array (
          'id' => 'MUNIT-dba4f3ed-e4eb-45a4-ab66-d98a0a99a21b-MUNIT',
          'moduleId' => 'rz_style_width_height',
          'name' => '',
          'templateUnitId' => 'MUNIT-a37f37b3-3da3-4e66-9429-48f6d071dab1-MUNIT',
          'ghostContainer' => false,
          'formValues' => 
          array (
            'cssEnableWidth' => 
            array (
              'type' => 'bp',
              'default' => true,
            ),
            'cssWidthType' => 
            array (
              'type' => 'bp',
              'default' => 'fix',
            ),
            'cssWidth' => 
            array (
              'type' => 'bp',
              'default' => '100%',
            ),
            'cssEnableMinWidth' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssMinWidth' => 
            array (
              'type' => 'bp',
              'default' => '340px',
            ),
            'cssEnableMaxWidth' => 
            array (
              'type' => 'bp',
              'default' => true,
            ),
            'cssMaxWidth' => 
            array (
              'type' => 'bp',
              'default' => '940px',
            ),
            'cssEnableHeight' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssHeightType' => 
            array (
              'type' => 'bp',
              'default' => 'fix',
            ),
            'cssHeight' => 
            array (
              'type' => 'bp',
              'default' => '50px',
            ),
            'cssOverflowY' => 
            array (
              'type' => 'bp',
              'default' => 'hidden',
            ),
            'cssMinHeight' => 
            array (
              'type' => 'bp',
              'default' => '50px',
            ),
          ),
          'htmlClass' => '',
        ),
        1 => 
        array (
          'id' => 'MUNIT-906ad505-3ed3-4e2c-a1c8-2a12ba79ed11-MUNIT',
          'moduleId' => 'rz_svg',
          'name' => 'Logo',
          'templateUnitId' => 'MUNIT-b66fcc60-f274-4016-b70d-be67c89d5a0b-MUNIT',
          'ghostContainer' => false,
          'formValues' => 
          array (
            'svg' => 'MDB-c32c5c61-a1b1-42fb-9c87-5218413c4755-MDB',
            'svgAlt' => 'Cafe by the Lake',
            'svgTitle' => '',
          ),
          'htmlClass' => '',
        ),
        2 => 
        array (
          'id' => 'MUNIT-42aa252f-c99a-4d69-84c2-f46bdf084e2a-MUNIT',
          'moduleId' => 'rz_navigation',
          'name' => '',
          'templateUnitId' => 'MUNIT-9c833bd0-88a6-42ae-a9d7-500d20e29348-MUNIT',
          'ghostContainer' => false,
          'formValues' => 
          array (
            'navStart' => NULL,
            'enableLevel1' => true,
            'cssLevel1Align' => 
            array (
              'type' => 'bp',
              'default' => 'center',
            ),
            'cssLevel1Distribution' => 
            array (
              'type' => 'bp',
              'default' => 'horizontal',
              'res3' => 'vertical',
            ),
            'cssLevel1Space' => 
            array (
              'type' => 'bp',
              'default' => '40px',
              'res3' => '11px',
            ),
            'enableLevel2' => false,
            'cssLevel2Align' => 
            array (
              'type' => 'bp',
              'default' => 'left',
            ),
            'cssLevel2Distribution' => 
            array (
              'type' => 'bp',
              'default' => 'horizontal',
            ),
            'cssLevel2Space' => 
            array (
              'type' => 'bp',
              'default' => '5px',
            ),
            'enableOnlyShowActiveItemsOfLevel2' => true,
            'enableLevel3' => false,
            'cssLevel3Align' => 
            array (
              'type' => 'bp',
              'default' => 'left',
            ),
            'cssLevel3Distribution' => 
            array (
              'type' => 'bp',
              'default' => 'horizontal',
            ),
            'cssLevel3Space' => 
            array (
              'type' => 'bp',
              'default' => '5px',
            ),
            'enableOnlyShowActiveItemsOfLevel3' => true,
            'enableLevel4' => false,
            'cssLevel4Align' => 
            array (
              'type' => 'bp',
              'default' => 'left',
            ),
            'cssLevel4Distribution' => 
            array (
              'type' => 'bp',
              'default' => 'horizontal',
            ),
            'cssLevel4Space' => 
            array (
              'type' => 'bp',
              'default' => '5px',
            ),
            'enableOnlyShowActiveItemsOfLevel4' => true,
            'enableLevel5' => false,
            'cssLevel5Align' => 
            array (
              'type' => 'bp',
              'default' => 'left',
            ),
            'cssLevel5Distribution' => 
            array (
              'type' => 'bp',
              'default' => 'horizontal',
            ),
            'cssLevel5Space' => 
            array (
              'type' => 'bp',
              'default' => '5px',
            ),
            'enableOnlyShowActiveItemsOfLevel5' => true,
          ),
          'htmlClass' => '',
          'children' => 
          array (
            0 => 
            array (
              'id' => 'MUNIT-615aaafc-c966-4a3a-bddd-a847a2aaa829-MUNIT',
              'moduleId' => 'rz_style_border',
              'name' => '',
              'templateUnitId' => 'MUNIT-faf789ae-5acb-4b9d-9c85-7968ca494867-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'cssEnableBorder' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssBorderColor' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssBorderStyle' => 
                array (
                  'type' => 'bp',
                  'default' => 'solid',
                ),
                'cssBorderWidth' => 
                array (
                  'type' => 'bp',
                  'default' => '1px',
                ),
                'cssEnableBorderTop' => 
                array (
                  'type' => 'bp',
                  'default' => true,
                ),
                'cssBorderTopColor' => 
                array (
                  'type' => 'bp',
                  'default' => 'COLOR-05524024-1f7e-4fca-a109-16328ea0b8c9--000000000000--COLOR',
                ),
                'cssBorderTopStyle' => 
                array (
                  'type' => 'bp',
                  'default' => 'solid',
                ),
                'cssBorderTopWidth' => 
                array (
                  'type' => 'bp',
                  'default' => '2px',
                ),
                'cssEnableBorderRight' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssBorderRightColor' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssBorderRightStyle' => 
                array (
                  'type' => 'bp',
                  'default' => 'solid',
                ),
                'cssBorderRightWidth' => 
                array (
                  'type' => 'bp',
                  'default' => '1px',
                ),
                'cssEnableBorderBottom' => 
                array (
                  'type' => 'bp',
                  'default' => true,
                ),
                'cssBorderBottomColor' => 
                array (
                  'type' => 'bp',
                  'default' => 'COLOR-05524024-1f7e-4fca-a109-16328ea0b8c9--000000000000--COLOR',
                ),
                'cssBorderBottomStyle' => 
                array (
                  'type' => 'bp',
                  'default' => 'solid',
                ),
                'cssBorderBottomWidth' => 
                array (
                  'type' => 'bp',
                  'default' => '2px',
                ),
                'cssEnableBorderLeft' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssBorderLeftColor' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssBorderLeftStyle' => 
                array (
                  'type' => 'bp',
                  'default' => 'solid',
                ),
                'cssBorderLeftWidth' => 
                array (
                  'type' => 'bp',
                  'default' => '1px',
                ),
              ),
              'htmlClass' => '',
            ),
            1 => 
            array (
              'id' => 'MUNIT-7d9951e8-27c6-4f7e-b230-0b9ed7c3b9dc-MUNIT',
              'moduleId' => 'rz_style_padding_margin',
              'name' => '',
              'templateUnitId' => 'MUNIT-ac5e9827-179e-483c-92b8-287b281d3d6a-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'cssEnablePadding' => 
                array (
                  'type' => 'bp',
                  'default' => true,
                ),
                'cssPaddingLeft' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssPaddingRight' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssPaddingTop' => 
                array (
                  'type' => 'bp',
                  'default' => '10px',
                ),
                'cssPaddingBottom' => 
                array (
                  'type' => 'bp',
                  'default' => '10px',
                ),
                'cssEnableMargin' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssMarginLeft' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssMarginRight' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssMarginTop' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssMarginBottom' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
              ),
              'htmlClass' => '',
            ),
            2 => 
            array (
              'id' => 'MUNIT-14139759-4a25-4ea3-84e2-1d34886e5235-MUNIT',
              'moduleId' => 'rz_style_font',
              'name' => '',
              'templateUnitId' => 'MUNIT-12197de1-15a3-4d53-bace-352b815adacc-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'cssEnableFontFamily' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssWebFontId' => 
                array (
                  'type' => 'bp',
                  'default' => '',
                ),
                'cssFontFamilyGoogle' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssFontFamily' => 
                array (
                  'type' => 'bp',
                  'default' => 'Arial, Helvetica, sans-serif',
                ),
                'cssEnableFontStyle' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssFontWeight' => 
                array (
                  'type' => 'bp',
                  'default' => 400,
                ),
                'cssEnableItalic' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssEnableCaps' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssEnableFontSize' => 
                array (
                  'type' => 'bp',
                  '[object Object]' => true,
                  'default' => true,
                  'res3' => true,
                ),
                'cssFontSize' => 
                array (
                  'type' => 'bp',
                  'default' => '18px',
                  'res3' => '16px',
                ),
                'cssEnableFontSizeVw' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssFontSizeVw' => 
                array (
                  'type' => 'bp',
                  'default' => '1vw',
                ),
                'cssEnableColor' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssColor' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssEnableTextDecoration' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssEnableUnderline' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssEnableOverline' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssEnableLineThrough' => 
                array (
                  'type' => 'bp',
                ),
                'cssEnableTextTransform' => 
                array (
                  'type' => 'bp',
                  '[object Object]' => true,
                  'default' => true,
                ),
                'cssTextTransform' => 
                array (
                  'type' => 'bp',
                  'default' => 'uppercase',
                ),
                'cssEnableTextAlign' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssTextAlign' => 
                array (
                  'type' => 'bp',
                  'default' => 'left',
                ),
                'cssEnableLineHeight' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssLineHeight' => 
                array (
                  'type' => 'bp',
                  'default' => '130%',
                ),
                'cssEnableLetterSpacing' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssLetterSpacing' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
              ),
              'htmlClass' => '',
            ),
            3 => 
            array (
              'id' => 'MUNIT-e1b06f47-1311-45b3-b936-28a6a552cc0d-MUNIT',
              'moduleId' => 'rz_selector_elements',
              'name' => '{"de":"Selektor (Aktiver Navigationslink)","en":"Selector (Active navigation link)"}',
              'templateUnitId' => 'MUNIT-32191f76-f035-43c5-8ad9-f15d8f5d9ab0-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'module' => 'rz_navigation',
                'selectorChooser' => '.navLink.navLinkActive',
                'nthChildEnable' => false,
                'type' => 'preset',
                'presets' => 'first-of-type',
                'customPseudoClass' => 'nth-of-type',
                'customType' => 'single',
                'singleStartIndex' => '1',
                'multipleCount' => '1',
                'allStartIndex' => '1',
                'multipleOffsetStartIndex' => '1',
                'multipleOffsetNth' => '1',
                'additionalSelector' => '.navLink.navLinkActive',
              ),
              'htmlClass' => '',
              'children' => 
              array (
                0 => 
                array (
                  'id' => 'MUNIT-b980fe5a-d0dc-41f1-b920-3ccf9b9cdc2c-MUNIT',
                  'moduleId' => 'rz_style_font',
                  'name' => '',
                  'templateUnitId' => 'MUNIT-fd9b02db-690e-4e33-ad38-f7d91dc320f0-MUNIT',
                  'ghostContainer' => false,
                  'formValues' => 
                  array (
                    'cssEnableFontFamily' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssWebFontId' => 
                    array (
                      'type' => 'bp',
                      'default' => '',
                    ),
                    'cssFontFamilyGoogle' => 
                    array (
                      'type' => 'bp',
                      'default' => NULL,
                    ),
                    'cssFontFamily' => 
                    array (
                      'type' => 'bp',
                      'default' => 'Arial, Helvetica, sans-serif',
                    ),
                    'cssEnableFontStyle' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssFontWeight' => 
                    array (
                      'type' => 'bp',
                      'default' => 400,
                    ),
                    'cssEnableItalic' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssEnableCaps' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssEnableFontSize' => 
                    array (
                      'type' => 'bp',
                      '[object Object]' => true,
                      'default' => false,
                      'res3' => true,
                    ),
                    'cssFontSize' => 
                    array (
                      'type' => 'bp',
                      'default' => '19px',
                      'res3' => '16px',
                    ),
                    'cssEnableFontSizeVw' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssFontSizeVw' => 
                    array (
                      'type' => 'bp',
                      'default' => '1vw',
                    ),
                    'cssEnableColor' => 
                    array (
                      'type' => 'bp',
                      '[object Object]' => false,
                      'default' => true,
                    ),
                    'cssColor' => 
                    array (
                      'type' => 'bp',
                      'default' => 'COLOR-56562ce6-d7a7-4fdc-8e76-d7c51587a8f1--000000000000--COLOR',
                    ),
                    'cssEnableTextDecoration' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssEnableUnderline' => 
                    array (
                      'type' => 'bp',
                      'default' => NULL,
                    ),
                    'cssEnableOverline' => 
                    array (
                      'type' => 'bp',
                      'default' => NULL,
                    ),
                    'cssEnableLineThrough' => 
                    array (
                      'type' => 'bp',
                    ),
                    'cssEnableTextTransform' => 
                    array (
                      'type' => 'bp',
                      '[object Object]' => true,
                      'default' => false,
                    ),
                    'cssTextTransform' => 
                    array (
                      'type' => 'bp',
                      'default' => 'uppercase',
                    ),
                    'cssEnableTextAlign' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssTextAlign' => 
                    array (
                      'type' => 'bp',
                      'default' => 'left',
                    ),
                    'cssEnableLineHeight' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssLineHeight' => 
                    array (
                      'type' => 'bp',
                      'default' => '130%',
                    ),
                    'cssEnableLetterSpacing' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssLetterSpacing' => 
                    array (
                      'type' => 'bp',
                      'default' => '0px',
                    ),
                  ),
                  'htmlClass' => '',
                ),
              ),
            ),
            4 => 
            array (
              'id' => 'MUNIT-c13e6303-be09-41e3-9b7b-c4ff3a829266-MUNIT',
              'moduleId' => 'rz_selector_elements',
              'name' => '{"de":"Selektor (Alle Navigationslinks)","en":"Selector (All navigation links)"}',
              'templateUnitId' => 'MUNIT-f362635c-4d41-482a-aeaf-c43800b2a962-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'module' => 'rz_navigation',
                'selectorChooser' => '.navLink',
                'nthChildEnable' => false,
                'type' => 'preset',
                'presets' => 'first-of-type',
                'customPseudoClass' => 'nth-of-type',
                'customType' => 'single',
                'singleStartIndex' => '1',
                'multipleCount' => '1',
                'allStartIndex' => '1',
                'multipleOffsetStartIndex' => '1',
                'multipleOffsetNth' => '1',
                'additionalSelector' => '.navLink',
              ),
              'htmlClass' => '',
              'children' => 
              array (
                0 => 
                array (
                  'id' => 'MUNIT-9ae58cac-eb92-425c-97f0-1b40de3c6dc6-MUNIT',
                  'moduleId' => 'rz_selector_pseudo_class',
                  'name' => '{"de":"Zustandsselektor (Mouseover)","en":"State Selector (Mouseover)"}',
                  'templateUnitId' => 'MUNIT-022ad9a8-d3f3-47ab-974d-2d1f1b32792e-MUNIT',
                  'ghostContainer' => false,
                  'formValues' => 
                  array (
                    'pseudoClass' => 'hover',
                    'additionalSelector' => ':hover',
                  ),
                  'htmlClass' => '',
                  'children' => 
                  array (
                    0 => 
                    array (
                      'id' => 'MUNIT-7e191426-6d85-4d92-b483-db0f7c9ad2da-MUNIT',
                      'moduleId' => 'rz_style_font',
                      'name' => '',
                      'templateUnitId' => 'MUNIT-69ea429f-f602-43c4-83a7-e7e90e62c6f3-MUNIT',
                      'ghostContainer' => false,
                      'formValues' => 
                      array (
                        'cssEnableFontFamily' => 
                        array (
                          'type' => 'bp',
                          '[object Object]' => true,
                          'default' => false,
                        ),
                        'cssWebFontId' => 
                        array (
                          'type' => 'bp',
                          'default' => '',
                        ),
                        'cssFontFamilyGoogle' => 
                        array (
                          'type' => 'bp',
                          'default' => NULL,
                        ),
                        'cssFontFamily' => 
                        array (
                          'type' => 'bp',
                          'default' => 'Arial, Helvetica, sans-serif',
                        ),
                        'cssEnableFontStyle' => 
                        array (
                          'type' => 'bp',
                          '[object Object]' => true,
                          'default' => false,
                        ),
                        'cssFontWeight' => 
                        array (
                          'type' => 'bp',
                          'default' => 400,
                        ),
                        'cssEnableItalic' => 
                        array (
                          'type' => 'bp',
                          'default' => false,
                        ),
                        'cssEnableCaps' => 
                        array (
                          'type' => 'bp',
                          'default' => false,
                        ),
                        'cssEnableFontSize' => 
                        array (
                          'type' => 'bp',
                          'default' => false,
                        ),
                        'cssFontSize' => 
                        array (
                          'type' => 'bp',
                          'default' => '16px',
                        ),
                        'cssEnableFontSizeVw' => 
                        array (
                          'type' => 'bp',
                          'default' => false,
                        ),
                        'cssFontSizeVw' => 
                        array (
                          'type' => 'bp',
                          'default' => '1vw',
                        ),
                        'cssEnableColor' => 
                        array (
                          'type' => 'bp',
                          '[object Object]' => false,
                          'default' => true,
                        ),
                        'cssColor' => 
                        array (
                          'type' => 'bp',
                          'default' => 'COLOR-d89e3651-f4fb-4cc1-8734-de56c41c9a6d--000000000000--COLOR',
                        ),
                        'cssEnableTextDecoration' => 
                        array (
                          'type' => 'bp',
                          'default' => false,
                        ),
                        'cssEnableUnderline' => 
                        array (
                          'type' => 'bp',
                          'default' => NULL,
                        ),
                        'cssEnableOverline' => 
                        array (
                          'type' => 'bp',
                          'default' => NULL,
                        ),
                        'cssEnableLineThrough' => 
                        array (
                          'type' => 'bp',
                        ),
                        'cssEnableTextTransform' => 
                        array (
                          'type' => 'bp',
                          'default' => false,
                        ),
                        'cssTextTransform' => 
                        array (
                          'type' => 'bp',
                          'default' => 'uppercase',
                        ),
                        'cssEnableTextAlign' => 
                        array (
                          'type' => 'bp',
                          'default' => false,
                        ),
                        'cssTextAlign' => 
                        array (
                          'type' => 'bp',
                          'default' => 'left',
                        ),
                        'cssEnableLineHeight' => 
                        array (
                          'type' => 'bp',
                          'default' => false,
                        ),
                        'cssLineHeight' => 
                        array (
                          'type' => 'bp',
                          'default' => '130%',
                        ),
                        'cssEnableLetterSpacing' => 
                        array (
                          'type' => 'bp',
                          'default' => false,
                        ),
                        'cssLetterSpacing' => 
                        array (
                          'type' => 'bp',
                          'default' => '0px',
                        ),
                      ),
                      'htmlClass' => '',
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        3 => 
        array (
          'id' => 'MUNIT-90ae476d-3bca-4a15-9cd7-873c2d9315a4-MUNIT',
          'moduleId' => 'rz_ghost_container',
          'name' => '',
          'templateUnitId' => 'MUNIT-ff02c0bf-c3b2-4db2-90c6-811cf289267a-MUNIT',
          'ghostContainer' => true,
          'formValues' => 
          array (
            'cssColumnCount' => 
            array (
              'type' => 'bp',
              'default' => 1,
            ),
            'cssHSpace' => 
            array (
              'type' => 'bp',
              'default' => '2%',
            ),
            'cssVSpace' => 
            array (
              'type' => 'bp',
              'default' => '5%',
            ),
          ),
          'htmlClass' => '',
          'children' => 
          array (
            0 => 
            array (
              'id' => 'MUNIT-381a581e-0096-477d-9c77-4ab24ea9af50-MUNIT',
              'moduleId' => 'rz_image',
              'name' => '',
              'templateUnitId' => 'MUNIT-444ad636-dd80-41ec-a7cf-3eb8e1d58f1e-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'imgsrc' => 'MDB-f757f5b1-d6e0-4b67-97f5-d25fc40f16ed-MDB',
                'imageAlt' => 'Breakfast',
                'imageTitle' => '',
                'cropData' => '',
                'imgHeight' => '30%',
                'enableImageQuality' => false,
                'imageQuality' => '85',
              ),
              'htmlClass' => '',
              'children' => 
              array (
                0 => 
                array (
                  'id' => 'MUNIT-1376ba71-d02d-4432-aab4-2da9cee5072e-MUNIT',
                  'moduleId' => 'rz_style_animation_scroll',
                  'name' => '',
                  'templateUnitId' => 'MUNIT-49b168b7-695d-4a6e-a738-d1db2b9a94dd-MUNIT',
                  'ghostContainer' => false,
                  'formValues' => 
                  array (
                    'cssEnableAnimation' => 
                    array (
                      'type' => 'bp',
                      'default' => 'enabled',
                    ),
                    'cssAnimationIn' => 
                    array (
                      'type' => 'bp',
                      'default' => 'fadeIn',
                    ),
                    'cssDuration' => 
                    array (
                      'type' => 'bp',
                      'default' => '750ms',
                    ),
                    'cssDelay' => 
                    array (
                      'type' => 'bp',
                      'default' => '0ms',
                    ),
                    'cssIteration' => 
                    array (
                      'type' => 'bp',
                      'default' => '1ms',
                    ),
                    'cssTrigger' => 
                    array (
                      'type' => 'bp',
                      'default' => 'visiblePart75',
                    ),
                    'cssOnlyOnce' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssVisibilityHidden' => 
                    array (
                      'type' => 'bp',
                      'default' => true,
                    ),
                    'previewAnimations' => NULL,
                  ),
                  'htmlClass' => '',
                ),
              ),
            ),
            1 => 
            array (
              'id' => 'MUNIT-5a8fb1cf-ed17-4628-816f-00cdc54d30fd-MUNIT',
              'moduleId' => 'rz_headline',
              'name' => '{"de":"Überschrift (h1)","en":"Heading (h1)"}',
              'templateUnitId' => 'MUNIT-95e1a1b7-df3d-4646-9eac-b454cc0f6215-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'text' => 'Breakfast',
                'htmlElement' => 'h1',
              ),
              'htmlClass' => '',
              'children' => 
              array (
                0 => 
                array (
                  'id' => 'MUNIT-e932aefc-d32d-4112-a58d-92856951da65-MUNIT',
                  'moduleId' => 'rz_style_font',
                  'name' => '',
                  'templateUnitId' => 'MUNIT-f44b252b-bbac-4800-8210-038c0babb8f0-MUNIT',
                  'ghostContainer' => false,
                  'formValues' => 
                  array (
                    'cssEnableFontFamily' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssWebFontId' => 
                    array (
                      'type' => 'bp',
                      'default' => '',
                    ),
                    'cssFontFamilyGoogle' => 
                    array (
                      'type' => 'bp',
                      'default' => NULL,
                    ),
                    'cssFontFamily' => 
                    array (
                      'type' => 'bp',
                      'default' => 'Arial, Helvetica, sans-serif',
                    ),
                    'cssEnableFontStyle' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssFontWeight' => 
                    array (
                      'type' => 'bp',
                      'default' => 400,
                    ),
                    'cssEnableItalic' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssEnableCaps' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssEnableFontSize' => 
                    array (
                      'type' => 'bp',
                      '[object Object]' => true,
                      'default' => true,
                      'res3' => true,
                    ),
                    'cssFontSize' => 
                    array (
                      'type' => 'bp',
                      'default' => '48px',
                      'res3' => '21px',
                    ),
                    'cssEnableFontSizeVw' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssFontSizeVw' => 
                    array (
                      'type' => 'bp',
                      'default' => '1vw',
                    ),
                    'cssEnableColor' => 
                    array (
                      'type' => 'bp',
                      '[object Object]' => false,
                      'default' => true,
                    ),
                    'cssColor' => 
                    array (
                      'type' => 'bp',
                      'default' => 'COLOR-56562ce6-d7a7-4fdc-8e76-d7c51587a8f1--000000000000--COLOR',
                    ),
                    'cssEnableTextDecoration' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssEnableUnderline' => 
                    array (
                      'type' => 'bp',
                      'default' => NULL,
                    ),
                    'cssEnableOverline' => 
                    array (
                      'type' => 'bp',
                      'default' => NULL,
                    ),
                    'cssEnableLineThrough' => 
                    array (
                      'type' => 'bp',
                    ),
                    'cssEnableTextTransform' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssTextTransform' => 
                    array (
                      'type' => 'bp',
                      'default' => 'uppercase',
                    ),
                    'cssEnableTextAlign' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssTextAlign' => 
                    array (
                      'type' => 'bp',
                      'default' => 'left',
                    ),
                    'cssEnableLineHeight' => 
                    array (
                      'type' => 'bp',
                      'default' => true,
                    ),
                    'cssLineHeight' => 
                    array (
                      'type' => 'bp',
                      'default' => '130%',
                    ),
                    'cssEnableLetterSpacing' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssLetterSpacing' => 
                    array (
                      'type' => 'bp',
                      'default' => '0px',
                    ),
                  ),
                  'htmlClass' => '',
                ),
              ),
            ),
            2 => 
            array (
              'id' => 'MUNIT-1043595a-1599-4fc0-a951-b3249b4b9f34-MUNIT',
              'moduleId' => 'rz_textfield',
              'name' => '',
              'templateUnitId' => 'MUNIT-ea5c3f4d-dbb0-4800-a455-85fb6016e90c-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'enableRteBold' => true,
                'enableRteItalic' => true,
                'enableRteUnderline' => true,
                'enableRteStrikethrough' => true,
                'enableRteSubscript' => true,
                'enableRteSuperscript' => true,
                'enableRteList' => true,
                'enableRteLink' => true,
                'enableRteTable' => true,
                'enableRteHeadline1' => false,
                'rteHeadline1Title' => 'Heading 1',
                'enableRteHeadline2' => false,
                'rteHeadline2Title' => 'Heading 2',
                'enableRteHeadline3' => false,
                'rteHeadline3Title' => 'Heading 3',
                'enableRteHeadline4' => false,
                'rteHeadline4Title' => 'Heading 4',
                'enableRteHeadline5' => false,
                'rteHeadline5Title' => 'Heading 5',
                'enableRteHeadline6' => false,
                'rteHeadline6Title' => 'Heading 6',
                'enableRteStyle1' => false,
                'rteStyle1Title' => '',
                'rteStyle1Element' => '',
                'enableRteStyle2' => false,
                'rteStyle2Title' => '',
                'rteStyle2Element' => '',
                'enableRteStyle3' => false,
                'rteStyle3Title' => '',
                'rteStyle3Element' => '',
                'enableRteStyle4' => false,
                'rteStyle4Title' => '',
                'rteStyle4Element' => '',
                'text' => '<p><b>Small Breakfast</b></p>
<p>1 cup of coffee, tea or hot chocolate, 1 pastry of your choice <em>£3.90</em></p>
<p><b><br /></b></p>
<p><b>Breakfast à la Française</b><br />1 Latte, 1 Croissant with butter and jam or honey <em>£4.90</em></p>
<p><b><br /></b></p>
<p><b>Fitness Breakfast</b><br />1 cup of eco grain coffee<br />Cereal with milk, 1 bread roll with butter and honey <em>£5.90</em></p>
<p><b><br /></b></p>
<p><b>German Style Breafast</b><br />Assorted bread rolls with butter and jam or honey <em>£3.50</em></p>
<p><b><br /></b></p>
<p><b>Schmidts Breakfast</b><br />Assorted bread rolls with butter and jam or honey, 1 boiled egg <em>£4.20</em></p>
<p><b><br /></b></p>
<p><b>Big Breakfast</b><br />1 glass of of orange juice, assorted bread rolls,<br />1 boiled egg, ham, butter, jam or honey <em>£8.90</em></p>
<p><b><br /></b></p>
<p><b>Mediterranean Breakfast</b><br />Assorted bread rolls, Serrano-Ham-Salami-Mozzarella-Platter,<br />1 boiled Ei, tomato, cucumber and olives, butter and fresh cheese <em>£9.90</em></p>
<p><b><br /></b></p>
<p><b>The Duo (for two)</b><br />Assorted bread rolls, ham-cheese-platter, butter and<br />jam or honey, 2 boiled eggs, 1 Piccolo <em>£17.80</em></p>',
              ),
              'htmlClass' => '',
            ),
            3 => 
            array (
              'id' => 'MUNIT-77c5c21c-dff4-48e4-8702-9ffd8eca44b6-MUNIT',
              'moduleId' => 'rz_image',
              'name' => '',
              'templateUnitId' => 'MUNIT-444ad636-dd80-41ec-a7cf-3eb8e1d58f1e-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'imgsrc' => 'MDB-b0dcfb0e-47c0-430f-9135-02d47b506c16-MDB',
                'imageAlt' => 'Tomato Soup',
                'imageTitle' => '',
                'cropData' => '{"zoomRatio":1,"centerXRatio":0.5,"centerYRatio":3.1877551020408164,"cropXRatio":0,"cropYRatio":0.4455345060893099,"cropWidthRatio":1,"cropHeightRatio":0.16576454668470908}',
                'imgHeight' => '30%',
                'enableImageQuality' => false,
                'imageQuality' => '85',
              ),
              'htmlClass' => '',
              'children' => 
              array (
                0 => 
                array (
                  'id' => 'MUNIT-c1fd1686-e9db-4a59-a508-6bdef0d03ca4-MUNIT',
                  'moduleId' => 'rz_style_animation_scroll',
                  'name' => '',
                  'templateUnitId' => 'MUNIT-49b168b7-695d-4a6e-a738-d1db2b9a94dd-MUNIT',
                  'ghostContainer' => false,
                  'formValues' => 
                  array (
                    'cssEnableAnimation' => 
                    array (
                      'type' => 'bp',
                      'default' => 'enabled',
                    ),
                    'cssAnimationIn' => 
                    array (
                      'type' => 'bp',
                      'default' => 'fadeIn',
                    ),
                    'cssDuration' => 
                    array (
                      'type' => 'bp',
                      'default' => '750ms',
                    ),
                    'cssDelay' => 
                    array (
                      'type' => 'bp',
                      'default' => '0ms',
                    ),
                    'cssIteration' => 
                    array (
                      'type' => 'bp',
                      'default' => '1ms',
                    ),
                    'cssTrigger' => 
                    array (
                      'type' => 'bp',
                      'default' => 'visiblePart75',
                    ),
                    'cssOnlyOnce' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssVisibilityHidden' => 
                    array (
                      'type' => 'bp',
                      'default' => true,
                    ),
                    'previewAnimations' => NULL,
                  ),
                  'htmlClass' => '',
                ),
              ),
            ),
            4 => 
            array (
              'id' => 'MUNIT-b58baa31-444a-4522-9a79-7b4915d8feb7-MUNIT',
              'moduleId' => 'rz_headline',
              'name' => '{"de":"Überschrift (h1)","en":"Heading (h1)"}',
              'templateUnitId' => 'MUNIT-95e1a1b7-df3d-4646-9eac-b454cc0f6215-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'text' => 'Starters',
                'htmlElement' => 'h1',
              ),
              'htmlClass' => '',
              'children' => 
              array (
                0 => 
                array (
                  'id' => 'MUNIT-89db89c3-14d1-4eca-904f-088d0cda557a-MUNIT',
                  'moduleId' => 'rz_style_font',
                  'name' => '',
                  'templateUnitId' => 'MUNIT-f44b252b-bbac-4800-8210-038c0babb8f0-MUNIT',
                  'ghostContainer' => false,
                  'formValues' => 
                  array (
                    'cssEnableFontFamily' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssWebFontId' => 
                    array (
                      'type' => 'bp',
                      'default' => '',
                    ),
                    'cssFontFamilyGoogle' => 
                    array (
                      'type' => 'bp',
                      'default' => NULL,
                    ),
                    'cssFontFamily' => 
                    array (
                      'type' => 'bp',
                      'default' => 'Arial, Helvetica, sans-serif',
                    ),
                    'cssEnableFontStyle' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssFontWeight' => 
                    array (
                      'type' => 'bp',
                      'default' => 400,
                    ),
                    'cssEnableItalic' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssEnableCaps' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssEnableFontSize' => 
                    array (
                      'type' => 'bp',
                      '[object Object]' => true,
                      'default' => true,
                      'res3' => true,
                    ),
                    'cssFontSize' => 
                    array (
                      'type' => 'bp',
                      'default' => '48px',
                      'res3' => '21px',
                    ),
                    'cssEnableFontSizeVw' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssFontSizeVw' => 
                    array (
                      'type' => 'bp',
                      'default' => '1vw',
                    ),
                    'cssEnableColor' => 
                    array (
                      'type' => 'bp',
                      '[object Object]' => false,
                      'default' => true,
                    ),
                    'cssColor' => 
                    array (
                      'type' => 'bp',
                      'default' => 'COLOR-56562ce6-d7a7-4fdc-8e76-d7c51587a8f1--000000000000--COLOR',
                    ),
                    'cssEnableTextDecoration' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssEnableUnderline' => 
                    array (
                      'type' => 'bp',
                      'default' => NULL,
                    ),
                    'cssEnableOverline' => 
                    array (
                      'type' => 'bp',
                      'default' => NULL,
                    ),
                    'cssEnableLineThrough' => 
                    array (
                      'type' => 'bp',
                    ),
                    'cssEnableTextTransform' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssTextTransform' => 
                    array (
                      'type' => 'bp',
                      'default' => 'uppercase',
                    ),
                    'cssEnableTextAlign' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssTextAlign' => 
                    array (
                      'type' => 'bp',
                      'default' => 'left',
                    ),
                    'cssEnableLineHeight' => 
                    array (
                      'type' => 'bp',
                      'default' => true,
                    ),
                    'cssLineHeight' => 
                    array (
                      'type' => 'bp',
                      'default' => '130%',
                    ),
                    'cssEnableLetterSpacing' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssLetterSpacing' => 
                    array (
                      'type' => 'bp',
                      'default' => '0px',
                    ),
                  ),
                  'htmlClass' => '',
                ),
              ),
            ),
            5 => 
            array (
              'id' => 'MUNIT-5ba1d6e7-53f3-496f-8a04-ad05bf4ea591-MUNIT',
              'moduleId' => 'rz_textfield',
              'name' => '',
              'templateUnitId' => 'MUNIT-ea5c3f4d-dbb0-4800-a455-85fb6016e90c-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'enableRteBold' => true,
                'enableRteItalic' => true,
                'enableRteUnderline' => true,
                'enableRteStrikethrough' => true,
                'enableRteSubscript' => true,
                'enableRteSuperscript' => true,
                'enableRteList' => true,
                'enableRteLink' => true,
                'enableRteTable' => true,
                'enableRteHeadline1' => false,
                'rteHeadline1Title' => 'Heading 1',
                'enableRteHeadline2' => false,
                'rteHeadline2Title' => 'Heading 2',
                'enableRteHeadline3' => false,
                'rteHeadline3Title' => 'Heading 3',
                'enableRteHeadline4' => false,
                'rteHeadline4Title' => 'Heading 4',
                'enableRteHeadline5' => false,
                'rteHeadline5Title' => 'Heading 5',
                'enableRteHeadline6' => false,
                'rteHeadline6Title' => 'Heading 6',
                'enableRteStyle1' => false,
                'rteStyle1Title' => '',
                'rteStyle1Element' => '',
                'enableRteStyle2' => false,
                'rteStyle2Title' => '',
                'rteStyle2Element' => '',
                'enableRteStyle3' => false,
                'rteStyle3Title' => '',
                'rteStyle3Element' => '',
                'enableRteStyle4' => false,
                'rteStyle4Title' => '',
                'rteStyle4Element' => '',
                'text' => '<p><b>Tomato Soup</b><br />with cream and crispy bread <em>£</em><em>3.90</em></p>
<p><b><br /></b></p>
<p><b>Chicken Soup</b></p>
<p>with crispy bread <em>£</em><em>3.90</em></p>
<p><b><br /></b></p>
<p><b>Goulash Soup</b><br />with bun <em>£</em><em>3.90</em></p>
<p><b><br /></b></p>
<p><b>Two Sausage</b><br />with bun <em>£</em><em>5.90</em></p>
<p><b><br /></b></p>
<p><b>Bavarian Weißwürste</b><br />with pretzel and sweet mustard <em>£</em><em>7.00</em></p>
<p><b><br /></b></p>
<p><b>Ham Roll</b><br /><em><em>£</em>4.40</em></p>
<p><b><br /></b></p>
<p><b>Cheese Bun</b></p>
<p><em><em>£</em>4.40</em></p>
<p><b><br /></b></p>
<p><b>Chicken Salad</b><br />with toast and butter <em>£</em><em>7.70</em></p>',
              ),
              'htmlClass' => '',
            ),
            6 => 
            array (
              'id' => 'MUNIT-a35745ce-1b21-45a5-ac65-b3f3cfb62a41-MUNIT',
              'moduleId' => 'rz_image',
              'name' => '',
              'templateUnitId' => 'MUNIT-444ad636-dd80-41ec-a7cf-3eb8e1d58f1e-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'imgsrc' => 'MDB-d1f964f7-b11f-4f0d-aeb2-8a58c9334421-MDB',
                'imageAlt' => '',
                'imageTitle' => '',
                'cropData' => '',
                'imgHeight' => '30%',
                'enableImageQuality' => false,
                'imageQuality' => '85',
              ),
              'htmlClass' => '',
              'children' => 
              array (
                0 => 
                array (
                  'id' => 'MUNIT-db6568b4-b311-4f03-ae3d-bf0faf27c87e-MUNIT',
                  'moduleId' => 'rz_style_animation_scroll',
                  'name' => '',
                  'templateUnitId' => 'MUNIT-49b168b7-695d-4a6e-a738-d1db2b9a94dd-MUNIT',
                  'ghostContainer' => false,
                  'formValues' => 
                  array (
                    'cssEnableAnimation' => 
                    array (
                      'type' => 'bp',
                      'default' => 'enabled',
                    ),
                    'cssAnimationIn' => 
                    array (
                      'type' => 'bp',
                      'default' => 'fadeIn',
                    ),
                    'cssDuration' => 
                    array (
                      'type' => 'bp',
                      'default' => '750ms',
                    ),
                    'cssDelay' => 
                    array (
                      'type' => 'bp',
                      'default' => '0ms',
                    ),
                    'cssIteration' => 
                    array (
                      'type' => 'bp',
                      'default' => '1ms',
                    ),
                    'cssTrigger' => 
                    array (
                      'type' => 'bp',
                      'default' => 'visiblePart75',
                    ),
                    'cssOnlyOnce' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssVisibilityHidden' => 
                    array (
                      'type' => 'bp',
                      'default' => true,
                    ),
                    'previewAnimations' => NULL,
                  ),
                  'htmlClass' => '',
                ),
              ),
            ),
            7 => 
            array (
              'id' => 'MUNIT-6ad4c3c1-7ce4-41e3-a289-1fe5ac2ebaac-MUNIT',
              'moduleId' => 'rz_headline',
              'name' => '{"de":"Überschrift (h1)","en":"Heading (h1)"}',
              'templateUnitId' => 'MUNIT-95e1a1b7-df3d-4646-9eac-b454cc0f6215-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'text' => 'Drinks',
                'htmlElement' => 'h1',
              ),
              'htmlClass' => '',
              'children' => 
              array (
                0 => 
                array (
                  'id' => 'MUNIT-3b8e44b9-bf90-4974-86c8-59a6a306d6a1-MUNIT',
                  'moduleId' => 'rz_style_font',
                  'name' => '',
                  'templateUnitId' => 'MUNIT-f44b252b-bbac-4800-8210-038c0babb8f0-MUNIT',
                  'ghostContainer' => false,
                  'formValues' => 
                  array (
                    'cssEnableFontFamily' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssWebFontId' => 
                    array (
                      'type' => 'bp',
                      'default' => '',
                    ),
                    'cssFontFamilyGoogle' => 
                    array (
                      'type' => 'bp',
                      'default' => NULL,
                    ),
                    'cssFontFamily' => 
                    array (
                      'type' => 'bp',
                      'default' => 'Arial, Helvetica, sans-serif',
                    ),
                    'cssEnableFontStyle' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssFontWeight' => 
                    array (
                      'type' => 'bp',
                      'default' => 400,
                    ),
                    'cssEnableItalic' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssEnableCaps' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssEnableFontSize' => 
                    array (
                      'type' => 'bp',
                      '[object Object]' => true,
                      'default' => true,
                      'res3' => true,
                    ),
                    'cssFontSize' => 
                    array (
                      'type' => 'bp',
                      'default' => '48px',
                      'res3' => '21px',
                    ),
                    'cssEnableFontSizeVw' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssFontSizeVw' => 
                    array (
                      'type' => 'bp',
                      'default' => '1vw',
                    ),
                    'cssEnableColor' => 
                    array (
                      'type' => 'bp',
                      '[object Object]' => false,
                      'default' => true,
                    ),
                    'cssColor' => 
                    array (
                      'type' => 'bp',
                      'default' => 'COLOR-56562ce6-d7a7-4fdc-8e76-d7c51587a8f1--000000000000--COLOR',
                    ),
                    'cssEnableTextDecoration' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssEnableUnderline' => 
                    array (
                      'type' => 'bp',
                      'default' => NULL,
                    ),
                    'cssEnableOverline' => 
                    array (
                      'type' => 'bp',
                      'default' => NULL,
                    ),
                    'cssEnableLineThrough' => 
                    array (
                      'type' => 'bp',
                    ),
                    'cssEnableTextTransform' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssTextTransform' => 
                    array (
                      'type' => 'bp',
                      'default' => 'uppercase',
                    ),
                    'cssEnableTextAlign' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssTextAlign' => 
                    array (
                      'type' => 'bp',
                      'default' => 'left',
                    ),
                    'cssEnableLineHeight' => 
                    array (
                      'type' => 'bp',
                      'default' => true,
                    ),
                    'cssLineHeight' => 
                    array (
                      'type' => 'bp',
                      'default' => '130%',
                    ),
                    'cssEnableLetterSpacing' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssLetterSpacing' => 
                    array (
                      'type' => 'bp',
                      'default' => '0px',
                    ),
                  ),
                  'htmlClass' => '',
                ),
              ),
            ),
            8 => 
            array (
              'id' => 'MUNIT-20db8301-1fd1-432e-afa4-319aec8848de-MUNIT',
              'moduleId' => 'rz_textfield',
              'name' => '',
              'templateUnitId' => 'MUNIT-ea5c3f4d-dbb0-4800-a455-85fb6016e90c-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'enableRteBold' => true,
                'enableRteItalic' => true,
                'enableRteUnderline' => true,
                'enableRteStrikethrough' => true,
                'enableRteSubscript' => true,
                'enableRteSuperscript' => true,
                'enableRteList' => true,
                'enableRteLink' => true,
                'enableRteTable' => true,
                'enableRteHeadline1' => false,
                'rteHeadline1Title' => 'Heading 1',
                'enableRteHeadline2' => false,
                'rteHeadline2Title' => 'Heading 2',
                'enableRteHeadline3' => false,
                'rteHeadline3Title' => 'Heading 3',
                'enableRteHeadline4' => false,
                'rteHeadline4Title' => 'Heading 4',
                'enableRteHeadline5' => false,
                'rteHeadline5Title' => 'Heading 5',
                'enableRteHeadline6' => false,
                'rteHeadline6Title' => 'Heading 6',
                'enableRteStyle1' => false,
                'rteStyle1Title' => '',
                'rteStyle1Element' => '',
                'enableRteStyle2' => false,
                'rteStyle2Title' => '',
                'rteStyle2Element' => '',
                'enableRteStyle3' => false,
                'rteStyle3Title' => '',
                'rteStyle3Element' => '',
                'enableRteStyle4' => false,
                'rteStyle4Title' => '',
                'rteStyle4Element' => '',
                'text' => '<p><b>Cup of organic coffee</b><br />with milk vanilla foam <em>£</em><em>2.30</em></p>
<p><b><br /></b></p>
<p><b>Indian Chai of green or black tea</b><br />with spices and soy milk <em>£</em><em>3.30</em></p>
<p><b><br /></b></p>
<p><b>Glass of Darjeeling tea</b><br />with lemon or milk  <em>£</em><em>2.30</em></p>
<p><b><br /></b></p>
<p><b>Pot of loose tea</b><br />Choose from 17 different black and green teas <em>£</em><em>4.90</em></p>
<p><b><br /></b></p>
<p><b>Glass fruit, peppermint, chamomile, rose hips or herbal tea</b></p>
<p><em><em>£</em>2.30</em></p>
<p><b><br /></b></p>
<p><b>Cappuccino with milk</b></p>
<p><em><em>£</em>2.60</em></p>
<p><b><br /></b></p>
<p><b>Cappuccino with cream</b></p>
<p><em><em>£</em>2.60</em></p>
<p><em><br /></em></p>
<p><b>Soy Cappuccino</b></p>
<p><em><em>£</em>2.80</em></p>
<p><b><br /></b></p>
<p><b>Espresso</b></p>
<p><em><em>£</em>2.20</em></p>',
              ),
              'htmlClass' => '',
            ),
          ),
        ),
        4 => 
        array (
          'id' => 'MUNIT-b73d1a01-178d-4fdf-83af-69a6ed772583-MUNIT',
          'moduleId' => 'rz_textfield',
          'name' => 'Footer',
          'templateUnitId' => 'MUNIT-e1a6ef07-576c-4943-bfa0-650790a62ba2-MUNIT',
          'ghostContainer' => false,
          'formValues' => 
          array (
            'enableRteBold' => false,
            'enableRteItalic' => false,
            'enableRteUnderline' => false,
            'enableRteStrikethrough' => false,
            'enableRteSubscript' => false,
            'enableRteSuperscript' => false,
            'enableRteList' => false,
            'enableRteLink' => true,
            'enableRteTable' => false,
            'enableRteHeadline1' => false,
            'rteHeadline1Title' => 'Heading 1',
            'enableRteHeadline2' => false,
            'rteHeadline2Title' => 'Heading 2',
            'enableRteHeadline3' => false,
            'rteHeadline3Title' => 'Heading 3',
            'enableRteHeadline4' => false,
            'rteHeadline4Title' => 'Heading 4',
            'enableRteHeadline5' => false,
            'rteHeadline5Title' => 'Heading 5',
            'enableRteHeadline6' => false,
            'rteHeadline6Title' => 'Heading 6',
            'enableRteStyle1' => false,
            'rteStyle1Title' => '',
            'rteStyle1Element' => '',
            'enableRteStyle2' => false,
            'rteStyle2Title' => '',
            'rteStyle2Element' => '',
            'enableRteStyle3' => false,
            'rteStyle3Title' => '',
            'rteStyle3Element' => '',
            'enableRteStyle4' => false,
            'rteStyle4Title' => '',
            'rteStyle4Element' => '',
            'text' => '<p>© Café by the Lake – pictures by <a href="http://www.johanneselze.de/" target="_blank" data-cms-link="http://www.johanneselze.de/" data-cms-link-type="external">Johannes Elze</a> – made with <a href="https://rukzuk.com/" target="_blank" title="rukzuk - web design platform" data-cms-link="https://rukzuk.com/" data-cms-link-type="external">rukzuk</a></p>',
          ),
          'htmlClass' => '',
          'children' => 
          array (
            0 => 
            array (
              'id' => 'MUNIT-9b29c591-1c56-40ad-b920-b4627eeaedc4-MUNIT',
              'moduleId' => 'rz_style_border',
              'name' => '',
              'templateUnitId' => 'MUNIT-7cb375b2-bb3b-4984-a2da-46a7bf6f182f-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'cssEnableBorder' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssBorderColor' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssBorderStyle' => 
                array (
                  'type' => 'bp',
                  'default' => 'solid',
                ),
                'cssBorderWidth' => 
                array (
                  'type' => 'bp',
                  'default' => '1px',
                ),
                'cssEnableBorderTop' => 
                array (
                  'type' => 'bp',
                  'default' => true,
                ),
                'cssBorderTopColor' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssBorderTopStyle' => 
                array (
                  'type' => 'bp',
                  'default' => 'solid',
                ),
                'cssBorderTopWidth' => 
                array (
                  'type' => 'bp',
                  'default' => '2px',
                ),
                'cssEnableBorderRight' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssBorderRightColor' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssBorderRightStyle' => 
                array (
                  'type' => 'bp',
                  'default' => 'solid',
                ),
                'cssBorderRightWidth' => 
                array (
                  'type' => 'bp',
                  'default' => '1px',
                ),
                'cssEnableBorderBottom' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssBorderBottomColor' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssBorderBottomStyle' => 
                array (
                  'type' => 'bp',
                  'default' => 'solid',
                ),
                'cssBorderBottomWidth' => 
                array (
                  'type' => 'bp',
                  'default' => '1px',
                ),
                'cssEnableBorderLeft' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssBorderLeftColor' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssBorderLeftStyle' => 
                array (
                  'type' => 'bp',
                  'default' => 'solid',
                ),
                'cssBorderLeftWidth' => 
                array (
                  'type' => 'bp',
                  'default' => '1px',
                ),
              ),
              'htmlClass' => '',
            ),
            1 => 
            array (
              'id' => 'MUNIT-93c5bcb4-df5f-481b-a82f-c2ce6250d1d7-MUNIT',
              'moduleId' => 'rz_style_font',
              'name' => '',
              'templateUnitId' => 'MUNIT-69d7ec5d-9516-4e3f-ab1a-1711c8cfbe21-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'cssEnableFontFamily' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssWebFontId' => 
                array (
                  'type' => 'bp',
                  'default' => '',
                ),
                'cssFontFamilyGoogle' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssFontFamily' => 
                array (
                  'type' => 'bp',
                  'default' => 'Arial, Helvetica, sans-serif',
                ),
                'cssEnableFontStyle' => 
                array (
                  'type' => 'bp',
                  '[object Object]' => true,
                  'default' => false,
                ),
                'cssFontWeight' => 
                array (
                  'type' => 'bp',
                  'default' => 400,
                ),
                'cssEnableItalic' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssEnableCaps' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssEnableFontSize' => 
                array (
                  'type' => 'bp',
                  '[object Object]' => true,
                  'default' => true,
                ),
                'cssFontSize' => 
                array (
                  'type' => 'bp',
                  'default' => '14px',
                ),
                'cssEnableFontSizeVw' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssFontSizeVw' => 
                array (
                  'type' => 'bp',
                  'default' => '1vw',
                ),
                'cssEnableColor' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssColor' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssEnableTextDecoration' => 
                array (
                  'type' => 'bp',
                  '[object Object]' => true,
                  'default' => false,
                ),
                'cssEnableUnderline' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssEnableOverline' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssEnableLineThrough' => 
                array (
                  'type' => 'bp',
                ),
                'cssEnableTextTransform' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssTextTransform' => 
                array (
                  'type' => 'bp',
                  'default' => 'uppercase',
                ),
                'cssEnableTextAlign' => 
                array (
                  'type' => 'bp',
                  'default' => true,
                ),
                'cssTextAlign' => 
                array (
                  'type' => 'bp',
                  'default' => 'right',
                ),
                'cssEnableLineHeight' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssLineHeight' => 
                array (
                  'type' => 'bp',
                  'default' => '130%',
                ),
                'cssEnableLetterSpacing' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssLetterSpacing' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
              ),
              'htmlClass' => '',
            ),
            2 => 
            array (
              'id' => 'MUNIT-640d8596-5368-481a-a73d-db88bce1e6f3-MUNIT',
              'moduleId' => 'rz_style_padding_margin',
              'name' => '',
              'templateUnitId' => 'MUNIT-704fa635-4cb7-49bb-94a1-87fc29c01832-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'cssEnablePadding' => 
                array (
                  'type' => 'bp',
                  'default' => true,
                ),
                'cssPaddingLeft' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssPaddingRight' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssPaddingTop' => 
                array (
                  'type' => 'bp',
                  'default' => '6px',
                ),
                'cssPaddingBottom' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssEnableMargin' => 
                array (
                  'type' => 'bp',
                  'default' => true,
                ),
                'cssMarginLeft' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssMarginRight' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssMarginTop' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssMarginBottom' => 
                array (
                  'type' => 'bp',
                  'default' => '31px',
                ),
              ),
              'htmlClass' => '',
            ),
          ),
        ),
      ),
    ),
  ),
)
;