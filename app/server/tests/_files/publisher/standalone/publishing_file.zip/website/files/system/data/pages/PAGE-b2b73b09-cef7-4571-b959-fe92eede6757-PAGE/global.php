<?php
/**
 * (c) 2014 rukzuk AG
 * page global variables
 * page id: PAGE-b2b73b09-cef7-4571-b959-fe92eede6757-PAGE
 */
return
array (
  'lang' => 
  array (
    0 => 
    array (
      'unitId' => 'MUNIT-cebde8b8-a113-43ff-8725-7fa7947f4059-MUNIT',
      'templateUnitId' => 'MUNIT-7afafb67-119e-4e95-a538-81a140899255-MUNIT',
      'moduleId' => 'rz_root',
      'value' => 'en-US',
      'isUnitValue' => true,
    ),
  ),
)
;