<?php
/**
 * Author: Michael Trunner <michael.trunner@rukzuk.com>
 * Date: 10.01.14
 * (c) 2014 rukzuk AG
 */

namespace Render\APIs\APIv1;

class MediaItemNotFoundException extends MediaException
{

  public function __construct()
  {
    parent::__construct('Media item not found');
  }
}
