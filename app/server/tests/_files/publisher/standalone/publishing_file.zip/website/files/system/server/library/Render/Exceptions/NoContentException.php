<?php
/**
 * Author: Michael Trunner <michael.trunner@rukzuk.com>
 * Date: 26.11.13
 * (c) 2013 rukzuk AG
 */

namespace Render\Exceptions;

/**
 * Class NoContentException
 *
 * Thrown when the NodeFactory gets an empty content array.
 *
 * @package Render\Exceptions
 */
class NoContentException extends \Exception
{

}
