<?php
/**
 * (c) 2014 rukzuk AG
 * page content
 * page id: PAGE-a8e00fc9-7e5d-4ca6-a3f3-2a0f8ced47e8-PAGE
 */
return
array (
  'id' => 'MUNIT-efd4db7a-28c0-4ee1-aa7a-562188a8ff2f-MUNIT',
  'moduleId' => 'rz_root',
  'name' => '',
  'templateUnitId' => 'MUNIT-7afafb67-119e-4e95-a538-81a140899255-MUNIT',
  'ghostContainer' => false,
  'formValues' => 
  array (
    'titlePrefix' => '',
    'titleSuffix' => ' - Cafe by the Lake',
    'lang' => 'en-US',
    'favicon' => NULL,
    'appleTouchIcon' => NULL,
    'enablePHPSession' => false,
    'debugShowPhpErrors' => false,
    'debugShowDynCssErrors' => false,
  ),
  'htmlClass' => '',
  'children' => 
  array (
    0 => 
    array (
      'id' => 'MUNIT-719bc9ba-c366-485f-a828-163d0b2be91f-MUNIT',
      'moduleId' => 'rz_style_padding_margin',
      'name' => '',
      'templateUnitId' => 'MUNIT-399cfa86-0638-4814-a6d1-85b8ede51d1f-MUNIT',
      'ghostContainer' => false,
      'formValues' => 
      array (
        'cssEnablePadding' => 
        array (
          'type' => 'bp',
          'default' => true,
        ),
        'cssPaddingLeft' => 
        array (
          'type' => 'bp',
          'default' => '3%',
        ),
        'cssPaddingRight' => 
        array (
          'type' => 'bp',
          'default' => '3%',
        ),
        'cssPaddingTop' => 
        array (
          'type' => 'bp',
          'default' => '3%',
        ),
        'cssPaddingBottom' => 
        array (
          'type' => 'bp',
          'default' => '0px',
        ),
        'cssEnableMargin' => 
        array (
          'type' => 'bp',
          'default' => false,
        ),
        'cssMarginLeft' => 
        array (
          'type' => 'bp',
          'default' => '0px',
        ),
        'cssMarginRight' => 
        array (
          'type' => 'bp',
          'default' => '0px',
        ),
        'cssMarginTop' => 
        array (
          'type' => 'bp',
          'default' => '0px',
        ),
        'cssMarginBottom' => 
        array (
          'type' => 'bp',
          'default' => '0%',
        ),
      ),
      'htmlClass' => '',
    ),
    1 => 
    array (
      'id' => 'MUNIT-eeee824d-0208-46de-adfa-b224390fe2f5-MUNIT',
      'moduleId' => 'rz_style_font',
      'name' => '',
      'templateUnitId' => 'MUNIT-6e292ef7-2126-48ad-84e3-41852ebf82df-MUNIT',
      'ghostContainer' => false,
      'formValues' => 
      array (
        'cssEnableFontFamily' => 
        array (
          'type' => 'bp',
          '[object Object]' => true,
          'default' => true,
        ),
        'cssWebFontId' => 
        array (
          'type' => 'bp',
          'default' => '',
        ),
        'cssFontFamilyGoogle' => 
        array (
          'type' => 'bp',
          '[object Object]' => '',
          'default' => 'Arvo',
        ),
        'cssFontFamily' => 
        array (
          'type' => 'bp',
          'default' => 'Arial, Helvetica, sans-serif',
        ),
        'cssEnableFontStyle' => 
        array (
          'type' => 'bp',
          'default' => false,
        ),
        'cssFontWeight' => 
        array (
          'type' => 'bp',
          'default' => 400,
        ),
        'cssEnableItalic' => 
        array (
          'type' => 'bp',
          'default' => false,
        ),
        'cssEnableCaps' => 
        array (
          'type' => 'bp',
          'default' => false,
        ),
        'cssEnableFontSize' => 
        array (
          'type' => 'bp',
          '[object Object]' => true,
          'default' => true,
        ),
        'cssFontSize' => 
        array (
          'type' => 'bp',
          'default' => '16px',
        ),
        'cssEnableFontSizeVw' => 
        array (
          'type' => 'bp',
          'default' => false,
        ),
        'cssFontSizeVw' => 
        array (
          'type' => 'bp',
          'default' => '1vw',
        ),
        'cssEnableColor' => 
        array (
          'type' => 'bp',
          '[object Object]' => false,
          'default' => true,
        ),
        'cssColor' => 
        array (
          'type' => 'bp',
          'default' => 'COLOR-05524024-1f7e-4fca-a109-16328ea0b8c9--000000000000--COLOR',
        ),
        'cssEnableTextDecoration' => 
        array (
          'type' => 'bp',
          'default' => false,
        ),
        'cssEnableUnderline' => 
        array (
          'type' => 'bp',
          'default' => NULL,
        ),
        'cssEnableOverline' => 
        array (
          'type' => 'bp',
          'default' => NULL,
        ),
        'cssEnableLineThrough' => 
        array (
          'type' => 'bp',
        ),
        'cssEnableTextTransform' => 
        array (
          'type' => 'bp',
          'default' => false,
        ),
        'cssTextTransform' => 
        array (
          'type' => 'bp',
          'default' => 'uppercase',
        ),
        'cssEnableTextAlign' => 
        array (
          'type' => 'bp',
          'default' => false,
        ),
        'cssTextAlign' => 
        array (
          'type' => 'bp',
          'default' => 'left',
        ),
        'cssEnableLineHeight' => 
        array (
          'type' => 'bp',
          'default' => true,
        ),
        'cssLineHeight' => 
        array (
          'type' => 'bp',
          'default' => '140%',
        ),
        'cssEnableLetterSpacing' => 
        array (
          'type' => 'bp',
          'default' => false,
        ),
        'cssLetterSpacing' => 
        array (
          'type' => 'bp',
          'default' => '0px',
        ),
      ),
      'htmlClass' => '',
    ),
    2 => 
    array (
      'id' => 'MUNIT-d120d462-df18-4770-b418-8949105fe5ff-MUNIT',
      'moduleId' => 'rz_selector_elements',
      'name' => '{"de":"Selektor (Links)","en":"Selector (Links)"}',
      'templateUnitId' => 'MUNIT-4d07fa1d-c34f-49fb-9a56-d1b9b5d227f4-MUNIT',
      'ghostContainer' => false,
      'formValues' => 
      array (
        'module' => 'rz_textfield',
        'selectorChooser' => '.text a',
        'nthChildEnable' => false,
        'type' => 'preset',
        'presets' => 'first-of-type',
        'customPseudoClass' => 'nth-of-type',
        'customType' => 'single',
        'singleStartIndex' => '1',
        'multipleCount' => '1',
        'allStartIndex' => '1',
        'multipleOffsetStartIndex' => '1',
        'multipleOffsetNth' => '1',
        'additionalSelector' => '.text a',
      ),
      'htmlClass' => '',
      'children' => 
      array (
        0 => 
        array (
          'id' => 'MUNIT-b09370de-23f0-483e-8d83-9de474a8c825-MUNIT',
          'moduleId' => 'rz_style_font',
          'name' => '',
          'templateUnitId' => 'MUNIT-f3a7efc1-a0a4-4bb5-894b-c35a5836a88a-MUNIT',
          'ghostContainer' => false,
          'formValues' => 
          array (
            'cssEnableFontFamily' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssWebFontId' => 
            array (
              'type' => 'bp',
              'default' => '',
            ),
            'cssFontFamilyGoogle' => 
            array (
              'type' => 'bp',
              'default' => NULL,
            ),
            'cssFontFamily' => 
            array (
              'type' => 'bp',
              'default' => 'Arial, Helvetica, sans-serif',
            ),
            'cssEnableFontStyle' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssFontWeight' => 
            array (
              'type' => 'bp',
              'default' => 400,
            ),
            'cssEnableItalic' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssEnableCaps' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssEnableFontSize' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssFontSize' => 
            array (
              'type' => 'bp',
              'default' => '16px',
            ),
            'cssEnableFontSizeVw' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssFontSizeVw' => 
            array (
              'type' => 'bp',
              'default' => '1vw',
            ),
            'cssEnableColor' => 
            array (
              'type' => 'bp',
              '[object Object]' => false,
              'default' => true,
            ),
            'cssColor' => 
            array (
              'type' => 'bp',
              'default' => 'COLOR-56562ce6-d7a7-4fdc-8e76-d7c51587a8f1--000000000000--COLOR',
            ),
            'cssEnableTextDecoration' => 
            array (
              'type' => 'bp',
              '[object Object]' => true,
              'default' => false,
            ),
            'cssEnableUnderline' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssEnableOverline' => 
            array (
              'type' => 'bp',
              'default' => NULL,
            ),
            'cssEnableLineThrough' => 
            array (
              'type' => 'bp',
            ),
            'cssEnableTextTransform' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssTextTransform' => 
            array (
              'type' => 'bp',
              'default' => 'uppercase',
            ),
            'cssEnableTextAlign' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssTextAlign' => 
            array (
              'type' => 'bp',
              'default' => 'left',
            ),
            'cssEnableLineHeight' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssLineHeight' => 
            array (
              'type' => 'bp',
              'default' => '130%',
            ),
            'cssEnableLetterSpacing' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssLetterSpacing' => 
            array (
              'type' => 'bp',
              'default' => '0px',
            ),
          ),
          'htmlClass' => '',
        ),
        1 => 
        array (
          'id' => 'MUNIT-4bab3ac4-0eb6-47fc-9303-c89a53e79ae8-MUNIT',
          'moduleId' => 'rz_selector_pseudo_class',
          'name' => '{"de":"Zustandsselektor (Mouseover)","en":"State Selector (Mouseover)"}',
          'templateUnitId' => 'MUNIT-a9b3e0f0-7eec-4711-a106-9759ac4c5485-MUNIT',
          'ghostContainer' => false,
          'formValues' => 
          array (
            'pseudoClass' => 'hover',
            'additionalSelector' => ':hover',
          ),
          'htmlClass' => '',
          'children' => 
          array (
            0 => 
            array (
              'id' => 'MUNIT-6ebc2251-912c-43a8-93b8-6eda1896d76a-MUNIT',
              'moduleId' => 'rz_style_font',
              'name' => '',
              'templateUnitId' => 'MUNIT-662f6e07-e7eb-499c-a3ca-201d92f07fb9-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'cssEnableFontFamily' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssWebFontId' => 
                array (
                  'type' => 'bp',
                  'default' => '',
                ),
                'cssFontFamilyGoogle' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssFontFamily' => 
                array (
                  'type' => 'bp',
                  'default' => 'Arial, Helvetica, sans-serif',
                ),
                'cssEnableFontStyle' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssFontWeight' => 
                array (
                  'type' => 'bp',
                  'default' => 400,
                ),
                'cssEnableItalic' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssEnableCaps' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssEnableFontSize' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssFontSize' => 
                array (
                  'type' => 'bp',
                  'default' => '16px',
                ),
                'cssEnableFontSizeVw' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssFontSizeVw' => 
                array (
                  'type' => 'bp',
                  'default' => '1vw',
                ),
                'cssEnableColor' => 
                array (
                  'type' => 'bp',
                  '[object Object]' => false,
                  'default' => false,
                ),
                'cssColor' => 
                array (
                  'type' => 'bp',
                  'default' => 'COLOR-56562ce6-d7a7-4fdc-8e76-d7c51587a8f1--000000000000--COLOR',
                ),
                'cssEnableTextDecoration' => 
                array (
                  'type' => 'bp',
                  '[object Object]' => true,
                  'default' => true,
                ),
                'cssEnableUnderline' => 
                array (
                  'type' => 'bp',
                  'default' => true,
                ),
                'cssEnableOverline' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssEnableLineThrough' => 
                array (
                  'type' => 'bp',
                ),
                'cssEnableTextTransform' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssTextTransform' => 
                array (
                  'type' => 'bp',
                  'default' => 'uppercase',
                ),
                'cssEnableTextAlign' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssTextAlign' => 
                array (
                  'type' => 'bp',
                  'default' => 'left',
                ),
                'cssEnableLineHeight' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssLineHeight' => 
                array (
                  'type' => 'bp',
                  'default' => '130%',
                ),
                'cssEnableLetterSpacing' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssLetterSpacing' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
              ),
              'htmlClass' => '',
            ),
          ),
        ),
      ),
    ),
    3 => 
    array (
      'id' => 'MUNIT-1d78ddf9-bb55-4ae3-8ccf-21df29c201ce-MUNIT',
      'moduleId' => 'rz_grid',
      'name' => '{"de":"Grid mit Maximalbreite","en":"Grid with max-width"}',
      'templateUnitId' => 'MUNIT-6688c9fb-398b-4ff4-9043-28fe50d7019a-MUNIT',
      'ghostContainer' => false,
      'formValues' => 
      array (
        'gridSize' => 12,
        'cssGridDefinition' => 
        array (
          'type' => 'bp',
          'default' => '4-4-4
12
12
12',
          'res2' => '5-2-5
12
12
12',
          'res3' => '4-4-4
12
12
12',
        ),
        'cssHSpace' => 
        array (
          'type' => 'bp',
          'default' => '3%',
        ),
        'cssVSpace' => 
        array (
          'type' => 'bp',
          'default' => '5%',
        ),
        'cssMinHeight' => 
        array (
          'type' => 'bp',
          'default' => '0%',
        ),
        'cssVerticalAlign' => 
        array (
          'type' => 'bp',
          'default' => 'top',
        ),
        'cssEnableHorizontalAlign' => true,
        'cssHorizontalAlign' => 
        array (
          'type' => 'bp',
          'default' => 'center',
        ),
      ),
      'htmlClass' => '',
      'children' => 
      array (
        0 => 
        array (
          'id' => 'MUNIT-a3a945cb-176c-4cc7-929d-e45767d1a46b-MUNIT',
          'moduleId' => 'rz_style_width_height',
          'name' => '',
          'templateUnitId' => 'MUNIT-a37f37b3-3da3-4e66-9429-48f6d071dab1-MUNIT',
          'ghostContainer' => false,
          'formValues' => 
          array (
            'cssEnableWidth' => 
            array (
              'type' => 'bp',
              'default' => true,
            ),
            'cssWidthType' => 
            array (
              'type' => 'bp',
              'default' => 'fix',
            ),
            'cssWidth' => 
            array (
              'type' => 'bp',
              'default' => '100%',
            ),
            'cssEnableMinWidth' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssMinWidth' => 
            array (
              'type' => 'bp',
              'default' => '340px',
            ),
            'cssEnableMaxWidth' => 
            array (
              'type' => 'bp',
              'default' => true,
            ),
            'cssMaxWidth' => 
            array (
              'type' => 'bp',
              'default' => '940px',
            ),
            'cssEnableHeight' => 
            array (
              'type' => 'bp',
              'default' => false,
            ),
            'cssHeightType' => 
            array (
              'type' => 'bp',
              'default' => 'fix',
            ),
            'cssHeight' => 
            array (
              'type' => 'bp',
              'default' => '50px',
            ),
            'cssOverflowY' => 
            array (
              'type' => 'bp',
              'default' => 'hidden',
            ),
            'cssMinHeight' => 
            array (
              'type' => 'bp',
              'default' => '50px',
            ),
          ),
          'htmlClass' => '',
        ),
        1 => 
        array (
          'id' => 'MUNIT-dbe673ed-3370-4f71-9926-4b2dcdd5dc0b-MUNIT',
          'moduleId' => 'rz_svg',
          'name' => 'Logo',
          'templateUnitId' => 'MUNIT-b66fcc60-f274-4016-b70d-be67c89d5a0b-MUNIT',
          'ghostContainer' => false,
          'formValues' => 
          array (
            'svg' => 'MDB-c32c5c61-a1b1-42fb-9c87-5218413c4755-MDB',
            'svgAlt' => 'Cafe by the Lake',
            'svgTitle' => '',
          ),
          'htmlClass' => '',
        ),
        2 => 
        array (
          'id' => 'MUNIT-caefc05d-4753-45b7-b8de-a205f4730a08-MUNIT',
          'moduleId' => 'rz_navigation',
          'name' => '',
          'templateUnitId' => 'MUNIT-9c833bd0-88a6-42ae-a9d7-500d20e29348-MUNIT',
          'ghostContainer' => false,
          'formValues' => 
          array (
            'navStart' => NULL,
            'enableLevel1' => true,
            'cssLevel1Align' => 
            array (
              'type' => 'bp',
              'default' => 'center',
            ),
            'cssLevel1Distribution' => 
            array (
              'type' => 'bp',
              'default' => 'horizontal',
              'res3' => 'vertical',
            ),
            'cssLevel1Space' => 
            array (
              'type' => 'bp',
              'default' => '40px',
              'res3' => '11px',
            ),
            'enableLevel2' => false,
            'cssLevel2Align' => 
            array (
              'type' => 'bp',
              'default' => 'left',
            ),
            'cssLevel2Distribution' => 
            array (
              'type' => 'bp',
              'default' => 'horizontal',
            ),
            'cssLevel2Space' => 
            array (
              'type' => 'bp',
              'default' => '5px',
            ),
            'enableOnlyShowActiveItemsOfLevel2' => true,
            'enableLevel3' => false,
            'cssLevel3Align' => 
            array (
              'type' => 'bp',
              'default' => 'left',
            ),
            'cssLevel3Distribution' => 
            array (
              'type' => 'bp',
              'default' => 'horizontal',
            ),
            'cssLevel3Space' => 
            array (
              'type' => 'bp',
              'default' => '5px',
            ),
            'enableOnlyShowActiveItemsOfLevel3' => true,
            'enableLevel4' => false,
            'cssLevel4Align' => 
            array (
              'type' => 'bp',
              'default' => 'left',
            ),
            'cssLevel4Distribution' => 
            array (
              'type' => 'bp',
              'default' => 'horizontal',
            ),
            'cssLevel4Space' => 
            array (
              'type' => 'bp',
              'default' => '5px',
            ),
            'enableOnlyShowActiveItemsOfLevel4' => true,
            'enableLevel5' => false,
            'cssLevel5Align' => 
            array (
              'type' => 'bp',
              'default' => 'left',
            ),
            'cssLevel5Distribution' => 
            array (
              'type' => 'bp',
              'default' => 'horizontal',
            ),
            'cssLevel5Space' => 
            array (
              'type' => 'bp',
              'default' => '5px',
            ),
            'enableOnlyShowActiveItemsOfLevel5' => true,
          ),
          'htmlClass' => '',
          'children' => 
          array (
            0 => 
            array (
              'id' => 'MUNIT-9106d5b8-4a89-48a0-8e93-0f949a2cf681-MUNIT',
              'moduleId' => 'rz_style_border',
              'name' => '',
              'templateUnitId' => 'MUNIT-faf789ae-5acb-4b9d-9c85-7968ca494867-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'cssEnableBorder' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssBorderColor' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssBorderStyle' => 
                array (
                  'type' => 'bp',
                  'default' => 'solid',
                ),
                'cssBorderWidth' => 
                array (
                  'type' => 'bp',
                  'default' => '1px',
                ),
                'cssEnableBorderTop' => 
                array (
                  'type' => 'bp',
                  'default' => true,
                ),
                'cssBorderTopColor' => 
                array (
                  'type' => 'bp',
                  'default' => 'COLOR-05524024-1f7e-4fca-a109-16328ea0b8c9--000000000000--COLOR',
                ),
                'cssBorderTopStyle' => 
                array (
                  'type' => 'bp',
                  'default' => 'solid',
                ),
                'cssBorderTopWidth' => 
                array (
                  'type' => 'bp',
                  'default' => '2px',
                ),
                'cssEnableBorderRight' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssBorderRightColor' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssBorderRightStyle' => 
                array (
                  'type' => 'bp',
                  'default' => 'solid',
                ),
                'cssBorderRightWidth' => 
                array (
                  'type' => 'bp',
                  'default' => '1px',
                ),
                'cssEnableBorderBottom' => 
                array (
                  'type' => 'bp',
                  'default' => true,
                ),
                'cssBorderBottomColor' => 
                array (
                  'type' => 'bp',
                  'default' => 'COLOR-05524024-1f7e-4fca-a109-16328ea0b8c9--000000000000--COLOR',
                ),
                'cssBorderBottomStyle' => 
                array (
                  'type' => 'bp',
                  'default' => 'solid',
                ),
                'cssBorderBottomWidth' => 
                array (
                  'type' => 'bp',
                  'default' => '2px',
                ),
                'cssEnableBorderLeft' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssBorderLeftColor' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssBorderLeftStyle' => 
                array (
                  'type' => 'bp',
                  'default' => 'solid',
                ),
                'cssBorderLeftWidth' => 
                array (
                  'type' => 'bp',
                  'default' => '1px',
                ),
              ),
              'htmlClass' => '',
            ),
            1 => 
            array (
              'id' => 'MUNIT-c5556ea7-aa08-4b3e-9f32-ec9ccd0f3a6e-MUNIT',
              'moduleId' => 'rz_style_padding_margin',
              'name' => '',
              'templateUnitId' => 'MUNIT-ac5e9827-179e-483c-92b8-287b281d3d6a-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'cssEnablePadding' => 
                array (
                  'type' => 'bp',
                  'default' => true,
                ),
                'cssPaddingLeft' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssPaddingRight' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssPaddingTop' => 
                array (
                  'type' => 'bp',
                  'default' => '10px',
                ),
                'cssPaddingBottom' => 
                array (
                  'type' => 'bp',
                  'default' => '10px',
                ),
                'cssEnableMargin' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssMarginLeft' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssMarginRight' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssMarginTop' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssMarginBottom' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
              ),
              'htmlClass' => '',
            ),
            2 => 
            array (
              'id' => 'MUNIT-a349c932-772f-4391-84a4-976ab67a5f0a-MUNIT',
              'moduleId' => 'rz_style_font',
              'name' => '',
              'templateUnitId' => 'MUNIT-12197de1-15a3-4d53-bace-352b815adacc-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'cssEnableFontFamily' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssWebFontId' => 
                array (
                  'type' => 'bp',
                  'default' => '',
                ),
                'cssFontFamilyGoogle' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssFontFamily' => 
                array (
                  'type' => 'bp',
                  'default' => 'Arial, Helvetica, sans-serif',
                ),
                'cssEnableFontStyle' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssFontWeight' => 
                array (
                  'type' => 'bp',
                  'default' => 400,
                ),
                'cssEnableItalic' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssEnableCaps' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssEnableFontSize' => 
                array (
                  'type' => 'bp',
                  '[object Object]' => true,
                  'default' => true,
                  'res3' => true,
                ),
                'cssFontSize' => 
                array (
                  'type' => 'bp',
                  'default' => '18px',
                  'res3' => '16px',
                ),
                'cssEnableFontSizeVw' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssFontSizeVw' => 
                array (
                  'type' => 'bp',
                  'default' => '1vw',
                ),
                'cssEnableColor' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssColor' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssEnableTextDecoration' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssEnableUnderline' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssEnableOverline' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssEnableLineThrough' => 
                array (
                  'type' => 'bp',
                ),
                'cssEnableTextTransform' => 
                array (
                  'type' => 'bp',
                  '[object Object]' => true,
                  'default' => true,
                ),
                'cssTextTransform' => 
                array (
                  'type' => 'bp',
                  'default' => 'uppercase',
                ),
                'cssEnableTextAlign' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssTextAlign' => 
                array (
                  'type' => 'bp',
                  'default' => 'left',
                ),
                'cssEnableLineHeight' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssLineHeight' => 
                array (
                  'type' => 'bp',
                  'default' => '130%',
                ),
                'cssEnableLetterSpacing' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssLetterSpacing' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
              ),
              'htmlClass' => '',
            ),
            3 => 
            array (
              'id' => 'MUNIT-23e44fa1-cada-46f5-a27f-2e2fc8ae1216-MUNIT',
              'moduleId' => 'rz_selector_elements',
              'name' => '{"de":"Selektor (Aktiver Navigationslink)","en":"Selector (Active navigation link)"}',
              'templateUnitId' => 'MUNIT-32191f76-f035-43c5-8ad9-f15d8f5d9ab0-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'module' => 'rz_navigation',
                'selectorChooser' => '.navLink.navLinkActive',
                'nthChildEnable' => false,
                'type' => 'preset',
                'presets' => 'first-of-type',
                'customPseudoClass' => 'nth-of-type',
                'customType' => 'single',
                'singleStartIndex' => '1',
                'multipleCount' => '1',
                'allStartIndex' => '1',
                'multipleOffsetStartIndex' => '1',
                'multipleOffsetNth' => '1',
                'additionalSelector' => '.navLink.navLinkActive',
              ),
              'htmlClass' => '',
              'children' => 
              array (
                0 => 
                array (
                  'id' => 'MUNIT-962a88a4-145e-4abe-914b-0dce3f09ab31-MUNIT',
                  'moduleId' => 'rz_style_font',
                  'name' => '',
                  'templateUnitId' => 'MUNIT-fd9b02db-690e-4e33-ad38-f7d91dc320f0-MUNIT',
                  'ghostContainer' => false,
                  'formValues' => 
                  array (
                    'cssEnableFontFamily' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssWebFontId' => 
                    array (
                      'type' => 'bp',
                      'default' => '',
                    ),
                    'cssFontFamilyGoogle' => 
                    array (
                      'type' => 'bp',
                      'default' => NULL,
                    ),
                    'cssFontFamily' => 
                    array (
                      'type' => 'bp',
                      'default' => 'Arial, Helvetica, sans-serif',
                    ),
                    'cssEnableFontStyle' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssFontWeight' => 
                    array (
                      'type' => 'bp',
                      'default' => 400,
                    ),
                    'cssEnableItalic' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssEnableCaps' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssEnableFontSize' => 
                    array (
                      'type' => 'bp',
                      '[object Object]' => true,
                      'default' => false,
                      'res3' => true,
                    ),
                    'cssFontSize' => 
                    array (
                      'type' => 'bp',
                      'default' => '19px',
                      'res3' => '16px',
                    ),
                    'cssEnableFontSizeVw' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssFontSizeVw' => 
                    array (
                      'type' => 'bp',
                      'default' => '1vw',
                    ),
                    'cssEnableColor' => 
                    array (
                      'type' => 'bp',
                      '[object Object]' => false,
                      'default' => true,
                    ),
                    'cssColor' => 
                    array (
                      'type' => 'bp',
                      'default' => 'COLOR-56562ce6-d7a7-4fdc-8e76-d7c51587a8f1--000000000000--COLOR',
                    ),
                    'cssEnableTextDecoration' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssEnableUnderline' => 
                    array (
                      'type' => 'bp',
                      'default' => NULL,
                    ),
                    'cssEnableOverline' => 
                    array (
                      'type' => 'bp',
                      'default' => NULL,
                    ),
                    'cssEnableLineThrough' => 
                    array (
                      'type' => 'bp',
                    ),
                    'cssEnableTextTransform' => 
                    array (
                      'type' => 'bp',
                      '[object Object]' => true,
                      'default' => false,
                    ),
                    'cssTextTransform' => 
                    array (
                      'type' => 'bp',
                      'default' => 'uppercase',
                    ),
                    'cssEnableTextAlign' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssTextAlign' => 
                    array (
                      'type' => 'bp',
                      'default' => 'left',
                    ),
                    'cssEnableLineHeight' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssLineHeight' => 
                    array (
                      'type' => 'bp',
                      'default' => '130%',
                    ),
                    'cssEnableLetterSpacing' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssLetterSpacing' => 
                    array (
                      'type' => 'bp',
                      'default' => '0px',
                    ),
                  ),
                  'htmlClass' => '',
                ),
              ),
            ),
            4 => 
            array (
              'id' => 'MUNIT-2d5d88d0-a5d6-4842-968b-81f383fd4ee8-MUNIT',
              'moduleId' => 'rz_selector_elements',
              'name' => '{"de":"Selektor (Alle Navigationslinks)","en":"Selector (All navigation links)"}',
              'templateUnitId' => 'MUNIT-f362635c-4d41-482a-aeaf-c43800b2a962-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'module' => 'rz_navigation',
                'selectorChooser' => '.navLink',
                'nthChildEnable' => false,
                'type' => 'preset',
                'presets' => 'first-of-type',
                'customPseudoClass' => 'nth-of-type',
                'customType' => 'single',
                'singleStartIndex' => '1',
                'multipleCount' => '1',
                'allStartIndex' => '1',
                'multipleOffsetStartIndex' => '1',
                'multipleOffsetNth' => '1',
                'additionalSelector' => '.navLink',
              ),
              'htmlClass' => '',
              'children' => 
              array (
                0 => 
                array (
                  'id' => 'MUNIT-330bb522-7deb-42ce-b60c-3a1092d5f7b0-MUNIT',
                  'moduleId' => 'rz_selector_pseudo_class',
                  'name' => '{"de":"Zustandsselektor (Mouseover)","en":"State Selector (Mouseover)"}',
                  'templateUnitId' => 'MUNIT-022ad9a8-d3f3-47ab-974d-2d1f1b32792e-MUNIT',
                  'ghostContainer' => false,
                  'formValues' => 
                  array (
                    'pseudoClass' => 'hover',
                    'additionalSelector' => ':hover',
                  ),
                  'htmlClass' => '',
                  'children' => 
                  array (
                    0 => 
                    array (
                      'id' => 'MUNIT-dc29d275-faf3-4a83-af03-6f0d595c1337-MUNIT',
                      'moduleId' => 'rz_style_font',
                      'name' => '',
                      'templateUnitId' => 'MUNIT-69ea429f-f602-43c4-83a7-e7e90e62c6f3-MUNIT',
                      'ghostContainer' => false,
                      'formValues' => 
                      array (
                        'cssEnableFontFamily' => 
                        array (
                          'type' => 'bp',
                          '[object Object]' => true,
                          'default' => false,
                        ),
                        'cssWebFontId' => 
                        array (
                          'type' => 'bp',
                          'default' => '',
                        ),
                        'cssFontFamilyGoogle' => 
                        array (
                          'type' => 'bp',
                          'default' => NULL,
                        ),
                        'cssFontFamily' => 
                        array (
                          'type' => 'bp',
                          'default' => 'Arial, Helvetica, sans-serif',
                        ),
                        'cssEnableFontStyle' => 
                        array (
                          'type' => 'bp',
                          '[object Object]' => true,
                          'default' => false,
                        ),
                        'cssFontWeight' => 
                        array (
                          'type' => 'bp',
                          'default' => 400,
                        ),
                        'cssEnableItalic' => 
                        array (
                          'type' => 'bp',
                          'default' => false,
                        ),
                        'cssEnableCaps' => 
                        array (
                          'type' => 'bp',
                          'default' => false,
                        ),
                        'cssEnableFontSize' => 
                        array (
                          'type' => 'bp',
                          'default' => false,
                        ),
                        'cssFontSize' => 
                        array (
                          'type' => 'bp',
                          'default' => '16px',
                        ),
                        'cssEnableFontSizeVw' => 
                        array (
                          'type' => 'bp',
                          'default' => false,
                        ),
                        'cssFontSizeVw' => 
                        array (
                          'type' => 'bp',
                          'default' => '1vw',
                        ),
                        'cssEnableColor' => 
                        array (
                          'type' => 'bp',
                          '[object Object]' => false,
                          'default' => true,
                        ),
                        'cssColor' => 
                        array (
                          'type' => 'bp',
                          'default' => 'COLOR-d89e3651-f4fb-4cc1-8734-de56c41c9a6d--000000000000--COLOR',
                        ),
                        'cssEnableTextDecoration' => 
                        array (
                          'type' => 'bp',
                          'default' => false,
                        ),
                        'cssEnableUnderline' => 
                        array (
                          'type' => 'bp',
                          'default' => NULL,
                        ),
                        'cssEnableOverline' => 
                        array (
                          'type' => 'bp',
                          'default' => NULL,
                        ),
                        'cssEnableLineThrough' => 
                        array (
                          'type' => 'bp',
                        ),
                        'cssEnableTextTransform' => 
                        array (
                          'type' => 'bp',
                          'default' => false,
                        ),
                        'cssTextTransform' => 
                        array (
                          'type' => 'bp',
                          'default' => 'uppercase',
                        ),
                        'cssEnableTextAlign' => 
                        array (
                          'type' => 'bp',
                          'default' => false,
                        ),
                        'cssTextAlign' => 
                        array (
                          'type' => 'bp',
                          'default' => 'left',
                        ),
                        'cssEnableLineHeight' => 
                        array (
                          'type' => 'bp',
                          'default' => false,
                        ),
                        'cssLineHeight' => 
                        array (
                          'type' => 'bp',
                          'default' => '130%',
                        ),
                        'cssEnableLetterSpacing' => 
                        array (
                          'type' => 'bp',
                          'default' => false,
                        ),
                        'cssLetterSpacing' => 
                        array (
                          'type' => 'bp',
                          'default' => '0px',
                        ),
                      ),
                      'htmlClass' => '',
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        3 => 
        array (
          'id' => 'MUNIT-d1c72446-9ed4-435e-bd03-de64c8c5b945-MUNIT',
          'moduleId' => 'rz_ghost_container',
          'name' => '',
          'templateUnitId' => 'MUNIT-ff02c0bf-c3b2-4db2-90c6-811cf289267a-MUNIT',
          'ghostContainer' => true,
          'formValues' => 
          array (
            'cssColumnCount' => 
            array (
              'type' => 'bp',
              'default' => 1,
            ),
            'cssHSpace' => 
            array (
              'type' => 'bp',
              'default' => '2%',
            ),
            'cssVSpace' => 
            array (
              'type' => 'bp',
              'default' => '5%',
            ),
          ),
          'htmlClass' => '',
          'children' => 
          array (
            0 => 
            array (
              'id' => 'MUNIT-09729a86-aaa0-4fce-8061-1224df016486-MUNIT',
              'moduleId' => 'rz_headline',
              'name' => '{"de":"Überschrift (h1)","en":"Heading (h1)"}',
              'templateUnitId' => 'MUNIT-95e1a1b7-df3d-4646-9eac-b454cc0f6215-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'text' => 'Impressions',
                'htmlElement' => 'h1',
              ),
              'htmlClass' => '',
              'children' => 
              array (
                0 => 
                array (
                  'id' => 'MUNIT-d2eb285d-de85-4f60-b9c1-fe6e7beb4805-MUNIT',
                  'moduleId' => 'rz_style_font',
                  'name' => '',
                  'templateUnitId' => 'MUNIT-f44b252b-bbac-4800-8210-038c0babb8f0-MUNIT',
                  'ghostContainer' => false,
                  'formValues' => 
                  array (
                    'cssEnableFontFamily' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssWebFontId' => 
                    array (
                      'type' => 'bp',
                      'default' => '',
                    ),
                    'cssFontFamilyGoogle' => 
                    array (
                      'type' => 'bp',
                      'default' => NULL,
                    ),
                    'cssFontFamily' => 
                    array (
                      'type' => 'bp',
                      'default' => 'Arial, Helvetica, sans-serif',
                    ),
                    'cssEnableFontStyle' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssFontWeight' => 
                    array (
                      'type' => 'bp',
                      'default' => 400,
                    ),
                    'cssEnableItalic' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssEnableCaps' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssEnableFontSize' => 
                    array (
                      'type' => 'bp',
                      '[object Object]' => true,
                      'default' => true,
                      'res3' => true,
                    ),
                    'cssFontSize' => 
                    array (
                      'type' => 'bp',
                      'default' => '48px',
                      'res3' => '21px',
                    ),
                    'cssEnableFontSizeVw' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssFontSizeVw' => 
                    array (
                      'type' => 'bp',
                      'default' => '1vw',
                    ),
                    'cssEnableColor' => 
                    array (
                      'type' => 'bp',
                      '[object Object]' => false,
                      'default' => true,
                    ),
                    'cssColor' => 
                    array (
                      'type' => 'bp',
                      'default' => 'COLOR-56562ce6-d7a7-4fdc-8e76-d7c51587a8f1--000000000000--COLOR',
                    ),
                    'cssEnableTextDecoration' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssEnableUnderline' => 
                    array (
                      'type' => 'bp',
                      'default' => NULL,
                    ),
                    'cssEnableOverline' => 
                    array (
                      'type' => 'bp',
                      'default' => NULL,
                    ),
                    'cssEnableLineThrough' => 
                    array (
                      'type' => 'bp',
                    ),
                    'cssEnableTextTransform' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssTextTransform' => 
                    array (
                      'type' => 'bp',
                      'default' => 'uppercase',
                    ),
                    'cssEnableTextAlign' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssTextAlign' => 
                    array (
                      'type' => 'bp',
                      'default' => 'left',
                    ),
                    'cssEnableLineHeight' => 
                    array (
                      'type' => 'bp',
                      'default' => true,
                    ),
                    'cssLineHeight' => 
                    array (
                      'type' => 'bp',
                      'default' => '130%',
                    ),
                    'cssEnableLetterSpacing' => 
                    array (
                      'type' => 'bp',
                      'default' => false,
                    ),
                    'cssLetterSpacing' => 
                    array (
                      'type' => 'bp',
                      'default' => '0px',
                    ),
                  ),
                  'htmlClass' => '',
                ),
              ),
            ),
            1 => 
            array (
              'id' => 'MUNIT-33999a29-ac99-4faf-819e-c73d22e458bf-MUNIT',
              'moduleId' => 'rz_textfield',
              'name' => '',
              'templateUnitId' => 'MUNIT-ea5c3f4d-dbb0-4800-a455-85fb6016e90c-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'enableRteBold' => true,
                'enableRteItalic' => true,
                'enableRteUnderline' => true,
                'enableRteStrikethrough' => true,
                'enableRteSubscript' => true,
                'enableRteSuperscript' => true,
                'enableRteList' => true,
                'enableRteLink' => true,
                'enableRteTable' => true,
                'enableRteHeadline1' => false,
                'rteHeadline1Title' => 'Heading 1',
                'enableRteHeadline2' => false,
                'rteHeadline2Title' => 'Heading 2',
                'enableRteHeadline3' => false,
                'rteHeadline3Title' => 'Heading 3',
                'enableRteHeadline4' => false,
                'rteHeadline4Title' => 'Heading 4',
                'enableRteHeadline5' => false,
                'rteHeadline5Title' => 'Heading 5',
                'enableRteHeadline6' => false,
                'rteHeadline6Title' => 'Heading 6',
                'enableRteStyle1' => false,
                'rteStyle1Title' => '',
                'rteStyle1Element' => '',
                'enableRteStyle2' => false,
                'rteStyle2Title' => '',
                'rteStyle2Element' => '',
                'enableRteStyle3' => false,
                'rteStyle3Title' => '',
                'rteStyle3Element' => '',
                'enableRteStyle4' => false,
                'rteStyle4Title' => '',
                'rteStyle4Element' => '',
                'text' => '<p>I’m never bored, never ever bored.<br />If I’ve got a day off I’ll sit in the cafe by the lake<br />and watch and observe.<br />I’m a great observer, espacially here.<br /><br /><em>David Suchet</em></p>',
              ),
              'htmlClass' => '',
            ),
            2 => 
            array (
              'id' => 'MUNIT-c73de393-166d-4003-9562-647a58312350-MUNIT',
              'moduleId' => 'rz_lightbox',
              'name' => '{"de":"Lightbox mit Bildergalerie","en":"Lightbox with Gallery"}',
              'templateUnitId' => 'MUNIT-65dbdcd2-b1ee-4ff3-92f4-6712831b1b11-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
              ),
              'htmlClass' => '',
              'children' => 
              array (
                0 => 
                array (
                  'id' => 'MUNIT-a8aa9a95-5831-4542-bf62-13beadd30e7e-MUNIT',
                  'moduleId' => 'rz_grid',
                  'name' => '',
                  'templateUnitId' => 'MUNIT-6103bea5-ac37-4df3-9e77-86c45121cf85-MUNIT',
                  'ghostContainer' => false,
                  'formValues' => 
                  array (
                    'gridSize' => 12,
                    'cssGridDefinition' => 
                    array (
                      'type' => 'bp',
                      'default' => '3 3 3 3
3 3 3 3',
                      'res3' => '6 6
6 6
6 6
6 6',
                    ),
                    'cssHSpace' => 
                    array (
                      'type' => 'bp',
                      'default' => '3%',
                    ),
                    'cssVSpace' => 
                    array (
                      'type' => 'bp',
                      'default' => '3%',
                    ),
                    'cssMinHeight' => 
                    array (
                      'type' => 'bp',
                      'default' => '0%',
                    ),
                    'cssVerticalAlign' => 
                    array (
                      'type' => 'bp',
                      'default' => 'top',
                    ),
                    'cssEnableHorizontalAlign' => false,
                    'cssHorizontalAlign' => 
                    array (
                      'type' => 'bp',
                      'default' => 'left',
                    ),
                  ),
                  'htmlClass' => '',
                  'children' => 
                  array (
                    0 => 
                    array (
                      'id' => 'MUNIT-bcf7b2ea-9938-45cd-901e-d7aed470b78d-MUNIT',
                      'moduleId' => 'rz_image',
                      'name' => '',
                      'templateUnitId' => 'MUNIT-27a10060-0516-41f8-977e-d0a51184b44f-MUNIT',
                      'ghostContainer' => false,
                      'formValues' => 
                      array (
                        'imgsrc' => 'MDB-b78d4071-3cee-4a84-8f86-c5dbb403bbb0-MDB',
                        'imageAlt' => '',
                        'imageTitle' => '',
                        'cropData' => '{"cropXRatio":0.3093209398399173,"cropYRatio":0.389881103005892,"cropWidthRatio":0.6906790601600826,"cropHeightRatio":0.4596852855954328}',
                        'imgHeight' => '100%',
                        'enableImageQuality' => false,
                        'imageQuality' => '85',
                      ),
                      'htmlClass' => '',
                      'children' => 
                      array (
                        0 => 
                        array (
                          'id' => 'MUNIT-0a1031cb-7ee9-4554-bb87-5c9993b086df-MUNIT',
                          'moduleId' => 'rz_style_animation_scroll',
                          'name' => '',
                          'templateUnitId' => 'MUNIT-33d1a2e6-5694-4814-ba43-435fdcea7241-MUNIT',
                          'ghostContainer' => false,
                          'formValues' => 
                          array (
                            'cssEnableAnimation' => 
                            array (
                              'type' => 'bp',
                              'default' => 'enabled',
                            ),
                            'cssAnimationIn' => 
                            array (
                              'type' => 'bp',
                              'default' => 'flipInY',
                            ),
                            'cssDuration' => 
                            array (
                              'type' => 'bp',
                              'default' => '400ms',
                            ),
                            'cssDelay' => 
                            array (
                              'type' => 'bp',
                              'default' => '0ms',
                            ),
                            'cssIteration' => 
                            array (
                              'type' => 'bp',
                              'default' => '1ms',
                            ),
                            'cssTrigger' => 
                            array (
                              'type' => 'bp',
                              'default' => 'visiblePart75',
                            ),
                            'cssOnlyOnce' => 
                            array (
                              'type' => 'bp',
                              'default' => false,
                            ),
                            'cssVisibilityHidden' => 
                            array (
                              'type' => 'bp',
                              'default' => true,
                            ),
                            'previewAnimations' => NULL,
                          ),
                          'htmlClass' => '',
                        ),
                      ),
                    ),
                    1 => 
                    array (
                      'id' => 'MUNIT-4a739368-dcf1-4247-b0bb-219f201e4e73-MUNIT',
                      'moduleId' => 'rz_image',
                      'name' => '',
                      'templateUnitId' => 'MUNIT-bde8c6b3-7cc2-4fdb-a58c-2e74c56516d8-MUNIT',
                      'ghostContainer' => false,
                      'formValues' => 
                      array (
                        'imgsrc' => 'MDB-11cbdcf5-a10a-4ff2-9007-522d51318469-MDB',
                        'imageAlt' => '',
                        'imageTitle' => '',
                        'cropData' => '',
                        'imgHeight' => '100%',
                        'enableImageQuality' => false,
                        'imageQuality' => '85',
                      ),
                      'htmlClass' => '',
                      'children' => 
                      array (
                        0 => 
                        array (
                          'id' => 'MUNIT-283858a7-486a-48c5-b955-cd94c2adb4ff-MUNIT',
                          'moduleId' => 'rz_style_animation_scroll',
                          'name' => '',
                          'templateUnitId' => 'MUNIT-c2c15435-a90f-4f2f-8d3f-1792bec01faa-MUNIT',
                          'ghostContainer' => false,
                          'formValues' => 
                          array (
                            'cssEnableAnimation' => 
                            array (
                              'type' => 'bp',
                              'default' => 'enabled',
                            ),
                            'cssAnimationIn' => 
                            array (
                              'type' => 'bp',
                              'default' => 'flipInX',
                            ),
                            'cssDuration' => 
                            array (
                              'type' => 'bp',
                              'default' => '400ms',
                            ),
                            'cssDelay' => 
                            array (
                              'type' => 'bp',
                              'default' => '100ms',
                            ),
                            'cssIteration' => 
                            array (
                              'type' => 'bp',
                              'default' => '1ms',
                            ),
                            'cssTrigger' => 
                            array (
                              'type' => 'bp',
                              'default' => 'visiblePart75',
                            ),
                            'cssOnlyOnce' => 
                            array (
                              'type' => 'bp',
                              'default' => false,
                            ),
                            'cssVisibilityHidden' => 
                            array (
                              'type' => 'bp',
                              'default' => true,
                            ),
                            'previewAnimations' => NULL,
                          ),
                          'htmlClass' => '',
                        ),
                      ),
                    ),
                    2 => 
                    array (
                      'id' => 'MUNIT-69b1243f-1a41-40a9-b51e-630e77064f44-MUNIT',
                      'moduleId' => 'rz_image',
                      'name' => '',
                      'templateUnitId' => 'MUNIT-4954c165-3ad1-407b-8364-7c2988b900ef-MUNIT',
                      'ghostContainer' => false,
                      'formValues' => 
                      array (
                        'imgsrc' => 'MDB-f757f5b1-d6e0-4b67-97f5-d25fc40f16ed-MDB',
                        'imageAlt' => '',
                        'imageTitle' => '',
                        'cropData' => '',
                        'imgHeight' => '100%',
                        'enableImageQuality' => false,
                        'imageQuality' => '85',
                      ),
                      'htmlClass' => '',
                      'children' => 
                      array (
                        0 => 
                        array (
                          'id' => 'MUNIT-c5cc717a-7deb-4627-b559-933e0ecef501-MUNIT',
                          'moduleId' => 'rz_style_animation_scroll',
                          'name' => '',
                          'templateUnitId' => 'MUNIT-61645907-7188-42bf-8b91-87754d2e7f5c-MUNIT',
                          'ghostContainer' => false,
                          'formValues' => 
                          array (
                            'cssEnableAnimation' => 
                            array (
                              'type' => 'bp',
                              'default' => 'enabled',
                            ),
                            'cssAnimationIn' => 
                            array (
                              'type' => 'bp',
                              'default' => 'flipInX',
                            ),
                            'cssDuration' => 
                            array (
                              'type' => 'bp',
                              'default' => '400ms',
                            ),
                            'cssDelay' => 
                            array (
                              'type' => 'bp',
                              'default' => '200ms',
                            ),
                            'cssIteration' => 
                            array (
                              'type' => 'bp',
                              'default' => '1ms',
                            ),
                            'cssTrigger' => 
                            array (
                              'type' => 'bp',
                              'default' => 'visiblePart75',
                            ),
                            'cssOnlyOnce' => 
                            array (
                              'type' => 'bp',
                              'default' => false,
                            ),
                            'cssVisibilityHidden' => 
                            array (
                              'type' => 'bp',
                              'default' => true,
                            ),
                            'previewAnimations' => NULL,
                          ),
                          'htmlClass' => '',
                        ),
                      ),
                    ),
                    3 => 
                    array (
                      'id' => 'MUNIT-7b4dff9e-d687-4cb7-b692-e6f91db3305b-MUNIT',
                      'moduleId' => 'rz_image',
                      'name' => '',
                      'templateUnitId' => 'MUNIT-904b7c79-f783-4d2d-af28-4ba7788a2126-MUNIT',
                      'ghostContainer' => false,
                      'formValues' => 
                      array (
                        'imgsrc' => 'MDB-11de25a8-19a8-4544-800f-68dda3bd5dce-MDB',
                        'imageAlt' => '',
                        'imageTitle' => '',
                        'cropData' => '',
                        'imgHeight' => '100%',
                        'enableImageQuality' => false,
                        'imageQuality' => '85',
                      ),
                      'htmlClass' => '',
                      'children' => 
                      array (
                        0 => 
                        array (
                          'id' => 'MUNIT-63263c14-7e64-45e4-a4f6-6e833a0bcfd6-MUNIT',
                          'moduleId' => 'rz_style_animation_scroll',
                          'name' => '',
                          'templateUnitId' => 'MUNIT-39120514-af4a-4909-a692-531d1619e612-MUNIT',
                          'ghostContainer' => false,
                          'formValues' => 
                          array (
                            'cssEnableAnimation' => 
                            array (
                              'type' => 'bp',
                              'default' => 'enabled',
                            ),
                            'cssAnimationIn' => 
                            array (
                              'type' => 'bp',
                              'default' => 'flipInY',
                            ),
                            'cssDuration' => 
                            array (
                              'type' => 'bp',
                              'default' => '400ms',
                            ),
                            'cssDelay' => 
                            array (
                              'type' => 'bp',
                              'default' => '300ms',
                            ),
                            'cssIteration' => 
                            array (
                              'type' => 'bp',
                              'default' => '1ms',
                            ),
                            'cssTrigger' => 
                            array (
                              'type' => 'bp',
                              'default' => 'visiblePart75',
                            ),
                            'cssOnlyOnce' => 
                            array (
                              'type' => 'bp',
                              'default' => false,
                            ),
                            'cssVisibilityHidden' => 
                            array (
                              'type' => 'bp',
                              'default' => true,
                            ),
                            'previewAnimations' => NULL,
                          ),
                          'htmlClass' => '',
                        ),
                      ),
                    ),
                    4 => 
                    array (
                      'id' => 'MUNIT-c20b2a74-6338-4cd5-85ee-3476aa61ea26-MUNIT',
                      'moduleId' => 'rz_image',
                      'name' => '',
                      'templateUnitId' => 'MUNIT-1f2f3922-d629-4030-94f0-fbfccfa7d51f-MUNIT',
                      'ghostContainer' => false,
                      'formValues' => 
                      array (
                        'imgsrc' => 'MDB-4491463e-1fd0-4dec-b50c-2d0a87278b8d-MDB',
                        'imageAlt' => '',
                        'imageTitle' => '',
                        'cropData' => '',
                        'imgHeight' => '100%',
                        'enableImageQuality' => false,
                        'imageQuality' => '85',
                      ),
                      'htmlClass' => '',
                      'children' => 
                      array (
                        0 => 
                        array (
                          'id' => 'MUNIT-bc499b95-7fd8-402a-aca0-3b4f0d01deb9-MUNIT',
                          'moduleId' => 'rz_style_animation_scroll',
                          'name' => '',
                          'templateUnitId' => 'MUNIT-b88a6bde-9d56-4787-ba8e-9e8413ab8f41-MUNIT',
                          'ghostContainer' => false,
                          'formValues' => 
                          array (
                            'cssEnableAnimation' => 
                            array (
                              'type' => 'bp',
                              'default' => 'enabled',
                            ),
                            'cssAnimationIn' => 
                            array (
                              'type' => 'bp',
                              'default' => 'flipInY',
                            ),
                            'cssDuration' => 
                            array (
                              'type' => 'bp',
                              'default' => '400ms',
                            ),
                            'cssDelay' => 
                            array (
                              'type' => 'bp',
                              'default' => '700ms',
                            ),
                            'cssIteration' => 
                            array (
                              'type' => 'bp',
                              'default' => '1ms',
                            ),
                            'cssTrigger' => 
                            array (
                              'type' => 'bp',
                              'default' => 'visiblePart75',
                            ),
                            'cssOnlyOnce' => 
                            array (
                              'type' => 'bp',
                              'default' => false,
                            ),
                            'cssVisibilityHidden' => 
                            array (
                              'type' => 'bp',
                              'default' => true,
                            ),
                            'previewAnimations' => NULL,
                          ),
                          'htmlClass' => '',
                        ),
                      ),
                    ),
                    5 => 
                    array (
                      'id' => 'MUNIT-6ef757bb-a3eb-4fd2-bb13-3552855faa25-MUNIT',
                      'moduleId' => 'rz_image',
                      'name' => '',
                      'templateUnitId' => 'MUNIT-250d7820-3fa6-4338-bce0-37b3eb924a16-MUNIT',
                      'ghostContainer' => false,
                      'formValues' => 
                      array (
                        'imgsrc' => 'MDB-a621df4d-5a02-4f2d-bd30-f873a4efa7ba-MDB',
                        'imageAlt' => '',
                        'imageTitle' => '',
                        'cropData' => '',
                        'imgHeight' => '100%',
                        'enableImageQuality' => false,
                        'imageQuality' => '85',
                      ),
                      'htmlClass' => '',
                      'children' => 
                      array (
                        0 => 
                        array (
                          'id' => 'MUNIT-61065983-55cf-4cd4-84e7-cc87bd272bf1-MUNIT',
                          'moduleId' => 'rz_style_animation_scroll',
                          'name' => '',
                          'templateUnitId' => 'MUNIT-6a3e6ce8-8950-4611-8092-0a98180a545e-MUNIT',
                          'ghostContainer' => false,
                          'formValues' => 
                          array (
                            'cssEnableAnimation' => 
                            array (
                              'type' => 'bp',
                              'default' => 'enabled',
                            ),
                            'cssAnimationIn' => 
                            array (
                              'type' => 'bp',
                              'default' => 'flipInY',
                            ),
                            'cssDuration' => 
                            array (
                              'type' => 'bp',
                              'default' => '400ms',
                            ),
                            'cssDelay' => 
                            array (
                              'type' => 'bp',
                              'default' => '600ms',
                            ),
                            'cssIteration' => 
                            array (
                              'type' => 'bp',
                              'default' => '1ms',
                            ),
                            'cssTrigger' => 
                            array (
                              'type' => 'bp',
                              'default' => 'visiblePart75',
                            ),
                            'cssOnlyOnce' => 
                            array (
                              'type' => 'bp',
                              'default' => false,
                            ),
                            'cssVisibilityHidden' => 
                            array (
                              'type' => 'bp',
                              'default' => true,
                            ),
                            'previewAnimations' => NULL,
                          ),
                          'htmlClass' => '',
                        ),
                      ),
                    ),
                    6 => 
                    array (
                      'id' => 'MUNIT-d7ba6cdb-3cf5-49ad-a80f-08aad5f06b9c-MUNIT',
                      'moduleId' => 'rz_image',
                      'name' => '',
                      'templateUnitId' => 'MUNIT-da8fd6d2-3597-4582-965e-a8e4cad59f3b-MUNIT',
                      'ghostContainer' => false,
                      'formValues' => 
                      array (
                        'imgsrc' => 'MDB-d1f964f7-b11f-4f0d-aeb2-8a58c9334421-MDB',
                        'imageAlt' => '',
                        'imageTitle' => '',
                        'cropData' => '',
                        'imgHeight' => '100%',
                        'enableImageQuality' => false,
                        'imageQuality' => '85',
                      ),
                      'htmlClass' => '',
                      'children' => 
                      array (
                        0 => 
                        array (
                          'id' => 'MUNIT-d41a5752-7cfa-4eb6-8346-b1b81cc07de8-MUNIT',
                          'moduleId' => 'rz_style_animation_scroll',
                          'name' => '',
                          'templateUnitId' => 'MUNIT-7eeeee8a-edb8-49fb-bafc-1e4448870b8c-MUNIT',
                          'ghostContainer' => false,
                          'formValues' => 
                          array (
                            'cssEnableAnimation' => 
                            array (
                              'type' => 'bp',
                              'default' => 'enabled',
                            ),
                            'cssAnimationIn' => 
                            array (
                              'type' => 'bp',
                              'default' => 'flipInY',
                            ),
                            'cssDuration' => 
                            array (
                              'type' => 'bp',
                              'default' => '400ms',
                            ),
                            'cssDelay' => 
                            array (
                              'type' => 'bp',
                              'default' => '500ms',
                            ),
                            'cssIteration' => 
                            array (
                              'type' => 'bp',
                              'default' => '1ms',
                            ),
                            'cssTrigger' => 
                            array (
                              'type' => 'bp',
                              'default' => 'visiblePart75',
                            ),
                            'cssOnlyOnce' => 
                            array (
                              'type' => 'bp',
                              'default' => false,
                            ),
                            'cssVisibilityHidden' => 
                            array (
                              'type' => 'bp',
                              'default' => true,
                            ),
                            'previewAnimations' => NULL,
                          ),
                          'htmlClass' => '',
                        ),
                      ),
                    ),
                    7 => 
                    array (
                      'id' => 'MUNIT-c8ade566-02da-4973-862e-415154efa2ee-MUNIT',
                      'moduleId' => 'rz_image',
                      'name' => '',
                      'templateUnitId' => 'MUNIT-77eed807-f68a-4698-ac68-f59f8835003a-MUNIT',
                      'ghostContainer' => false,
                      'formValues' => 
                      array (
                        'imgsrc' => 'MDB-b78d4071-3cee-4a84-8f86-c5dbb403bbb0-MDB',
                        'imageAlt' => '',
                        'imageTitle' => '',
                        'cropData' => '',
                        'imgHeight' => '100%',
                        'enableImageQuality' => false,
                        'imageQuality' => '85',
                      ),
                      'htmlClass' => '',
                      'children' => 
                      array (
                        0 => 
                        array (
                          'id' => 'MUNIT-578b2dd3-8962-42a3-8787-5a7bbcab9f45-MUNIT',
                          'moduleId' => 'rz_style_animation_scroll',
                          'name' => '',
                          'templateUnitId' => 'MUNIT-26f51785-1afc-4a72-8f29-d3d51c2a21b6-MUNIT',
                          'ghostContainer' => false,
                          'formValues' => 
                          array (
                            'cssEnableAnimation' => 
                            array (
                              'type' => 'bp',
                              'default' => 'enabled',
                            ),
                            'cssAnimationIn' => 
                            array (
                              'type' => 'bp',
                              'default' => 'flipInY',
                            ),
                            'cssDuration' => 
                            array (
                              'type' => 'bp',
                              'default' => '400ms',
                            ),
                            'cssDelay' => 
                            array (
                              'type' => 'bp',
                              'default' => '400ms',
                            ),
                            'cssIteration' => 
                            array (
                              'type' => 'bp',
                              'default' => '1ms',
                            ),
                            'cssTrigger' => 
                            array (
                              'type' => 'bp',
                              'default' => 'visiblePart75',
                            ),
                            'cssOnlyOnce' => 
                            array (
                              'type' => 'bp',
                              'default' => false,
                            ),
                            'cssVisibilityHidden' => 
                            array (
                              'type' => 'bp',
                              'default' => true,
                            ),
                            'previewAnimations' => NULL,
                          ),
                          'htmlClass' => '',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        4 => 
        array (
          'id' => 'MUNIT-05e4cd0f-43e2-45be-9e2e-73587419977f-MUNIT',
          'moduleId' => 'rz_textfield',
          'name' => 'Footer',
          'templateUnitId' => 'MUNIT-e1a6ef07-576c-4943-bfa0-650790a62ba2-MUNIT',
          'ghostContainer' => false,
          'formValues' => 
          array (
            'enableRteBold' => false,
            'enableRteItalic' => false,
            'enableRteUnderline' => false,
            'enableRteStrikethrough' => false,
            'enableRteSubscript' => false,
            'enableRteSuperscript' => false,
            'enableRteList' => false,
            'enableRteLink' => true,
            'enableRteTable' => false,
            'enableRteHeadline1' => false,
            'rteHeadline1Title' => 'Heading 1',
            'enableRteHeadline2' => false,
            'rteHeadline2Title' => 'Heading 2',
            'enableRteHeadline3' => false,
            'rteHeadline3Title' => 'Heading 3',
            'enableRteHeadline4' => false,
            'rteHeadline4Title' => 'Heading 4',
            'enableRteHeadline5' => false,
            'rteHeadline5Title' => 'Heading 5',
            'enableRteHeadline6' => false,
            'rteHeadline6Title' => 'Heading 6',
            'enableRteStyle1' => false,
            'rteStyle1Title' => '',
            'rteStyle1Element' => '',
            'enableRteStyle2' => false,
            'rteStyle2Title' => '',
            'rteStyle2Element' => '',
            'enableRteStyle3' => false,
            'rteStyle3Title' => '',
            'rteStyle3Element' => '',
            'enableRteStyle4' => false,
            'rteStyle4Title' => '',
            'rteStyle4Element' => '',
            'text' => '<p>© Café by the Lake – pictures by <a href="http://www.johanneselze.de/" target="_blank" data-cms-link="http://www.johanneselze.de/" data-cms-link-type="external">Johannes Elze</a> – made with <a href="https://rukzuk.com/" target="_blank" title="rukzuk - web design platform" data-cms-link="https://rukzuk.com/" data-cms-link-type="external">rukzuk</a></p>',
          ),
          'htmlClass' => '',
          'children' => 
          array (
            0 => 
            array (
              'id' => 'MUNIT-94662643-2b98-4d7d-8089-b922b6244aeb-MUNIT',
              'moduleId' => 'rz_style_border',
              'name' => '',
              'templateUnitId' => 'MUNIT-7cb375b2-bb3b-4984-a2da-46a7bf6f182f-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'cssEnableBorder' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssBorderColor' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssBorderStyle' => 
                array (
                  'type' => 'bp',
                  'default' => 'solid',
                ),
                'cssBorderWidth' => 
                array (
                  'type' => 'bp',
                  'default' => '1px',
                ),
                'cssEnableBorderTop' => 
                array (
                  'type' => 'bp',
                  'default' => true,
                ),
                'cssBorderTopColor' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssBorderTopStyle' => 
                array (
                  'type' => 'bp',
                  'default' => 'solid',
                ),
                'cssBorderTopWidth' => 
                array (
                  'type' => 'bp',
                  'default' => '2px',
                ),
                'cssEnableBorderRight' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssBorderRightColor' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssBorderRightStyle' => 
                array (
                  'type' => 'bp',
                  'default' => 'solid',
                ),
                'cssBorderRightWidth' => 
                array (
                  'type' => 'bp',
                  'default' => '1px',
                ),
                'cssEnableBorderBottom' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssBorderBottomColor' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssBorderBottomStyle' => 
                array (
                  'type' => 'bp',
                  'default' => 'solid',
                ),
                'cssBorderBottomWidth' => 
                array (
                  'type' => 'bp',
                  'default' => '1px',
                ),
                'cssEnableBorderLeft' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssBorderLeftColor' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssBorderLeftStyle' => 
                array (
                  'type' => 'bp',
                  'default' => 'solid',
                ),
                'cssBorderLeftWidth' => 
                array (
                  'type' => 'bp',
                  'default' => '1px',
                ),
              ),
              'htmlClass' => '',
            ),
            1 => 
            array (
              'id' => 'MUNIT-4f4f94ee-a5ef-4bc1-8f87-e02c34a117f3-MUNIT',
              'moduleId' => 'rz_style_font',
              'name' => '',
              'templateUnitId' => 'MUNIT-69d7ec5d-9516-4e3f-ab1a-1711c8cfbe21-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'cssEnableFontFamily' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssWebFontId' => 
                array (
                  'type' => 'bp',
                  'default' => '',
                ),
                'cssFontFamilyGoogle' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssFontFamily' => 
                array (
                  'type' => 'bp',
                  'default' => 'Arial, Helvetica, sans-serif',
                ),
                'cssEnableFontStyle' => 
                array (
                  'type' => 'bp',
                  '[object Object]' => true,
                  'default' => false,
                ),
                'cssFontWeight' => 
                array (
                  'type' => 'bp',
                  'default' => 400,
                ),
                'cssEnableItalic' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssEnableCaps' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssEnableFontSize' => 
                array (
                  'type' => 'bp',
                  '[object Object]' => true,
                  'default' => true,
                ),
                'cssFontSize' => 
                array (
                  'type' => 'bp',
                  'default' => '14px',
                ),
                'cssEnableFontSizeVw' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssFontSizeVw' => 
                array (
                  'type' => 'bp',
                  'default' => '1vw',
                ),
                'cssEnableColor' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssColor' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssEnableTextDecoration' => 
                array (
                  'type' => 'bp',
                  '[object Object]' => true,
                  'default' => false,
                ),
                'cssEnableUnderline' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssEnableOverline' => 
                array (
                  'type' => 'bp',
                  'default' => NULL,
                ),
                'cssEnableLineThrough' => 
                array (
                  'type' => 'bp',
                ),
                'cssEnableTextTransform' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssTextTransform' => 
                array (
                  'type' => 'bp',
                  'default' => 'uppercase',
                ),
                'cssEnableTextAlign' => 
                array (
                  'type' => 'bp',
                  'default' => true,
                ),
                'cssTextAlign' => 
                array (
                  'type' => 'bp',
                  'default' => 'right',
                ),
                'cssEnableLineHeight' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssLineHeight' => 
                array (
                  'type' => 'bp',
                  'default' => '130%',
                ),
                'cssEnableLetterSpacing' => 
                array (
                  'type' => 'bp',
                  'default' => false,
                ),
                'cssLetterSpacing' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
              ),
              'htmlClass' => '',
            ),
            2 => 
            array (
              'id' => 'MUNIT-a4e984cb-c3a8-46c1-923d-23afd477c109-MUNIT',
              'moduleId' => 'rz_style_padding_margin',
              'name' => '',
              'templateUnitId' => 'MUNIT-704fa635-4cb7-49bb-94a1-87fc29c01832-MUNIT',
              'ghostContainer' => false,
              'formValues' => 
              array (
                'cssEnablePadding' => 
                array (
                  'type' => 'bp',
                  'default' => true,
                ),
                'cssPaddingLeft' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssPaddingRight' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssPaddingTop' => 
                array (
                  'type' => 'bp',
                  'default' => '6px',
                ),
                'cssPaddingBottom' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssEnableMargin' => 
                array (
                  'type' => 'bp',
                  'default' => true,
                ),
                'cssMarginLeft' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssMarginRight' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssMarginTop' => 
                array (
                  'type' => 'bp',
                  'default' => '0px',
                ),
                'cssMarginBottom' => 
                array (
                  'type' => 'bp',
                  'default' => '31px',
                ),
              ),
              'htmlClass' => '',
            ),
          ),
        ),
      ),
    ),
  ),
)
;