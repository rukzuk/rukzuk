<?php
/**
 * (c) 2014 rukzuk AG
 * page meta
 * page id: PAGE-09c5dddd-ce7c-4d7a-b9e1-4909f209c09f-PAGE
 */
return
array (
  'id' => 'PAGE-09c5dddd-ce7c-4d7a-b9e1-4909f209c09f-PAGE',
  'websiteId' => 'SITE-8a779fba-bd52-44ef-8c15-433af76f4504-SITE',
  'templateId' => 'TPL-f03e6c83-3534-46a7-a01b-12955d48447b-TPL',
  'name' => 'Contact',
  'description' => '',
  'date' => '1413842400',
  'inNavigation' => true,
  'navigationTitle' => '',
  'mediaId' => '',
  'type' => 'page',
  'legacy' => false,
  'css' => 
  array (
    'file' => '724660f66d04b5a3dbc91e905d5227a4.css',
    'url' => '724660f66d04b5a3dbc91e905d5227a4.css?m=1434548416',
  ),
)
;