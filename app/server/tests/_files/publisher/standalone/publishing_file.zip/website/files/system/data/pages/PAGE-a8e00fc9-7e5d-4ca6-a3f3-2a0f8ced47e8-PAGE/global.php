<?php
/**
 * (c) 2014 rukzuk AG
 * page global variables
 * page id: PAGE-a8e00fc9-7e5d-4ca6-a3f3-2a0f8ced47e8-PAGE
 */
return
array (
  'lang' => 
  array (
    0 => 
    array (
      'unitId' => 'MUNIT-efd4db7a-28c0-4ee1-aa7a-562188a8ff2f-MUNIT',
      'templateUnitId' => 'MUNIT-7afafb67-119e-4e95-a538-81a140899255-MUNIT',
      'moduleId' => 'rz_root',
      'value' => 'en-US',
      'isUnitValue' => true,
    ),
  ),
)
;