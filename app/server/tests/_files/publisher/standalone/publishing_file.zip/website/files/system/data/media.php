<?php
/**
 * (c) 2014 rukzuk AG
 * media info array
 * site: SITE-8a779fba-bd52-44ef-8c15-433af76f4504-SITE
 */
return
array (
  'MDB-c32c5c61-a1b1-42fb-9c87-5218413c4755-MDB' => 
  array (
    'id' => 'MDB-c32c5c61-a1b1-42fb-9c87-5218413c4755-MDB',
    'file' => '06f225ffb0edee636c02bdef2e173cfb.svg',
    'name' => 'image.svg',
    'size' => '7221',
    'lastModified' => '1433944828',
  ),
  'MDB-f757f5b1-d6e0-4b67-97f5-d25fc40f16ed-MDB' => 
  array (
    'id' => 'MDB-f757f5b1-d6e0-4b67-97f5-d25fc40f16ed-MDB',
    'file' => '76e9b090693e718039d29a1038876964.jpg',
    'name' => 'RZ-1134.jpg',
    'size' => '322065',
    'lastModified' => '1433944828',
  ),
  'MDB-b0dcfb0e-47c0-430f-9135-02d47b506c16-MDB' => 
  array (
    'id' => 'MDB-b0dcfb0e-47c0-430f-9135-02d47b506c16-MDB',
    'file' => '59168b13b19ce7167572219db574918e.jpg',
    'name' => 'RZ-1329.jpg',
    'size' => '264155',
    'lastModified' => '1433944828',
  ),
  'MDB-d1f964f7-b11f-4f0d-aeb2-8a58c9334421-MDB' => 
  array (
    'id' => 'MDB-d1f964f7-b11f-4f0d-aeb2-8a58c9334421-MDB',
    'file' => '5e0a289ee44eebe7208caf59b42f8b54.jpg',
    'name' => 'RZ-2302.jpg',
    'size' => '282399',
    'lastModified' => '1433944828',
  ),
  'MDB-b78d4071-3cee-4a84-8f86-c5dbb403bbb0-MDB' => 
  array (
    'id' => 'MDB-b78d4071-3cee-4a84-8f86-c5dbb403bbb0-MDB',
    'file' => '1afe456cae0ce00f14c417f40a715375.jpg',
    'name' => 'RAWFOOD-4442.jpg',
    'size' => '213521',
    'lastModified' => '1433944828',
  ),
  'MDB-11cbdcf5-a10a-4ff2-9007-522d51318469-MDB' => 
  array (
    'id' => 'MDB-11cbdcf5-a10a-4ff2-9007-522d51318469-MDB',
    'file' => '7892817fbfd8de8b752f02f14c771aef.jpg',
    'name' => 'RZ-0706.jpg',
    'size' => '247267',
    'lastModified' => '1433944828',
  ),
  'MDB-11de25a8-19a8-4544-800f-68dda3bd5dce-MDB' => 
  array (
    'id' => 'MDB-11de25a8-19a8-4544-800f-68dda3bd5dce-MDB',
    'file' => 'a1219708a4068366a141175bb7d70720.jpg',
    'name' => 'RZ-1463.jpg',
    'size' => '194966',
    'lastModified' => '1433944828',
  ),
  'MDB-4491463e-1fd0-4dec-b50c-2d0a87278b8d-MDB' => 
  array (
    'id' => 'MDB-4491463e-1fd0-4dec-b50c-2d0a87278b8d-MDB',
    'file' => '7e16b15591217225f2dda13d6e90cb89.jpg',
    'name' => 'RZ-1606.jpg',
    'size' => '345764',
    'lastModified' => '1433944828',
  ),
  'MDB-a621df4d-5a02-4f2d-bd30-f873a4efa7ba-MDB' => 
  array (
    'id' => 'MDB-a621df4d-5a02-4f2d-bd30-f873a4efa7ba-MDB',
    'file' => 'e48ab336e5d0f315e606dcf9ad632616.jpg',
    'name' => 'RZ-1683.jpg',
    'size' => '249622',
    'lastModified' => '1433944828',
  ),
  'MDB-20fa92fd-d6d6-4c30-8de0-bd5f47a4cbcd-MDB' => 
  array (
    'id' => 'MDB-20fa92fd-d6d6-4c30-8de0-bd5f47a4cbcd-MDB',
    'file' => '220ec089f4cbd4e8610589bf5fef5902.jpg',
    'name' => 'RAWFOOD-4045.jpg',
    'size' => '261437',
    'lastModified' => '1433944828',
  ),
)
;