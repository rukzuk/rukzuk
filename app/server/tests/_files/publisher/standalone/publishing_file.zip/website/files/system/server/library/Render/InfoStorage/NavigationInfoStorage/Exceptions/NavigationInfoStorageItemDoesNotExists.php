<?php
 /**
 * Author: Heiko Schwarz <heiko.schwarz@rukzuk.com>
 * Date: 13.01.14
 * (c) 2014 rukzuk AG
 */

namespace Render\InfoStorage\NavigationInfoStorage\Exceptions;

class NavigationInfoStorageItemDoesNotExists extends \Exception
{

}
