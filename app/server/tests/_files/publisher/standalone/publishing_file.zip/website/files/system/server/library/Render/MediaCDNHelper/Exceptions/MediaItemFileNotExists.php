<?php
 /**
 * Author: Heiko Schwarz <heiko.schwarz@rukzuk.com>
 * Date: 10.02.14
 * (c) 2014 rukzuk AG
 */

namespace Render\MediaCDNHelper\Exceptions;

class MediaItemFileNotExists extends \Exception
{

}
