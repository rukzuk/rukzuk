<?php
namespace Seitenbau\Image;

/**
 * Image Exception
 *
 * @author       Heiko Schwarz <schwarz@seitenbau.com>
 * @copyright    Copyright (c) 2011, Seitenbau GmbH
 * @package      Seitenbau
 * @subpackage   Image
 */

class ImageException extends \Exception
{
}
