<?php
/**
 * @copyright   Copyright &copy; 2015, rukzuk AG
 */
namespace Render;

if (isset($_GET['__debug'])) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
}

$installPath = realpath(__DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR);
require_once($installPath . DIRECTORY_SEPARATOR . 'files' . DIRECTORY_SEPARATOR . 'system' . DIRECTORY_SEPARATOR . 'server' . DIRECTORY_SEPARATOR . 'bootstrap.php');
$renderer = new LiveRenderer('PAGE-a8e00fc9-7e5d-4ca6-a3f3-2a0f8ced47e8-PAGE');
$renderer->renderHtml();
