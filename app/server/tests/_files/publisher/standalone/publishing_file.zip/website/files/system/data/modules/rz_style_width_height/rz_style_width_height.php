<?php
namespace Rukzuk\Modules;

class rz_style_width_height extends SimpleModule { }
