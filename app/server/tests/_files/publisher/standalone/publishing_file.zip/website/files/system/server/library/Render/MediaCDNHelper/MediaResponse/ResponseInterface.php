<?php
 /**
 * Author: Heiko Schwarz <heiko.schwarz@rukzuk.com>
 * Date: 04.02.14
 * (c) 2014 rukzuk AG
 */

namespace Render\MediaCDNHelper\MediaResponse;

interface ResponseInterface
{
  /**
   * Returns the http status code
   *
   * @return int
   */
  public function getResponseCode();

  /**
   * Returns the http headers
   *
   * @return array
   */
  public function getHeaders();

  /**
   * Output the requested media item
   */
  public function outputBody();
}
