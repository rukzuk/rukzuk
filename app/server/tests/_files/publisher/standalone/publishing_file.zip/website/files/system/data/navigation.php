<?php
/**
 * (c) 2014 rukzuk AG
 * navigation info array
 * site: SITE-8a779fba-bd52-44ef-8c15-433af76f4504-SITE
 */
return
array (
  'PAGE-b2b73b09-cef7-4571-b959-fe92eede6757-PAGE' => 
  array (
    'id' => 'PAGE-b2b73b09-cef7-4571-b959-fe92eede6757-PAGE',
    'pageType' => 'page',
    'name' => 'Home',
    'description' => '',
    'date' => 1411077600,
    'inNavigation' => true,
    'navigationTitle' => '',
    'mediaId' => '',
  ),
  'PAGE-26918879-8c46-4d19-bf60-13b2f7ae01c9-PAGE' => 
  array (
    'id' => 'PAGE-26918879-8c46-4d19-bf60-13b2f7ae01c9-PAGE',
    'pageType' => 'page',
    'name' => 'Menu',
    'description' => '',
    'date' => 1413842400,
    'inNavigation' => true,
    'navigationTitle' => '',
    'mediaId' => '',
  ),
  'PAGE-a8e00fc9-7e5d-4ca6-a3f3-2a0f8ced47e8-PAGE' => 
  array (
    'id' => 'PAGE-a8e00fc9-7e5d-4ca6-a3f3-2a0f8ced47e8-PAGE',
    'pageType' => 'page',
    'name' => 'Gallery',
    'description' => '',
    'date' => 1413842400,
    'inNavigation' => true,
    'navigationTitle' => '',
    'mediaId' => '',
  ),
  'PAGE-09c5dddd-ce7c-4d7a-b9e1-4909f209c09f-PAGE' => 
  array (
    'id' => 'PAGE-09c5dddd-ce7c-4d7a-b9e1-4909f209c09f-PAGE',
    'pageType' => 'page',
    'name' => 'Contact',
    'description' => '',
    'date' => 1413842400,
    'inNavigation' => true,
    'navigationTitle' => '',
    'mediaId' => '',
  ),
)
;