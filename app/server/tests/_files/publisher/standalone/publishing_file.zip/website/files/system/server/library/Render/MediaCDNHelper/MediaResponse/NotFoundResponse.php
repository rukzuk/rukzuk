<?php
 /**
 * Author: Heiko Schwarz <heiko.schwarz@rukzuk.com>
 * Date: 04.02.14
 * (c) 2014 rukzuk AG
 */

namespace Render\MediaCDNHelper\MediaResponse;

class NotFoundResponse extends ErrorResponse
{
  /**
   * @return int
   */
  public function getResponseCode()
  {
    return 404;
  }
}
