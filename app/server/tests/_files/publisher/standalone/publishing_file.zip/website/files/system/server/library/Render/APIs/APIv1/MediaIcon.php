<?php
/**
 * Author: Michael Trunner <michael.trunner@rukzuk.com>
 * Date: 09.01.14
 * (c) 2014 rukzuk AG
 */

namespace Render\APIs\APIv1;

class MediaIcon extends MediaImage
{

  protected function getFilePath()
  {
    $mediaId = $this->getMediaItem()->getId();
    $infoStorage = $this->getMediaContext()->getMediaInfoStorage();
    return $infoStorage->getItem($mediaId)->getIconFilePath();
  }

  public function getUrl()
  {
    return $this->getMediaContext()->getMediaInfoStorage()->getIconUrl(
        $this->getMediaId(),
        $this->getImageOperations()
    );
  }
}
