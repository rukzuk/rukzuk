<?php
/**
 * Author: Michael Trunner <michael.trunner@rukzuk.com>
 * Date: 03.12.13
 * (c) 2013 rukzuk AG
 */

namespace Render\APIs\RootAPIv1;

use Render\APIs\APIv1\APIv1Factory;
use Render\Visitors\AbstractVisitor;

class RootAPIv1Factory extends APIv1Factory
{

  /**
   * @param AbstractVisitor $renderingVisitor
   *
   * @return RootRenderAPI
   */
  public function getRenderAPI(AbstractVisitor $renderingVisitor)
  {
    return new RootRenderAPI($renderingVisitor, $this->getNodeTree(), $this->getRenderContext());
  }

  /**
   * @return RootCssAPI
   */
  public function getCSSAPI()
  {
    return new RootCssAPI($this->getNodeTree(), $this->getRenderContext());
  }
}
