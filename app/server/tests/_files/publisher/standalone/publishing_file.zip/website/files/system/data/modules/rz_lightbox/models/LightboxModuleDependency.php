<?php
require_once( dirname( __FILE__ ) . "/ILightboxModuleDependency.php" );

/**
 * @author       Christian Pergande <christian.pergande@rukzuk.com>
 * @since        May 09, 2014
 * @copyright    Copyright (c) 2014, rukzuk AG, All rights reserved.
 */
class LightboxModuleDependency implements ILightboxModuleDependency{

	public function isInsideModule( $renderApi, $unit, $parentModuleId ) {
		$formUnit = $renderApi->getParentUnit($unit);
		while ( isset( $formUnit ) && $renderApi->getModuleInfo( $formUnit )->getId() !== $parentModuleId ) {
			$formUnit = $renderApi->getParentUnit( $formUnit );
		}
		return isset($formUnit);
	}
}