<?php
/**
 * Author: Michael Trunner <michael.trunner@rukzuk.com>
 * Date: 08.01.14
 * (c) 2014 rukzuk AG
 */

namespace Render\ImageToolFactory;

interface IImageToolFactory
{

  /**
   * @return ImageTool
   */
  public function createImageTool();
}
