<?php
/**
 * (c) 2014 rukzuk AG
 * website settings info array
 * site: SITE-8a779fba-bd52-44ef-8c15-433af76f4504-SITE
 */
return
array (
  'rz_shop' => 
  array (
    'currency' => 'EUR',
    'vat' => '19%',
    'cartPage' => NULL,
    'tosPage' => NULL,
    'thanksText' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
    'shippingCosts' => 5,
    'paymentInvoice' => true,
    'paymentInvoiceDesc' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
    'paymentBanktransfer' => false,
    'paymentBanktransferDesc' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
    'emailConfirmationText' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
    'emailNotificationAddress' => '',
    'paymentPayPalExpress' => false,
    'paymentPayPalExpressApiSandboxMode' => true,
    'countryList' => 'DE:Germany
AT:Austria
CH:Switzerland',
  ),
)
;