<?php
/**
 * Author: Michael Trunner <michael.trunner@rukzuk.com>
 * Date: 10.01.14
 * (c) 2014 rukzuk AG
 */

namespace Render\APIs\APIv1;

class MediaImageInvalidException extends MediaException
{

  public function __construct()
  {
    parent::__construct('Invalid image format');
  }
}
