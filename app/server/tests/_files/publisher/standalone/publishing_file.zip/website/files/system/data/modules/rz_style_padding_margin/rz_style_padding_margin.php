<?php
namespace Rukzuk\Modules;

class rz_style_padding_margin extends SimpleModule { }
