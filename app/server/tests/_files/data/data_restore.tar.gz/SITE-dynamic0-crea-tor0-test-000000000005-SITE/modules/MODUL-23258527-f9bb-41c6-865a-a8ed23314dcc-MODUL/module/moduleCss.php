<?php namespace Dual\Render; ?>
body {
  <?php if ($this->get('enablebgimage') == 1) { ?>
  background-image: url('<?php echo MediaDb::getImageUrl($this->get('bgimage')); ?>');
  background-repeat: <?php $this->p('bgrepeat'); ?>;
  background-attachment: <?php $this->p('bgattachment'); ?>;
  <?php } ?>
  <?php if ($this->get('enablebgcolor') == 1) { ?>
  background-color: <?php $this->p('bgcolor'); ?>;
  <?php } ?>

  <?php if ($this->get('enablegradient') == 1) { ?>
  background-image: -webkit-gradient(linear, 0 0, 0 <?php $this->p('gradientdirection'); ?>, from(<?php $this->p('gradientcolor1'); ?>), to(<?php $this->p('gradientcolor2'); ?>));
  background-image: -moz-linear-gradient(<?php $this->p('gradientdirection'); ?>, <?php $this->p('gradientcolor1'); ?>, <?php $this->p('gradientcolor2'); ?>);
  background-image: linear-gradient(<?php $this->p('gradientdirection'); ?>, <?php $this->p('gradientcolor1'); ?>, <?php $this->p('gradientcolor2'); ?>);
  -pie-background-image: linear-gradient(<?php $this->p('gradientdirection'); ?>, <?php $this->p('gradientcolor1'); ?>, <?php $this->p('gradientcolor2'); ?>);
  <?php } ?>


  /*Standardtypo*/
  font-family:<?php $this->p('fontB'); ?>;
  color:<?php $this->p('colorB'); ?>;
  font-size:<?php $this->p('sizeB'); ?>px;
  line-height:<?php $this->p('heightB'); ?>%;

  <?php $this->p('cssbody'); ?>

}

<?php if (RenderContext::MODE_EDIT == $this->getMode()) { ?>
#<?php echo $this->getId(); ?> {
  padding:0;
  margin: 0;
  width: 140px;
  position:fixed;
  bottom: 0;
  left: 0;
  background-color: rgba(255,255,255,.8);
}

#<?php echo $this->getId(); ?> .head {
  font-weight: bold;
  color: #fff;
  font-size: 12px;
  background-color: #444;
  padding: 0 5px;
}
#<?php echo $this->getId(); ?> .text{
  padding:  2px 5px 5px 5px;
  font-size: 11px;
}

<?php } ?>

<?php if ($this->get('enablelink') == 1) { ?>
a {
  color: <?php $this->p('linkcolor'); ?>;
  text-decoration: <?php $this->p('linktextdecoration'); ?>
}
<?php } ?>

<?php if ($this->get('enablelinkhover') == 1) { ?>
a:hover {
  color: <?php $this->p('linkcolorhover'); ?>;
  text-decoration: <?php $this->p('linktextdecorationhover'); ?>
}
<?php } ?>

/* Font
*****************************************/
/*Ueberschriften*/
<?php for ($i=1;$i<=4;$i++) {
if($this->get('enableH'.$i)==1) {
?>
h<?php echo $i; ?> {
  font-family:<?php $this->p('fontH'.$i); ?>;
  color:<?php $this->p('colorH'.$i); ?>;
  font-size:<?php $this->p('sizeH'.$i); ?>px;
  line-height:<?php $this->p('heightH'.$i); ?>%;
  font-weight:<?php echo ($this->get('weightH'.$i)==1) ? 'bold' : 'normal'; ?>;
  font-style:<?php echo ($this->get('styleH'.$i)==1) ? 'italic' : 'normal'; ?>;
  text-decoration:<?php echo ($this->get('decorationH'.$i)==1) ? 'underline' : 'none'; ?>;
  margin-top:<?php $this->p('mtopH'.$i); ?>px;
  margin-bottom:<?php $this->p('mbottomH'.$i); ?>px;
}
<?php
}
} ?>
/*Absatz*/
<?php if($this->get('enableP')==1) { ?>
p {
  font-family:<?php $this->p('fontP'); ?>;
  color:<?php $this->p('colorP'); ?>;
  font-size:<?php $this->p('sizeP'); ?>px;
  line-height:<?php $this->p('heightP'); ?>%;
  font-weight:<?php echo ($this->get('weightP')==1) ? 'bold' : 'normal'; ?>;
  font-style:<?php echo ($this->get('styleP')==1) ? 'italic' : 'normal'; ?>;
  text-decoration:<?php echo ($this->get('decorationP')==1) ? 'underline' : 'none'; ?>;
  margin-top:<?php $this->p('mtopP'); ?>px;
  margin-bottom:<?php $this->p('mbottomP'); ?>px;
}
<?php } ?>
/*Link*/
<?php if($this->get('enableA')==1) { ?>
a, a:link {
  color:<?php $this->p('colorA'); ?>;
  font-weight:<?php echo ($this->get('weightA')==1) ? 'bold' : 'normal'; ?>;
  font-style:<?php echo ($this->get('styleA')==1) ? 'italic' : 'normal'; ?>;
  text-decoration:<?php echo ($this->get('decorationA')==1) ? 'underline' : 'none'; ?>;
}
<?php } ?>
<?php if($this->get('enableAvisit')==1) { ?>
a:visited {
  color:<?php $this->p('colorAvisit'); ?>;
  font-weight:<?php echo ($this->get('weightAvisit')==1) ? 'bold' : 'normal'; ?>;
  font-style:<?php echo ($this->get('styleAvisit')==1) ? 'italic' : 'normal'; ?>;
  text-decoration:<?php echo ($this->get('decorationAvisit')==1) ? 'underline' : 'none'; ?>;
}
<?php } ?>
<?php if($this->get('enableAhover')==1) { ?>
a:hover, a:focus {
  color:<?php $this->p('colorAhover'); ?>;
  font-weight:<?php echo ($this->get('weightAhover')==1) ? 'bold' : 'normal'; ?>;
  font-style:<?php echo ($this->get('styleAhover')==1) ? 'italic' : 'normal'; ?>;
  text-decoration:<?php echo ($this->get('decorationAhover')==1) ? 'underline' : 'none'; ?>;
}
<?php } ?>
/*listen*/
<?php if($this->get('enableL')==1) { ?>
ul, ol {
  font-family:<?php $this->p('fontL'); ?>;
  color:<?php $this->p('colorL'); ?>;
  font-size:<?php $this->p('sizeL'); ?>px;
  line-height:<?php $this->p('heightL'); ?>%;
  font-weight:<?php echo ($this->get('weightL')==1) ? 'bold' : 'normal'; ?>;
  font-style:<?php echo ($this->get('styleL')==1) ? 'italic' : 'normal'; ?>;
  text-decoration:<?php echo ($this->get('decorationL')==1) ? 'underline' : 'none'; ?>;
  margin-top:<?php $this->p('mtopL'); ?>px;
  margin-bottom:<?php $this->p('mbottomL'); ?>px;
}
ul {
  list-style-type:<?php $this->p('listenstyleUL'); ?>;
}
ol {
  list-style-type:<?php $this->p('listenstyleOL'); ?>;
}
<?php } ?>

  /* Image
  *****************************************/
  .picture {
    <?php if ($this->get('enablepicturebgcolor') == 1) { ?>
      background-color: <?php $this->p('picturebgcolor'); ?>;
    <?php } ?>
    <?php if ($this->get('enablepicturecorners') == 1) { ?>
      border-radius: <?php $this->p('pictureborderradius1'); ?>px <?php $this->p('pictureborderradius2'); ?>px <?php $this->p('pictureborderradius3'); ?>px <?php $this->p('pictureborderradius4'); ?>px;
      -moz-border-radius: <?php $this->p('pictureborderradius1'); ?>px <?php $this->p('pictureborderradius2'); ?>px <?php $this->p('pictureborderradius3'); ?>px <?php $this->p('pictureborderradius4'); ?>px;
      -webkit-radius: <?php $this->p('pictureborderradius1'); ?>px <?php $this->p('pictureborderradius2'); ?>px <?php $this->p('pictureborderradius3'); ?>px <?php $this->p('pictureborderradius4'); ?>px;
    <?php } ?>
    <?php if ($this->get('enablepicturegradient') == 1) { ?>
      background: -webkit-gradient(linear, 0 0, 0 <?php $this->p('picturegradientdirection'); ?>, from(<?php $this->p('picturegradientcolor1'); ?>), to(<?php $this->p('picturegradientcolor2'); ?>));
      background: -moz-linear-gradient(<?php $this->p('picturegradientdirection'); ?>, <?php $this->p('picturegradientcolor1'); ?>, <?php $this->p('picturegradientcolor2'); ?>);
      background: linear-gradient(<?php $this->p('picturegradientdirection'); ?>, <?php $this->p('picturegradientcolor1'); ?>, <?php $this->p('picturegradientcolor2'); ?>);
      -pie-background: linear-gradient(<?php $this->p('picturegradientdirection'); ?>, <?php $this->p('picturegradientcolor1'); ?>, <?php $this->p('picturegradientcolor2'); ?>);
    <?php } ?>
    <?php if ($this->get('enablepictureshadow') == 1) { ?>
      -webkit-box-shadow: <?php $this->p('pictureshadowcolor'); ?> <?php $this->p('pictureshadowoffsetx'); ?>px <?php $this->p('pictureshadowoffsety'); ?>px <?php $this->p('pictureshadowblur'); ?>px;
      -moz-box-shadow: <?php $this->p('pictureshadowcolor'); ?> <?php $this->p('pictureshadowoffsetx'); ?>px <?php $this->p('pictureshadowoffsety'); ?>px <?php $this->p('pictureshadowblur'); ?>px;
      box-shadow: <?php $this->p('pictureshadowcolor'); ?> <?php $this->p('pictureshadowoffsetx'); ?>px <?php $this->p('pictureshadowoffsety'); ?>px <?php $this->p('pictureshadowblur'); ?>px;
      <?php echo ($this->get('pictureshadowoffsetx')>=0) ? 'margin-right:'.$this->get('pictureshadowblur').'px;' : 'margin-left:'.$this->get('pictureshadowblur').'px;'; ?>
      <?php echo ($this->get('pictureshadowoffsety')>=0) ? 'margin-bottom:'.$this->get('pictureshadowblur').'px;' : 'margin-top:'.$this->get('pictureshadowblur').'px;'; ?>
    <?php } ?>
    <?php if ($this->get('enablepictureborder') == 1) { ?>
      <?php if ($this->get('pictureborderleft') == 1) { ?>
        border-left: <?php $this->p('pictureborderwidth'); ?>px <?php $this->p('pictureborderstyle'); ?> <?php $this->p('picturebordercolor'); ?>;
      <?php } ?>
      <?php if ($this->get('pictureborderright') == 1) { ?>
        border-right: <?php $this->p('pictureborderwidth'); ?>px <?php $this->p('pictureborderstyle'); ?> <?php $this->p('picturebordercolor'); ?>;
      <?php } ?>
      <?php if ($this->get('picturebordertop') == 1) { ?>
        border-top: <?php $this->p('pictureborderwidth'); ?>px <?php $this->p('pictureborderstyle'); ?> <?php $this->p('picturebordercolor'); ?>;
      <?php } ?>
      <?php if ($this->get('pictureborderbottom') == 1) { ?>
        border-bottom: <?php $this->p('pictureborderwidth'); ?>px <?php $this->p('pictureborderstyle'); ?> <?php $this->p('picturebordercolor'); ?>;
      <?php } ?>
     <?php } ?>
  }
  .picture div {
    <?php if ($this->get('enablepicturemargin') == 1) { ?>
      margin-left: <?php $this->p('picturemarginleft'); ?>px;
      margin-right: <?php $this->p('picturemarginright'); ?>px;
      margin-top: <?php $this->p('picturemargintop'); ?>px;
      margin-bottom: <?php $this->p('picturemarginbottom'); ?>px;
    <?php } ?>
  }
  .picture p {
    <?php if($this->get('enablepicturetext')==1) { ?>
        font-family:<?php $this->p('picturefontP'); ?>;
        color:<?php $this->p('picturecolorP'); ?>;
        font-size:<?php $this->p('picturesizeP'); ?>px;
        line-height:<?php $this->p('pictureheightP'); ?>%;
        font-weight:<?php echo ($this->get('pictureweightP')==1) ? 'bold' : 'normal'; ?>;
        font-style:<?php echo ($this->get('picturestyleP')==1) ? 'italic' : 'normal'; ?>;
        text-decoration:<?php echo ($this->get('picturedecorationP')==1) ? 'underline' : 'none'; ?>;
        margin-top:<?php $this->p('picturemtopP'); ?>px;
        margin-bottom:<?php $this->p('picturembottomP'); ?>px;
   <?php } ?>
  }

<?php $this->p('csscommon'); ?>


