<?php namespace Dual\Render; ?>
<?php
  global $unitwidth;
  global $imageframewidth;
  $unitwidth = 960;
  $imageframewidth = 0;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="description" content="<?php $this->p('description'); ?>" />
    <meta name="content-language" content="de" />
    <title><?php $this->p('title'); ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->getAssetUrl(); ?>/reset.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="<?php echo $this->getAssetUrl(); ?>/js/fancybox/jquery.fancybox-1.3.1.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="<?php echo $this->getAssetUrl(); ?>/js/skins_jcarousel/tango/skin.css" />
    <script language="javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="<?php echo $this->getAssetUrl(); ?>/js/fancybox/jquery.fancybox-1.3.1.js"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/swfobject/2/swfobject.js"></script>
    <script type="text/javascript" src="<?php echo $this->getAssetUrl(); ?>/js/jquery.jcarousel.min.js"></script>    
    <script type="text/javascript" src="<?php echo $this->getAssetUrl(); ?>/js/jquery.tweet.js"></script>
    <script type="text/javascript" src="<?php echo $this->getAssetUrl(); ?>/js/jqueryui173.js"></script>
    <script type="text/javascript" src="<?php echo $this->getAssetUrl(); ?>/js/cross-slide.min.js"></script>
    <script type="text/javascript" src="<?php echo $this->getAssetUrl(); ?>/js/jcoverflip.js"></script>
    
    <style type="text/css" media="all">
      <?php $this->insertCss(); ?>
    </style>    
    
    <?php
    $this->insertHead();
    ?>
  </head>
  <body>
    <?php
      if (RenderContext::MODE_EDIT == $this->getMode()) { 
        $desc = $this->get('description');
        if (strlen($desc) > 200) {
          $desc = substr($desc,0,150)."...";
        }
    ?>
    <div class="isModule" id="<?php echo $this->getId(); ?>">
      <span class="head">Seitentitel</span>
      <div class="text"><?php $this->p('title'); ?></div>
      <span class="head">Beschreibungstext</span>
      <div class="text"><?php echo $desc; ?></div>      
    </div>
    <?php } ?>
    
    <?php $this->renderChilds(); ?>
  </body>
</html>