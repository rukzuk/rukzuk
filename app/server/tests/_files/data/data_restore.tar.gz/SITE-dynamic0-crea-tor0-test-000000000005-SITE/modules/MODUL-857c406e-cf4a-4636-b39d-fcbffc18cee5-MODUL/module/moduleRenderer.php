<?php namespace Dual\Render; ?>
<?php
  global $unitwidth;
  $tempwidth = $unitwidth;
  global $imageframewidth;
  $tempframewidth = $imageframewidth;
  
  // Berechnung das Raumes für den Bildrahmen
  if ($this->get('enablepictureborder') == 1) {
    if ($this->get('pictureborderright') == 1) {
      $imageframewidth = $imageframewidth+$this->get('pictureborderwidth');
    }
    if ($this->get('pictureborderleft') == 1) {
      $imageframewidth = $imageframewidth+$this->get('pictureborderwidth');
    }
  }
  if ($this->get('enablepicturemargin') == 1) {
    $imageframewidth = $imageframewidth + ($this->get('picturemarginleft') + $this->get('picturemarginright'));
  }
  if ($this->get('enablepictureshadow') == 1) {
    $imageframewidth = $imageframewidth + $this->get('pictureshadowblur');
  }
  
  $thiswidth = $unitwidth * $this->get('containerwidth') / 100;
  $unitwidth = $thiswidth;
  if ($this->get('enablemargin') == 1) {
    $unitwidth = $unitwidth-$this->get('marginleft')-$this->get('marginright'); 
  }
  if ($this->get('enablepadding') == 1) {
    $unitwidth = $unitwidth-$this->get('paddingleft')-$this->get('paddingright');
  }
  if ($this->get('enableborder') == 1) {
    if ($this->get('borderleft') == 1) {
      $unitwidth = $unitwidth-$this->get('borderwidth');
    }
    if ($this->get('borderright') == 1) {
      $unitwidth = $unitwidth-$this->get('borderwidth');
    }
  }
?>
<div style="width:<?php echo $thiswidth; ?>px; float:<?php $this->p('float'); ?>" id="P<?php echo $this->getId(); ?>">
  <div class="isModule"  id="<?php echo $this->getId(); ?>" >
    <?php if (($this->get('isInserter') == 1) && ($this->getMode() == "EDIT" )) { ?>
    <div style="float:right;background-color:yellow;padding:3px"><?php $this->p('insertertext'); ?></div><br style="clear:both" />
    <?php } ?>
   
    <?php $this->renderChilds(); ?>
  </div>
</div>

<?php
  $unitwidth = $tempwidth;
  $imageframewidth = $tempframewidth;
?>


