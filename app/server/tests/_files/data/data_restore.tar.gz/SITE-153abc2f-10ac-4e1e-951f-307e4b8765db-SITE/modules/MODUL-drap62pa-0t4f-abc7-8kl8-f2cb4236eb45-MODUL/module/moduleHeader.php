<?php namespace Dual\Render; ?>
some_header