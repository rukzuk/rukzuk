<?php namespace Dual\Render; ?>
some_css