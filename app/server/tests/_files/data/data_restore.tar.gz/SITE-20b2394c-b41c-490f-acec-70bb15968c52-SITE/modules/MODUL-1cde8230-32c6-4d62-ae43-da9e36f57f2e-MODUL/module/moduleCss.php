<?php namespace Dual\Render; ?>
#<?php echo $this->getId(); ?> {
  margin:<?php $this->p('margintop'); ?>px <?php $this->p('marginright'); ?>px <?php $this->p('marginbottom'); ?>px <?php $this->p('marginleft'); ?>px;
  width: <?php $this->p('width'); ?>px;
  float:left;
}

.download {
  background: url(<?php echo $this->getAssetUrl(); ?>/disk.png) no-repeat left center;
  padding-left: 20px;
  line-height: 18px;
}
<?php
global $cmsStyles;
/* CSS-Klasse mit der Definition des Schriftstils ausgeben */
if ($this->get('classlinkhover') != "") {
  echo "#".$this->getId()." a:hover {".$cmsStyles[$this->get('classlinkhover')]."}";
}
?>

