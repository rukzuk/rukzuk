<?php namespace Dual\Render; ?>
<script src="http://widgets.twimg.com/j/2/widget.js"></script>
