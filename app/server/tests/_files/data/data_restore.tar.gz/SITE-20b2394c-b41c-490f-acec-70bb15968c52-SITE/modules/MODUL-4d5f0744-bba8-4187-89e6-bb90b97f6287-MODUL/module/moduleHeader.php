<?php namespace Dual\Render; ?>
<?php if (($this->getMode() == "EDIT" ) && ($this->isTemplate())) { ?>  
<script type="text/javascript">
$(document).ready(function() { 
    CMS.on('CMSconfigchange', function (config) {
        unit = $('#'+config.unitId);
        if (unit.attr('data-cms-autowidth') == "true") {
            parentwidth = unit.parents('[data-cms-autowidth="true"]').first().width();
            
            if (config.key == 'width') {
                unit.width(config.newValue);
                width = config.newValue;
                widthpercent = (unit.outerWidth(true)/parentwidth)*100;
                CMS.set(config.unitId, 'widthpercent', widthpercent);
                CMS.preventRendering();
            }
            if (config.key == 'widthpercent') {
                delta = unit.outerWidth(true) - unit.width();
                width = Math.round(((config.newValue*parentwidth)/100)-delta);
                unit.width(width);
                CMS.set(config.unitId, 'width', width);
                CMS.preventRendering();      
            }   
        }
    });   
});
</script>
<?php } ?>
