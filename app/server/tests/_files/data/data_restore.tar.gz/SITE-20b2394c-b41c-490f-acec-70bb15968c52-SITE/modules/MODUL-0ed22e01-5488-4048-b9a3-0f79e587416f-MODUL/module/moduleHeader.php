<?php namespace Dual\Render; ?>
<link rel="stylesheet" type="text/css" href="<?php echo $this->getAssetUrl(); ?>/tabBox.css" />

<?php if ($this->getMode() != "EDIT" ) { ?>
<script type="text/javascript" src="<?php echo $this->getAssetUrl(); ?>/tabBox.js"></script>
<?php }?>

<?php if ($this->getMode() == "EDIT" ) { ?>
<style type="text/css">
.tabBoxItem {
  clear:both;
  padding-bottom:22px;
}
a.tabBoxItemTab span.editModeTabHint {
  display:none;
}    
a.tabBoxItemTab:hover span.editModeTabHint{
  display:block;
  height:auto;        
  background:#FFFAAE;
  font-size:11px;
  float:left;
  border:1px solid #222; 
  padding:1px;    
}    
</style>
<?php }?>




