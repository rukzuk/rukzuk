<?php namespace Dual\Render; ?>
#<?php echo $this->getId(); ?> .tabBox {
  padding-top: <?php $this->p('margintop'); ?>px;  
  padding-bottom: <?php $this->p('marginbottom'); ?>px;   
}
