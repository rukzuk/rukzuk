<?php namespace Dual\Render; ?>
<div class="isModule <?php $this->p('classtext'); ?>" id="<?php echo $this->getId(); ?>">
  <a class="download <?php $this->p('classlink'); ?>" href="<?php echo MediaDb::getUrl($this->get('download')); ?>"><?php $this->p('text'); ?></a>
  <?php $this->p('comment'); ?>
</div>
