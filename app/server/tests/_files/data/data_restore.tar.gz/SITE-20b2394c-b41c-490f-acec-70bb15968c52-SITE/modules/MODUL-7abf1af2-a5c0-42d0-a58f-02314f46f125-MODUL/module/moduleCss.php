<?php namespace Dual\Render; ?>
#<?php echo $this->getId(); ?> {
  margin:<?php $this->p('margintop'); ?>px <?php $this->p('marginright'); ?>px <?php $this->p('marginbottom'); ?>px <?php $this->p('marginleft'); ?>px;
  width: <?php echo $width; ?>;
  float: left;
}


#line<?php echo $this->getId(); ?> {
  width: 100%;
  height: 1px;
  margin:<?php $this->p('margintop'); ?>px 0 <?php $this->p('marginbottom'); ?>px 0;
  background-color: #D0D0D0;
  font-size:0;
  line-height: 0;
  padding: 0;
}

