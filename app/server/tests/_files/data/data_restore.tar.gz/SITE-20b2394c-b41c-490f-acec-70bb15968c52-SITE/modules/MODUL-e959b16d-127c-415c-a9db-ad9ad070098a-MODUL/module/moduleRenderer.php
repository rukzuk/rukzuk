<?php namespace Dual\Render; ?>
<?php
  global $unitwidth;

  // Innenabstand, Breite
  $paddingLeft            = $this->get('paddingleft');
  $paddingRight           = $this->get('paddingright');
  $containerInnerWidth    = $this->get('width');
  $containerPaddingStyle  = !empty($paddingLeft)  ? ' padding-left:'.$paddingLeft.'px;'   : null;
  $containerPaddingStyle .= !empty($paddingRight) ? ' padding-right:'.$paddingRight.'px;' : null;

  $imgwidth = $this->get('imgwidth');
  //Bildausrichtung
  if ($this->get('imgalign')== 'left') {
    $imagestyle='float:left;margin-right:'.$this->get('gap').'px;width:'.$imgwidth.'px;';
  } elseif ($this->get('imgalign')== 'right') {
    $imagestyle='float:right;margin-left:'.$this->get('gap').'px;width:'.$imgwidth.'px;';
  } else {
    $imagestyle='display:none;';
  }
  // Textverhalten
  if ($this->get('floatimg')== '1') {
    $textstyle = 'display:inline;';
  } else {
    $textwidth = $containerInnerWidth-$this->get('gap')-$this->get('imgwidth');
      $textstyle = "width:".$textwidth."px;display:block;float:right";
  }

  // Link (Url)
  $htmlbefore = '';
  $htmlafter  = '';
  if ($this->get('pagelink') ) {
    $linkIntern = $this->get('linkintern');
    $linkExtern = $this->get('linkextern');
    if (!empty($linkIntern)) {
      $page = Navigation::getNodeById($this->get('linkintern'));
      if ($page) {
        $htmlbefore = '<a href="'.$page['data']->get('url').'" target="'.$this->get('linktarget').'">';
        $htmlafter  = '</a>';
      }
    } elseif (!empty($linkExtern)) {
      $htmlbefore = '<a href="'.$this->get('linkextern').'" target="'.$this->get('linktarget').'">';
      $htmlafter  = '</a>';
    }

  // Link auf grossbildansicht
  } elseif($this->get('bigimg')) {

    $bigImgwidth = $this->get('bigimgwidth');
    empty($bigImgwidth) ? $bigImgwidth = $bigImgwidth : null;
    $imgUrl       = MediaDb::getImageUrl($this->get('imgsrc'),$bigImgwidth);
    $imgTarget   = $this->get('imglinktaget') == 'fancy' ?  :   'target="'.$this->get('imglinktaget').'"';
    $htmlbefore  = '<a href="'.$imgUrl.'?.jpg"'.$imgTarget.' id="img_'.$this->getId().'">';
    $htmlafter   = '</a>';
  }
?>
<div class="isModule" id="<?php echo $this->getId(); ?>" style="width: <?php echo $containerInnerWidth; ?>px;<?php echo $containerPaddingStyle?>">

  <div style="<?php echo $imagestyle; ?>">
    <?php echo $htmlbefore; ?><img src="<?php echo MediaDb::getImageUrl($this->get('imgsrc'),$imgwidth); ?>" alt="<?php $this->p('imagedesc'); ?>" border="0"><?php echo $htmlafter; ?>
    <?php if (trim($this->get('imagedesc'))) { ?>
      <p class="<?php $this->p('classimagedesc'); ?>"><?php $this->p('imagedesc'); ?></p>
    <?php } ?>

  </div>

  <!-- Text -->
  <div style="<?php echo $textstyle; ?>">
   <?php
       $classes = "";
       if ($this->get('classh1') != "") {
           $classes .= $this->get('classh1')."-h1 ";
       }
       if ($this->get('classh2') != "") {
           $classes .= $this->get('classh2')."-h2 ";
       }     
       if ($this->get('classp') != "") {
           $classes .= $this->get('classp')."-p ";
           $classes .= $this->get('classp')."-li ";
       } 
       if ($this->get('classlink') != "") {
           $classes .= $this->get('classlink')."-a ";
       }     
       if ($this->get('classlinkhover') != "") {
           $classes .= $this->get('classlinkhover')."-hover:hover ";
       }         
       $this->pEditable('text', 'div', 'class="'.$classes.'"');
   ?>      
      
  </div>

</div>


<?php if ($this->get('bigimg') && $this->get('imglinktaget')=='fancy') { ?>
<script type="text/javascript">
  $("a#img_<?php echo $this->getId(); ?>").fancybox({
    'hideOnContentClick': true
    ,'transitionIn'  :  'elastic'
    ,'transitionOut'  :  'elastic'
    ,'speedIn'    :  600
    ,'speedOut'    :  200
  });
</script>
<?php } ?>
