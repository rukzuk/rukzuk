<?php namespace Dual\Render; ?>
<?php
  global $unitwidth;

  // Innenabstand, Breite
  $paddingLeft            = $this->get('paddingleft');
  $paddingRight           = $this->get('paddingright');
  $containerInnerWidth    = $this->get('width');
  $containerPaddingStyle  = !empty($paddingLeft)  ? ' padding-left:'.$paddingLeft.'px;'   : null;
  $containerPaddingStyle .= !empty($paddingRight) ? ' padding-right:'.$paddingRight.'px;' : null;

  $imgwidth = $this->get('imgwidth');

  // Textverhalten
  $textwidth = $containerInnerWidth-$this->get('gap')-$this->get('imgwidth');
  $textstyle = "width:".$textwidth."px;display:block;float:right";
?>
<div class="isModule videoModule" id="<?php echo $this->getId(); ?>" style="width: <?php echo $containerInnerWidth; ?>px;<?php echo $containerPaddingStyle?>">
    
    <img src="<?php echo MediaDb::getImageUrl($this->get('imgsrc'),$imgwidth); ?>" alt="<?php $this->p('imagedesc'); ?>" border="0" class="videoImg"  rel="div.overlay<?php echo $this->getId(); ?>"/>
  <!-- Text -->

  <div style="<?php echo $textstyle; ?>">
      <h3 rel="div.overlay<?php echo $this->getId(); ?>"><?php $this->p('title'); ?></h3>
   <?php
       $classes = "";
       if ($this->get('classh1') != "") {
           $classes .= $this->get('classh1')."-h1 ";
       }
       if ($this->get('classh2') != "") {
           $classes .= $this->get('classh2')."-h2 ";
       }     
       if ($this->get('classp') != "") {
           $classes .= $this->get('classp')."-p ";
           $classes .= $this->get('classp')."-li ";
       } 
       if ($this->get('classlink') != "") {
           $classes .= $this->get('classlink')."-a ";
       }     
       if ($this->get('classlinkhover') != "") {
           $classes .= $this->get('classlinkhover')."-hover:hover ";
       }         
       $this->pEditable('text', 'div', 'class="'.$classes.'"');
       
       
       // Videogrosse
       $sDimensions = '';
       if($this->get('videoHeight')){
           $sDimensions .= "height:{$this->get('videoHeight')}px;";   
       }else{
           $sDimensions .= "height:300px;";   
       }
       if($this->get('videoWidth')){
           $sDimensions .= "width:{$this->get('videoWidth')}px;";   
       }else{
           $sDimensions .= "width:400px;";      
       }
   ?>    
  </div>
  <div class="overlay<?php echo $this->getId(); ?> overlay" style="<?php echo $sDimensions;?>">
      <a href="<?php echo $this->p('streamingURL');?>" class="videoLink">     
           <!-- some initial content so that player is not loaded upon page load --> 
                &nbsp;
      </a>    
  </div>
</div>
