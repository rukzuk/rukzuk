<?php namespace Dual\Render; ?>
<link rel="stylesheet" href="<?php echo $this->getAssetUrl(); ?>/css/themes/default/default.css" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php echo $this->getAssetUrl(); ?>/css/nivo-slider.css" type="text/css" media="screen" />
<script type="text/javascript" src="<?php echo $this->getAssetUrl(); ?>/js/jquery.nivo.slider.pack.js"></script>

<style type="text/css">
.slider-wrapper{
  float:left;
} 
</style>
