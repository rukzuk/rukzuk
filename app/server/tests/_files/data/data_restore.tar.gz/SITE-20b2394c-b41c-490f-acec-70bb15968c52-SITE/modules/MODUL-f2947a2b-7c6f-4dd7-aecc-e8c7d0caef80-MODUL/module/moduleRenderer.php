<?php namespace Dual\Render; ?>
<?php
  global $unitwidth;
  $tempwidth = $unitwidth;  
 
  $unitwidth = $this->get('width');
  
  if ($this->get('enablepadding') == 1) {
    $unitwidth = $unitwidth - $this->get('paddingleft') - $this->get('paddingright');
  }
  if ($this->get('enablemargin') == 1) {
    $unitwidth = $unitwidth - $this->get('marginleft') - $this->get('marginright');
  }
  if ($this->get('enableborder') == 1) {
    if ($this->get('borderleft') == 1) {
      $unitwidth = $unitwidth - $this->get('borderwidth');
    }  
    if ($this->get('borderright') == 1) {
      $unitwidth = $unitwidth - $this->get('borderwidth');
    } 
  }
?>
<div class="isModule roundedTrick" data-cms-autowidth="true" id="<?php echo $this->getId(); ?>"> 
<div class="rTtopleft">
<div class="rTtopright">
<div class="rTbottonright">
<div class="rTbottomleft">
<div class="rTtopleftOverlap">
  <?php 
    $this->renderChilds(); 
  ?>
</div>
</div>
</div>
</div>
</div>
</div>


<?php
  $unitwidth = $tempwidth;
?>


