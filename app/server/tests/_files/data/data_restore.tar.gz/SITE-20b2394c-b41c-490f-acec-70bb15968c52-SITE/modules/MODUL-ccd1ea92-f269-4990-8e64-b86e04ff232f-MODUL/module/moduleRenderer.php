<?php namespace Dual\Render; ?>
<?php
  global $unitwidth;
  $elementwidth = $unitwidth;
?>

<div class="isModule" id="<?php echo $this->getId(); ?>" style="clear:both;width: <?php echo $elementwidth; ?>px; margin-top:<?php $this->p('mtop'); ?>px;margin-bottom:<?php $this->p('mbottom'); ?>px">
  <div class="twittermultyplugin" style="overflow:hidden;">
    <?php
      if ( $this->get('type') == 1 ) {
        //Tweet Button
        $url = ( $this->get('tweet_url') ) ? 'data-url='.$this->get('tweet_url') : '';
        $text = ( $this->get('tweet_text') ) ? 'data-text='.$this->get('tweet_text') : '';
        echo '<a href="http://twitter.com/share" class="twitter-share-button" 
          '.$url.' 
          '.$text.'
          data-count="'.$this->get('tweet_view').'" 
          data-lang="de">Tweet</a>
          <script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>';
        
      } elseif ( $this->get('type') == 2 ) {
        //Profil Widget
        $user = ( $this->get('tprofil_name') ) ? ".setUser('".$this->get('tprofil_name')."')" : '';
        $type = "profile";
        $search = '';
        $titel = '';
        $headline = '';
      } elseif ( $this->get('type') == 3 ) {
        //Such Widget
        $user = '';
        $type = "search";
        $search = ( $this->get('tsearch_suche') ) ? "search: '".$this->get('tsearch_suche')."'," : '';
        $titel = ( $this->get('tsearch_titel') ) ? "title: '".$this->get('tsearch_titel')."'," : '';
        $headline = ( $this->get('tsearch_headline') ) ? "subject: '".$this->get('tsearch_headline')."'," : '';
      } elseif ( $this->get('type') == 4 ) {
        //Listen Widget
        $user = ( $this->get('tlist_name') && $this->get('tlist_list') ) ? ".setList('".$this->get('tlist_name')."', '".$this->get('tlist_list')."')" : '';
        $type = "list";
        $search = '';
        $titel = ( $this->get('tlist_titel') ) ? "title: '".$this->get('tlist_titel')."'," : '';
        $headline = ( $this->get('tlist_headline') ) ? "subject: '".$this->get('tlist_headline')."'," : '';
      } elseif ( RenderContext::MODE_EDIT == $this->getMode() ) {
        echo 'noch kein Plugin gewählt';
      }
      
      if ( $this->get('type') >= 2 && $this->get('type') <= 4 ) {
        //Widgetfarben
        $cb= ( $this->get('widgetcolor_border') ) ? $this->get('widgetcolor_border') : '#8ec1da';
        $cbt= ( $this->get('widgetcolor_bordertext') ) ? $this->get('widgetcolor_bordertext') : '#ffffff';
        $ctb= ( $this->get('widgetcolor_tweetbackground') ) ? $this->get('widgetcolor_tweetbackground') : '#ffffff';
        $ctt= ( $this->get('widgetcolor_tweettext') ) ? $this->get('widgetcolor_tweettext') : '#444444';
        $cl= ( $this->get('widgetcolor_link') ) ? $this->get('widgetcolor_link') : '#1985b5';
        
        //Widgetoptionen
        $wnewer=( $this->get('widget_newer') == 1 ) ? 'true' : 'false';
        $wavatar=( $this->get('widget_avatar') == 1 ) ? 'true' : 'false';
        
        //Listenausgabe
        echo "<script>
          new TWTR.Widget({
          version: 2,
          type: '".$type."',
          ".$search."
          ".$titel."
          ".$headline."
          rpp: ".$this->get('widget_tweetnum').",
          interval: 6000,
          width: '".($elementwidth)."',
          height: ".$this->get('wheight').",
          theme: {
          shell: {
          background: '".$cb."',
          color: '".$cbt."'
          },
          tweets: {
          background: '".$ctb."',
          color: '".$ctt."',
          links: '".$cl."'
          }
          },
          features: {
          scrollbar: true,
          loop: false,
          live: ".$wnewer.",
          hashtags: true,
          timestamp: true,
          avatars: ".$wavatar.",
          behavior: 'all'
          }
          }).render()".$user.".start();
          </script>";
      }
      
    ?>
  </div>  
</div>
