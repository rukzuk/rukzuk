<?php namespace Dual\Render; ?>
<?php
$minwidth = $this->get('width');

if ($minwidth == 0) {
  $minwidth = 'width:auto;'; 
} else {
  $minwidth = 'width:'.$minwidth.'px;';   
}
?>

#<?php echo $this->getId(); ?> .rTtopleftOverlap{
  <?php if ($this->get('enablepadding') == 1) { ?>
  padding-left: <?php $this->p('paddingleft'); ?>px;
  padding-right: <?php $this->p('paddingright'); ?>px;
  padding-top: <?php $this->p('paddingtop'); ?>px;
  padding-bottom: <?php $this->p('paddingbottom'); ?>px;
  min-height: <?php $this->p('minheight'); ?>px;
  <?php } ?>
  position: relative;
  overflow:hidden;

}
  
#<?php echo $this->getId(); ?> {  
  position:relative;
  <?php if ($this->get('floatright') == 1) {
   echo "float:right;";
  } else {
   echo "float:left;";
  } ?>
  display: block;  
  <?php
  echo "min-height: ".$this->get('minheight')."px;";
  echo $minwidth;
  ?>  
    
 
  <?php if ($this->get('enablemargin') == 1) { ?>
  margin-left: <?php $this->p('marginleft'); ?>px;
  margin-right: <?php $this->p('marginright'); ?>px;
  margin-top: <?php $this->p('margintop'); ?>px;
  margin-bottom: <?php $this->p('marginbottom'); ?>px;
  <?php } ?>

  <?php if ($this->get('enablecustomcss') == 1) { ?>
  <?php $this->p('customcss'); ?>
  <?php }?>

}
