<?php namespace Dual\Render; ?>
#<?php echo $this->getId(); ?> {
  margin-top:<?php $this->p('margintop'); ?>px;
  margin-bottom:<?php $this->p('marginbottom'); ?>px;
  width: <?php $this->p('width'); ?>px;
  float:left;
}
#<?php echo $this->getId(); ?> img {
  margin-top:3px;
}

