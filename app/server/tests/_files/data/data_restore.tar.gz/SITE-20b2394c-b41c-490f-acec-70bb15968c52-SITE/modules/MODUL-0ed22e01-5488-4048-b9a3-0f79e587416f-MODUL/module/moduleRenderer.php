<?php namespace Dual\Render; ?>
<div id="<?php echo $this->getId(); ?>" class="isModule tabBox" style="clear:both">
    <div class="tabBoxContents">
    <?php $this->renderChildren(); ?>
    </div>
</div>

