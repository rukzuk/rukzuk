<?php namespace Dual\Render; ?>
<?php
if ($this->get('width') == 0) {
  $width = "auto";
} else {
  $width = $this->get('width')."px"; 
} ?>

#<?php echo $this->getId(); ?> {
  margin:<?php $this->p('margintop'); ?>px <?php $this->p('marginright'); ?>px <?php $this->p('marginbottom'); ?>px <?php $this->p('marginleft'); ?>px;
  width: <?php echo $width; ?>;
  float: left;
}

