<?php namespace Dual\Render; ?>
#<?php echo $this->getId(); ?> {
    margin-top:<?php $this->p('margintop'); ?>px; 
    margin-bottom:<?php $this->p('marginbottom'); ?>px;
    width: 100%;
    text-align: center;
}
