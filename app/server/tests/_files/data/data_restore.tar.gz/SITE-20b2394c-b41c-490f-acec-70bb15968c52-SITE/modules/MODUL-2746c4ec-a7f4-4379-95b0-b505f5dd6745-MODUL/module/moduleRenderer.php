<?php namespace Dual\Render; ?>
<?php if ($this->getMode() == "EDIT" ) { ?>
<div class="isModule" id="<?php echo $this->getId(); ?>"></div>
<?php } ?>

  

