<?php namespace Dual\Render; ?>
<?php
$width = $this->get('width'); 

$widthspalte1 = $width*($this->get('widthspalte1')/100);
$widthspalte2 = $width - $widthspalte1;
?>

#<?php echo $this->getId(); ?> {
  margin:<?php $this->p('margintop'); ?>px <?php $this->p('marginright'); ?>px <?php $this->p('marginbottom'); ?>px <?php $this->p('marginleft'); ?>px;
  width: <?php echo $width; ?>px;
  float: left;
}
#<?php echo $this->getId(); ?> .spalte1 {
  width: <?php echo $widthspalte1; ?>px;  
  float: left;
  text-align: left;
}
#<?php echo $this->getId(); ?> .spalte2 {
  width: <?php echo $widthspalte2; ?>px; 
  float: left;
  text-align: right;
}

