<?php namespace Dual\Render; ?>
<?php
$parentUnit = $this->getParent();
$parentId = $parentUnit->getId();
$minwidth = $this->get('width');

if ($this->get('rotate') > 0) {
  $rad = $this->get('rotate') * 3.141592654 / 180;
} 
if ($minwidth == 0) {
  $minwidth = 'width:auto;'; 
} else {
  $minwidth = 'width:'.$minwidth.'px;';   
}
?>


  
#<?php echo $this->getId(); ?> {  
  position:relative;
  <?php if ($this->get('floatright') == 1) {
   echo "float:right;";
  } else {
   echo "float:left;";
  } ?>
  display: block;
  <?php if ($this->get('enableposition') == 1) { ?>
  left: <?php $this->p('left'); ?>px;
  top: <?php $this->p('top'); ?>px;
  <?php } ?>

   <?php if ($this->get('rotate') > 0) { ?>
  -webkit-transform: rotate(<?php echo $rad; ?>rad);
  -moz-transform: rotate(<?php echo $rad; ?>rad);
  -o-transform: rotate(<?php echo $rad; ?>rad);
  <?php } ?>
  
  <?php
  echo "min-height: ".$this->get('minheight')."px;";
  echo $minwidth;
  ?>      
    
  <?php if ($this->get('enablebgcolor') == 1) { 
  if ($this->get('bgcolorschema') != "") {
    $color = CurrentSite::getColorById($this->get('bgcolorschema'));
  } else {
    $color = $this->get('bgcoloralpha');
  }
  /* IE Fallback mit solider Farbe */
  $solidcolor = preg_replace('/rgba\(([0-9]*),([0-9]*),([0-9]*),([0-9\.]*)\)/','rgb($1,$2,$3)',$color);
  echo "background: ".$solidcolor.";"; 
  echo "background: ".$color.";";     
  } ?>

  <?php if ($this->get('enablepadding') == 1) { ?>
  padding-left: <?php $this->p('paddingleft'); ?>px;
  padding-right: <?php $this->p('paddingright'); ?>px;
  padding-top: <?php $this->p('paddingtop'); ?>px;
  padding-bottom: <?php $this->p('paddingbottom'); ?>px;
  <?php } ?>

  <?php if ($this->get('enablemargin') == 1) { ?>
  margin-left: <?php $this->p('marginleft'); ?>px;
  margin-right: <?php $this->p('marginright'); ?>px;
  margin-top: <?php $this->p('margintop'); ?>px;
  margin-bottom: <?php $this->p('marginbottom'); ?>px;
  <?php } ?>


  <?php if ($this->get('enableborder') == 1) { 
    if ($this->get('bordercolorschema') != "") {
      $color = CurrentSite::getColorById($this->get('bordercolorschema'));
    } else {
      $color = $this->get('bordercolor');
    } 
    $color = preg_replace('/rgba\(([0-9]*),([0-9]*),([0-9]*),([0-9\.]*)\)/','rgb($1,$2,$3)',$color);
    if ($this->get('borderleft') == 1) { ?>
    border-left: <?php $this->p('borderwidth'); ?>px <?php $this->p('borderstyle'); ?> <?php echo $color; ?>;
    <?php } ?>
    <?php if ($this->get('borderright') == 1) { ?>
    border-right: <?php $this->p('borderwidth'); ?>px <?php $this->p('borderstyle'); ?> <?php echo $color; ?>;
   <?php } ?>
    <?php if ($this->get('bordertop') == 1) { ?>
    border-top: <?php $this->p('borderwidth'); ?>px <?php $this->p('borderstyle'); ?> <?php echo $color; ?>;
   <?php } ?>
    <?php if ($this->get('borderbottom') == 1) { ?>
    border-bottom: <?php $this->p('borderwidth'); ?>px <?php $this->p('borderstyle'); ?> <?php echo $color; ?>;
   <?php } ?>
  <?php } ?>

  <?php if ($this->get('enablegradient') == 1) {
  if ($this->get('gradientcolor1schema') != "") {
    $startcolor = CurrentSite::getColorById($this->get('gradientcolor1schema'));
  } else {
    $startcolor = $this->get('gradientcolor1');
  }
  if ($this->get('gradientcolor2schema') != "") {
    $endcolor = CurrentSite::getColorById($this->get('gradientcolor2schema'));
  } else {
    $endcolor = $this->get('gradientcolor2');
  } 
  if ($this->get('gradientdirection') == 'horizontal') {
    $webkit = "left top, right top";
    $other = "left center";
  } else {
    $webkit = "left top, left bottom";
    $other = "center top";  
  }

  ?>
  background-image: -webkit-gradient(linear, <?php echo $webkit; ?>, from(<?php echo $startcolor; ?>), to(<?php echo $endcolor; ?>));
  background-image: -moz-linear-gradient(<?php echo $other; ?>, <?php echo $startcolor; ?>, <?php echo $endcolor; ?>);
  background-image: linear-gradient(<?php echo $other; ?>, <?php echo $startcolor; ?>, <?php echo $endcolor; ?>);
  -pie-background: linear-gradient(<?php echo $other; ?>, <?php echo $startcolor; ?>, <?php echo $endcolor; ?>);
  <?php } ?>

  <?php if ($this->get('showbgimage') == 1) { ?>
  background-image: url('<?php echo MediaDb::getImageUrl($this->get('bgimage')); ?>');
  background-repeat: <?php $this->p('bgrepeat'); ?>;
  background-color: <?php $this->p('bgcolor'); ?>;
  background-position: <?php $this->p('bgposx'); ?> <?php $this->p('bgposy'); ?>;
  <?php } ?>

  <?php if ($this->get('enableshadow') == 1) { 
  if ($this->get('shadowcolorschema') != "") {
    $color = CurrentSite::getColorById($this->get('shadowcolorschema'));
  } else {
    $color = $this->get('shadowcolor');
  } 
  ?>
  -webkit-box-shadow: <?php echo $color; ?> <?php $this->p('shadowoffsetx'); ?>px <?php $this->p('shadowoffsety'); ?>px <?php $this->p('shadowblur'); ?>px;
  -moz-box-shadow: <?php echo $color; ?> <?php $this->p('shadowoffsetx'); ?>px <?php $this->p('shadowoffsety'); ?>px <?php $this->p('shadowblur'); ?>px;
  box-shadow: <?php echo $color; ?> <?php $this->p('shadowoffsetx'); ?>px <?php $this->p('shadowoffsety'); ?>px <?php $this->p('shadowblur'); ?>px;    
  <?php } ?>

  <?php if ($this->get('enablecorners') == 1) { ?>
  border-radius: <?php $this->p('borderradius1'); ?>px <?php $this->p('borderradius2'); ?>px <?php $this->p('borderradius3'); ?>px <?php $this->p('borderradius4'); ?>px;
  -moz-border-radius: <?php $this->p('borderradius1'); ?>px <?php $this->p('borderradius2'); ?>px <?php $this->p('borderradius3'); ?>px <?php $this->p('borderradius4'); ?>px;
  -webkit-radius: <?php $this->p('borderradius1'); ?>px <?php $this->p('borderradius2'); ?>px <?php $this->p('borderradius3'); ?>px <?php $this->p('borderradius4'); ?>px;
  <?php } ?>

  <?php if ($this->get('enablecustomcss') == 1) { ?>
  <?php $this->p('customcss'); ?>
  <?php }

  // PIE.htc fuer ie6, ie7, und ie8 einfuegen, ween gradient, rounded corners oder shadows aktiviert
  if ($this->get('enableshadow') || $this->get('enablegradient') || $this->get('enablecorners')) {
      echo "behavior: url(".$this->getAssetUrl()."/PIE.htc);";
  } ?>

}
