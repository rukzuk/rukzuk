<?php namespace Dual\Render; ?>
#<?php echo $this->getId(); ?> {
  width: 100%;   
  white-space:nowrap;
    
}

#<?php echo $this->getId(); ?> img {
  border: 0;
  display: block;
  float:left;
}
#<?php echo $this->getId(); ?> a {
  float: left;   
}
#<?php echo $this->getId(); ?> a .hover {
    display: none;
}
#<?php echo $this->getId(); ?> a:hover .hover {
    display: inline;
}
#<?php echo $this->getId(); ?> a:hover .standard{
    display: none;
}
#<?php echo $this->getId(); ?> a:hover .selected{
    display: none;
}
