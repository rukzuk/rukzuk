<?php namespace Dual\Render; ?>
<?php
  // Layout
  $padding_left   = $this->get('padding_left');
  $padding_right  = $this->get('padding_right');
  $padding_top    = $this->get('padding_top');
  $padding_bottom = $this->get('padding_bottom');
  
  $calcWidth      = $this->get('width')-$padding_left-$padding_right;
  $calcHeight     = $this->get('height')-$padding_top-$padding_bottom;
  
  // Images
  $galery = array();
  for($i=0;$i<10;$i++) {
    $var = sprintf('%02d',($i+1));
    //echo "<b>$var</b><br/>";
    $chk = $this->get('bild'.$var);
    $src = $this->get('bildSrc'.$var);
    $t   = $this->get('bildtitle'.$var);
    if(!empty($chk) && !empty($src)) {
      $galery[] = array('src'=>MediaDb::getImageUrl($src, $calcWidth),'title'=>$t);
    }
  }
  
  /*height:< ? php echo $calcHeight ? >px;*/
 ?>
<div id="<?php echo $this->getId(); ?>" class="isModule isResizable autowidth slider-wrapper theme-default">
    <div class="ribbon"></div>
    <div id="<?php echo $this->getId(); ?>_slider" class="nivoSlider">
    <?php
      foreach($galery as & $I) {
      ?>
      <img src="<?php echo $I['src']?>" alt="" title="<?php echo $I['title']?>" />
      <?php
      }
    ?>
    </div>
</div>


<script type="text/javascript"> 
  $('#<?php echo $this->getId(); ?>_slider').nivoSlider({
   effect:'<?php echo $this->get('slide_effect')?>'
  });
</script>
