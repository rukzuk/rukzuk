<?php namespace Dual\Render; ?>
#<?php echo $this->getId(); ?> {
  margin-top: <?php $this->p('margintop'); ?>px;
  margin-bottom: <?php $this->p('marginbottom'); ?>px;
  margin-left: <?php $this->p('marginleft'); ?>px;
  margin-right: <?php $this->p('marginright'); ?>px;
  float: left;
}
