<?php namespace Dual\Render; ?>
<?php
$style = "";
/* CSS-Definition in $style speichern */
if ($this->get('enableFontfamily')) {
  /*if ($this->get('webfont') != 'none') {
    $style.= "font-family:".$this->get('webfont').";";
  } else {*/
    $style.= "font-family:".$this->get('font').";";
  /*} */
} 
if ($this->get('enableColor')) {
  if ($this->get('colorschema') != "") {
    $color = CurrentSite::getColorById($this->get('colorschema'));
  } else {
    $color = $this->get('coloralpha');
  }
  /* IE Fallback mit solider Farbe */
  $solidcolor = preg_replace('/rgba\(([0-9]*),([0-9]*),([0-9]*),([0-9\.]*)\)/','rgb($1,$2,$3)',$color);
  /*$style.= "color: ".$color.";";   */
  $style.= "color: ".$solidcolor.";";


} 
if ($this->get('enableBgimage')) {
  $style.= "background-image: url('".MediaDb::getImageUrl($this->get('bgimage'))."');";
  $style.= "background-repeat: ".$this->get('bgrepeat').";";
  $style.= "background-position: ".$this->get('bgposx')." ".$this->get('bgposy').";";
}

if ($this->get('enableBgcolor') == 1) {
    if ($this->get('bgcolorschema') != "") {
      $style.= "background-color: ".CurrentSite::getColorById($this->get('bgcolorschema')).";";
    } else {
      $style.= "background-color: ".$this->get('bgcoloralpha').";";
    }
}


if ($this->get('enablegradient') == 1) { 
  if ($this->get('gradientcolor1schema') != "") {
    $startcolor = CurrentSite::getColorById($this->get('gradientcolor1schema'));
  } else {
    $startcolor = $this->get('gradientcolor1');
  }
  if ($this->get('gradientcolor2schema') != "") {
    $endcolor = CurrentSite::getColorById($this->get('gradientcolor2schema'));
  } else {
    $endcolor = $this->get('gradientcolor2');
  }  

  if ($this->get('gradientdirection') == 'horizontal') {
    $webkit = "left top, right top";
    $other = "left center";
  } else {
    $webkit = "left top, left bottom";
    $other = "center top";  
  }

  $style.= "background-image: -webkit-gradient(linear, ".$webkit.", from(".$startcolor."), to(".$endcolor."));";
  $style.= "background-image: -moz-linear-gradient(".$other.", ".$startcolor.", ".$endcolor.");";
  $style.= "background-image: linear-gradient(".$other.", ".$startcolor.", ".$endcolor.");";
  $style.= "-pie-background: linear-gradient(".$other.", ".$startcolor.", ".$endcolor.");";

} 

if ($this->get('enableshadow') == 1) {
  if ($this->get('shadowcolorschema') != "") {
    $color = CurrentSite::getColorById($this->get('shadowcolorschema'));
  } else {
    $color = $this->get('shadowcolor');
  } 
  $style.= "-webkit-box-shadow: ".$color." ".$this->get('shadowoffsetx')."px ".$this->get('shadowoffsety')."px ".$this->get('shadowblur')."px;";
  $style.= "-moz-box-shadow: ".$color." ".$this->get('shadowoffsetx')."px ".$this->get('shadowoffsety')."px ".$this->get('shadowblur')."px;";
  $style.= "box-shadow: ".$color." ".$this->get('shadowoffsetx')."px ".$this->get('shadowoffsety')."px ".$this->get('shadowblur')."px;";
}

if ($this->get('enablecorners') == 1) { 
  $style.= "border-radius: ".$this->get('borderradius1')."px ".$this->get('borderradius2')."px ".$this->get('borderradius3')."px ".$this->get('borderradius4')."px;";
  $style.= "-moz-border-radius: ".$this->get('borderradius1')."px ".$this->get('borderradius2')."px ".$this->get('borderradius3')."px ".$this->get('borderradius4')."px;";
  $style.= "-webkit-radius: ".$this->get('borderradius1')."px ".$this->get('borderradius2')."px ".$this->get('borderradius3')."px ".$this->get('borderradius4')."px;";
}

if ($this->get('enableFontsize')) {
  $style.= "font-size:".$this->get('fontsize')."px;";
} 
if ($this->get('enableLineheight')) {
  $style.= "line-height:".$this->get('lineheight')."%;";
}

if ($this->get('enableBlock')) {
  $style.= "display:block;";
  $style.= "text-align:".$this->get('textalign').";";
  $style.= "min-height:".$this->get('height')."px;";
  $style.= "min-width:".$this->get('width')."px;";
  if ($this->get('enableFloat') == 1) {
    $style.= "float: left;";
  }
}

if ($this->get('enableBold')) {
  if ($this->get('bold') == 1) {
    $style.= "font-weight:bold;";
  } else {
    $style.= "font-weight:normal;";
  }
  if ($this->get('italic')) {
    $style.= "font-style:italic;";
  } else {
    $style.= "font-style:normal;";
  }
  if ($this->get('underline')) {
    $style.= "text-decoration:underline;";
  } else {
    $style.= "text-decoration:none;";
  }
}

if ($this->get('enableborder')) { 
  
  if ($this->get('bordercolorschema') != "") {
    $bordercolor = CurrentSite::getColorById($this->get('bordercolorschema'));
  } else {
    $bordercolor = $this->get('bordercoloralpha');
  }  
  $bordercolor= preg_replace('/rgba\(([0-9]*),([0-9]*),([0-9]*),([0-9\.]*)\)/','rgb($1,$2,$3)',$bordercolor);
  if ($this->get('borderleft') == 1) { 
    $style.= "border-left: ".$this->get('borderwidth')."px ".$this->get('borderstyle')." ".$bordercolor.";";
  }
  if ($this->get('borderright') == 1) { 
    $style.= "border-right: ".$this->get('borderwidth')."px ".$this->get('borderstyle')." ".$bordercolor.";";
  } 
  if ($this->get('bordertop') == 1) {
    $style.= "border-top: ".$this->get('borderwidth')."px ".$this->get('borderstyle')." ".$bordercolor.";";
  }
  if ($this->get('borderbottom') == 1) {
    $style.= "border-bottom: ".$this->get('borderwidth')."px ".$this->get('borderstyle')." ".$bordercolor.";";
  } 
} 

if ($this->get('enablepadding')) { 
  $style.= "padding-left: ".$this->get('paddingleft')."px;";
  $style.= "padding-right: ".$this->get('paddingright')."px;";
  $style.= "padding-top: ".$this->get('paddingtop')."px;";
  $style.= "padding-bottom: ".$this->get('paddingbottom')."px;";
}

if ($this->get('enablemargin')) { 
  $style.= "margin-left: ".$this->get('marginleft')."px;";
  $style.= "margin-right: ".$this->get('marginright')."px;";
  $style.= "margin-top: ".$this->get('margintop')."px;";
  $style.= "margin-bottom: ".$this->get('marginbottom')."px;";
}

if ($this->get('enableCss')) {
  $style.= $this->get('css');
}

// PIE.htc fuer ie6, ie7, und ie8 einfuegen, ween gradient, rounded corners oder shadows aktiviert
if ($this->get('enableshadow') || $this->get('enablegradient') || $this->get('enablecorners')) {
    $style .= "behavior: url(".$this->getAssetUrl()."/PIE.htc);";
}

/* jetzt im globalen Styles-Array speichern */
global $cmsStyles;
$cmsStyles[$this->getTemplateUnitId()] = $style;

/* style ausgeben mit der id dieser Unit */
echo ".".$this->getTemplateUnitId().", .".$this->getTemplateUnitId()."-hover a:hover, .".$this->getTemplateUnitId()."-h1 h1, .".$this->getTemplateUnitId()."-hover2 *:hover, ";
echo ".".$this->getTemplateUnitId()."-h2 h2, .".$this->getTemplateUnitId()."-a a, .".$this->getTemplateUnitId()."-p p, .".$this->getTemplateUnitId()."-li li {".$style."}";
?>

