<?php namespace Dual\Render; ?>
<?php
if ($this->get('width') == 0) {
  $width = "width:auto;_width:1px;";
} else {
  $width = "width:".$this->get('width')."px;";
} ?>

#<?php echo $this->getId(); ?> {
  margin:<?php $this->p('margintop'); ?>px <?php $this->p('marginright'); ?>px <?php $this->p('marginbottom'); ?>px <?php $this->p('marginleft'); ?>px;
  float:<?php $this->p('float'); ?>;
  <?php if ($this->get('clear') == 1) {
    echo "clear:both;";
  } ?>
}
#<?php echo $this->getId(); ?> a {
  display:block; 
  <?php echo $width; ?>
  white-space:nowrap;
}

