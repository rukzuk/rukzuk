<?php namespace Dual\Render; ?>
<script type="text/javascript" src="<?php echo $this->getAssetUrl(); ?>/flowplayer-3.2.6.min.js"></script>
<script type="text/javascript" src="<?php echo $this->getAssetUrl(); ?>/jquery.tools.min.js"></script>
<style>
    div.videoModule h3{
        font-size:14px;
        cursor:pointer;
    }
    div.videoModule img.videoImg{
        cursor:pointer;
    }
    div.videoModule img{
        float:left;
    }
    .overlay {
        padding:40px;
        width:576px;
        display:none;
        background-image:url(http://static.flowplayer.org/img/overlay/white.png);
    }
    
    .close {
        background:url(http://static.flowplayer.org/img/overlay/close.png) no-repeat;
        position:absolute;
        top:2px;
        right:5px;
        display:block;
        width:35px;
        height:35px;
        cursor:pointer;
    }
    
    #player {
        height:450px;
        display:block;
    }    
</style>
<script type="text/javascript">
jQuery(function($) {
    $('div.videoModule').each(function(){
    var $videoURL   = $('a.videoLink',this);
    var $videoTitle = $('h3',this);
    var $videoImg   = $('img.videoImg',this);
    var SWFPath     =  '<?php echo $this->getAssetUrl(); ?>/flowplayer-3.2.7-T.swf';
    var player = $f($videoURL[0], SWFPath,{'width':'800px','height':'600px'});
    // setup button action. it will fire our overlay
    var options ={
        effect: 'apple',    
        onLoad: function() {
            player.load();
        },
        onClose: function() {
            player.unload();
        }
    };
    $videoTitle.overlay(options);
    $videoImg.overlay(options);

       return;


        /******************************
       return;
       var $videoURL   = $('a.videoLink',this);

       var $videoTitle = $('h3',this);
       var SWFPath     =  '<?php echo $this->getAssetUrl(); ?>/flowplayer-3.2.7-T.swf';
       // playerinstance
       $f($videoURL[0], SWFPath, {
           clip: {
               // use first frame of the clip as a splash screen
               autoPlay: true
           }
       });

       // bind click on title
       $videoTitle.click(function(){
           $f().play($videoURL.attr('href'));
       });
       ***************/
     });
});
</script>
