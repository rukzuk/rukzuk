<?php namespace Dual\Render; ?>
#<?php echo $this->getId(); ?> .navlist{
  margin: 0;
  padding: 0;
}

#<?php echo $this->getId(); ?> .navitem {
  display: block;
  margin: 0;
  padding: 0;
  float: <?php $this->p('navfloat'); ?>;
  list-style-type: none;
  text-align: <?php $this->p('textalign'); ?>;
}

#<?php echo $this->getId(); ?> .navitem a, #<?php echo $this->getId(); ?> .navitem a:link {
  display: block;
  text-decoration: none;
  
  <?php if ($this->get('enablebgcolor') == 1) { ?>
  background-color: <?php $this->p('bgcolor'); ?>;
  <?php } ?>

  <?php if ($this->get('enablefont') == 1) { ?>
  font-family: <?php $this->p('fontfamily'); ?>;
  color: <?php $this->p('fontcolor'); ?>;
  font-size: <?php $this->p('fontsize'); ?>;
  font-weight: <?php $this->p('bold'); ?>;
  <?php } ?>

  <?php if ($this->get('enablemargin') == 1) { ?>
  margin-left: <?php $this->p('marginleft'); ?>px;
  margin-right: <?php $this->p('marginright'); ?>px;
  margin-top: <?php $this->p('margintop'); ?>px;
  margin-bottom: <?php $this->p('marginbottom'); ?>px;
  <?php } ?>

  <?php if ($this->get('enablepadding') == 1) { ?>
  padding-left: <?php $this->p('paddingleft'); ?>px;
  padding-right: <?php $this->p('paddingright'); ?>px;
  padding-top: <?php $this->p('paddingtop'); ?>px;
  padding-bottom: <?php $this->p('paddingbottom'); ?>px;
  <?php } ?>

  <?php if ($this->get('enableborderleft') == 1) { ?>
  border-left-width: <?php $this->p('borderwidthleft'); ?>px;
  border-left-color: <?php $this->p('bordercolorleft'); ?>;
  border-left-style: <?php $this->p('borderstyleleft'); ?>;
  <?php } ?>

  <?php if ($this->get('enableborderright') == 1) { ?>
  border-right-width: <?php $this->p('borderwidthright'); ?>px;
  border-right-color: <?php $this->p('bordercolorright'); ?>;
  border-right-style: <?php $this->p('borderstyleright'); ?>;
  <?php } ?>

  <?php if ($this->get('enablebordertop') == 1) { ?>
  border-top-width: <?php $this->p('borderwidthtop'); ?>px;
  border-top-color: <?php $this->p('bordercolortop'); ?>;
  border-top-style: <?php $this->p('borderstyletop'); ?>;
  <?php } ?>

  <?php if ($this->get('enableborderbottom') == 1) { ?>
  border-bottom-width: <?php $this->p('borderwidthbottom'); ?>px;
  border-bottom-color: <?php $this->p('bordercolorbottom'); ?>;
  border-bottom-style: <?php $this->p('borderstylebottom'); ?>;
  <?php } ?>

  <?php if ($this->get('showbgimage') == 1) { ?>
  background-image: url('<?php echo MediaDb::getImageUrl($this->get('bgimage')); ?>');
  background-repeat: <?php $this->p('bgrepeat'); ?>;
  background-color: <?php $this->p('bgcolor'); ?>;
  background-position: <?php $this->p('bgposition'); ?>;
  <?php } ?>

  <?php if ($this->get('enablecorners') == 1) { ?>
  border-radius: <?php $this->p('borderradius'); ?>px;
  -moz-border-radius: <?php $this->p('borderradius'); ?>px;
  -webkit-radius: <?php $this->p('borderradius'); ?>px;
  <?php } ?>

  <?php if ($this->get('enablecustomcss') == 1) { ?>
  <?php $this->p('customcss'); ?>
  <?php } ?>
}

#<?php echo $this->getId(); ?> .navitem a:hover {
  display: block;
  text-decoration: none;
  
  <?php if ($this->get('enablebgcolorHover') == 1) { ?>
  background-color: <?php $this->p('bgcolorHover'); ?>;
  <?php } ?>

  <?php if ($this->get('enablefontHover') == 1) { ?>
  font-family: <?php $this->p('fontfamilyHover'); ?>;
  color: <?php $this->p('fontcolorHover'); ?>;
  font-size: <?php $this->p('fontsizeHover'); ?>;
  font-weight: <?php $this->p('boldHover'); ?>;
  <?php } ?>

  <?php if ($this->get('enablemarginHover') == 1) { ?>
  margin-left: <?php $this->p('marginleftHover'); ?>px;
  margin-right: <?php $this->p('marginrightHover'); ?>px;
  margin-top: <?php $this->p('margintopHover'); ?>px;
  margin-bottom: <?php $this->p('marginbottomHover'); ?>px;
  <?php } ?>

  <?php if ($this->get('enablepaddingHover') == 1) { ?>
  padding-left: <?php $this->p('paddingleftHover'); ?>px;
  padding-right: <?php $this->p('paddingrightHover'); ?>px;
  padding-top: <?php $this->p('paddingtopHover'); ?>px;
  padding-bottom: <?php $this->p('paddingbottomHover'); ?>px;
  <?php } ?>

  <?php if ($this->get('enableborderleftHover') == 1) { ?>
  border-left-width: <?php $this->p('borderwidthleftHover'); ?>px;
  border-left-color: <?php $this->p('bordercolorleftHover'); ?>;
  border-left-style: <?php $this->p('borderstyleleftHover'); ?>;
  <?php } ?>

  <?php if ($this->get('enableborderrightHover') == 1) { ?>
  border-right-width: <?php $this->p('borderwidthrightHover'); ?>px;
  border-right-color: <?php $this->p('bordercolorrightHover'); ?>;
  border-right-style: <?php $this->p('borderstylerightHover'); ?>;
  <?php } ?>

  <?php if ($this->get('enablebordertopHover') == 1) { ?>
  border-top-width: <?php $this->p('borderwidthtopHover'); ?>px;
  border-top-color: <?php $this->p('bordercolortopHover'); ?>;
  border-top-style: <?php $this->p('borderstyletopHover'); ?>;
  <?php } ?>

  <?php if ($this->get('enableborderbottomHover') == 1) { ?>
  border-bottom-width: <?php $this->p('borderwidthbottomHover'); ?>px;
  border-bottom-color: <?php $this->p('bordercolorbottomHover'); ?>;
  border-bottom-style: <?php $this->p('borderstylebottomHover'); ?>;
  <?php } ?>

  <?php if ($this->get('showbgimageHover') == 1) { ?>
  background-image: url('<?php echo MediaDb::getImageUrl($this->get('bgimageHover')); ?>');
  background-repeat: <?php $this->p('bgrepeatHover'); ?>;
  background-color: <?php $this->p('bgcolorHover'); ?>;
  background-position: <?php $this->p('bgpositionHover'); ?>;
  <?php } ?>

  <?php if ($this->get('enablecornersHover') == 1) { ?>
  border-radius: <?php $this->p('borderradiusHover'); ?>px;
  -moz-border-radius: <?php $this->p('borderradiusHover'); ?>px;
  -webkit-radius: <?php $this->p('borderradiusHover'); ?>px;
  <?php } ?>

  <?php if ($this->get('enablecustomcssHover') == 1) { ?>
  <?php $this->p('customcssHover'); ?>
  <?php } ?>
}

#<?php echo $this->getId(); ?> .navselected a {
  display: block;
  text-decoration: none;
  
  <?php if ($this->get('enablebgcolorSelected') == 1) { ?>
  background-color: <?php $this->p('bgcolorSelected'); ?>;
  <?php } ?>

  <?php if ($this->get('enablefontSelected') == 1) { ?>
  font-family: <?php $this->p('fontfamilySelected'); ?>;
  color: <?php $this->p('fontcolorSelected'); ?>;
  font-size: <?php $this->p('fontsizeSelected'); ?>;
  font-weight: <?php $this->p('boldSelected'); ?>;
  <?php } ?>

  <?php if ($this->get('enablemarginSelected') == 1) { ?>
  margin-left: <?php $this->p('marginleftSelected'); ?>px;
  margin-right: <?php $this->p('marginrightSelected'); ?>px;
  margin-top: <?php $this->p('margintopSelected'); ?>px;
  margin-bottom: <?php $this->p('marginbottomSelected'); ?>px;
  <?php } ?>

  <?php if ($this->get('enablepaddingSelected') == 1) { ?>
  padding-left: <?php $this->p('paddingleftSelected'); ?>px;
  padding-right: <?php $this->p('paddingrightSelected'); ?>px;
  padding-top: <?php $this->p('paddingtopSelected'); ?>px;
  padding-bottom: <?php $this->p('paddingbottomSelected'); ?>px;
  <?php } ?>

  <?php if ($this->get('enableborderleftSelected') == 1) { ?>
  border-left-width: <?php $this->p('borderwidthleftSelected'); ?>px;
  border-left-color: <?php $this->p('bordercolorleftSelected'); ?>;
  border-left-style: <?php $this->p('borderstyleleftSelected'); ?>;
  <?php } ?>

  <?php if ($this->get('enableborderrightSelected') == 1) { ?>
  border-right-width: <?php $this->p('borderwidthrightSelected'); ?>px;
  border-right-color: <?php $this->p('bordercolorrightSelected'); ?>;
  border-right-style: <?php $this->p('borderstylerightSelected'); ?>;
  <?php } ?>

  <?php if ($this->get('enablebordertopSelected') == 1) { ?>
  border-top-width: <?php $this->p('borderwidthtopSelected'); ?>px;
  border-top-color: <?php $this->p('bordercolortopSelected'); ?>;
  border-top-style: <?php $this->p('borderstyletopSelected'); ?>;
  <?php } ?>

  <?php if ($this->get('enableborderbottomSelected') == 1) { ?>
  border-bottom-width: <?php $this->p('borderwidthbottomSelected'); ?>px;
  border-bottom-color: <?php $this->p('bordercolorbottomSelected'); ?>;
  border-bottom-style: <?php $this->p('borderstylebottomSelected'); ?>;
  <?php } ?>

  <?php if ($this->get('showbgimageSelected') == 1) { ?>
  background-image: url('<?php echo MediaDb::getImageUrl($this->get('bgimageSelected')); ?>');
  background-repeat: <?php $this->p('bgrepeaSelectedt'); ?>;
  background-color: <?php $this->p('bgcolorSelected'); ?>;
  background-position: <?php $this->p('bgpositionSelected'); ?>;
  <?php } ?>

  <?php if ($this->get('enablecornersSelected') == 1) { ?>
  border-radius: <?php $this->p('borderradiusSelected'); ?>px;
  -moz-border-radius: <?php $this->p('borderradiusSelected'); ?>px;
  -webkit-radius: <?php $this->p('borderradiusSelected'); ?>px;
  <?php } ?>

  <?php if ($this->get('enablecustomcssSelected') == 1) { ?>
  <?php $this->p('customcssSelected'); ?>
  <?php } ?>
}
