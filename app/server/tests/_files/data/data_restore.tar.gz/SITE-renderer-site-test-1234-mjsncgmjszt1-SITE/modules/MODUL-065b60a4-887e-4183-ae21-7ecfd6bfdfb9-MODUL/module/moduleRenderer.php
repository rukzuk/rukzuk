<?php namespace Dual\Render; ?>
<div class="isModule" id="<?php echo $this->getId(); ?>" style="margin-top:<?php $this->p('margintop'); ?>px; margin-bottom:<?php $this->p('marginbottom'); ?>px;clear:both">
  <?php $this->p('text'); ?>
</div>
<div style="clear:both"></div>