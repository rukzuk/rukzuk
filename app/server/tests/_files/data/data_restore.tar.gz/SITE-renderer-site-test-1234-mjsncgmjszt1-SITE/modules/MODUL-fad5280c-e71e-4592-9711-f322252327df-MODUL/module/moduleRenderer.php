<?php namespace Dual\Render; ?>
<?php
  global $unitwidth;
  $unitwidth= $this->get('containerwidth');
?>
<div style="width:100%" id="P<?php echo $this->getId(); ?>">
  <div style="width:<?php echo $unitwidth; ?>px; margin-left:auto;margin-right:auto" class="rahmen isModule" id="<?php echo $this->getId(); ?>">
    <?php $this->renderChilds(); ?>
  </div>
  <div style="clear:both"></div>
</div>
