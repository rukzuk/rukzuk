<?php namespace Dual\Render; ?>
<div class="isModule" id="<?php echo $this->getId(); ?>">
  <ul class="navlist">
    <?php
      global $unitwidth;
      $styleFirstItem = "";
      $styleLastItem = "";
      $navselected = "";
      $i=0;
      
      if ($this->get('enableTest') == 1) {
        $testitems = preg_split('/,/', $this->get('testitems'));
        
        /* Breite der Element automatisch berechen */
        if ($this->get('autowidth') == 1) {
          if ($this->get('navfloat') == 'left') {
            $styleFirstItem = "margin-left:0;border-left:none";
            $styleLastItem = "margin-right:0;border-right:none";
            $navwidth = $unitwidth/count($testitems);
            if ($this->get('enableborderright') == 1) {
              $navwidth = $navwidth - $this->get('borderwidthright') + $this->get('borderwidthright')/count($testitems);
            }
            if ($this->get('enablemargin') == 1) {
              $navwidth = $navwidth - $this->get('marginright') + $this->get('marginright')/count($testitems);
              $navwidth = $navwidth - $this->get('marginleft') + $this->get('marginleft')/count($testitems);
            }
            if ($this->get('enablepadding') == 1) {
              $navwidth = $navwidth - $this->get('paddingright');
              $navwidth = $navwidth - $this->get('paddingleft');
            }             
            $navwidth = $navwidth."px";
          } else {
            $styleFirstItem = "margin-top:0;border-top:none";
            $styleLastItem = "margin-bottom:0;border-bottom:none";            
            $navwidth = $unitwidth."px";
          }
        } else {
          $navwidth = 'auto';
        }
        
        
        foreach ($testitems as $page) {
          if ($i==0) {
            echo '<li class="navitem navselected"><a style="width:'.$navwidth.';'.$styleFirstItem.'" href="#">';
          } else {
            if ($i == (count($testitems)-1)) {
              echo '<li class="navitem"><a href="#" style="width:'.$navwidth.';'.$styleLastItem.'">';
            } else {
              echo '<li class="navitem"><a href="#" style="width:'.$navwidth.'">'; 
            }
          }
          echo $page.'</a></li>';
          $i++;
        }        
      } else {
        
        if ($this->get('navlevel') == 'first') {
          $navigation = Navigation::getChildren(Navigation::ROOT);
        } else {
          
          $navigator = Navigation::getNavigator();
          if (count($navigator) == 1) {
            $navigation = Navigation::getChildren(Navigation::CURRENT_PAGE);
          } else {
            $i=0;
            foreach ($navigator as $page) {
              if ($i == 0) {
                $navigation = Navigation::getChildren($page['id']);
              }
              $i++;
            }
      
          }
        }
        
        /* Breite der Element automatisch berechen */
        if ($this->get('autowidth') == 1) {
          if ($this->get('navfloat') == 'left') {
            $styleFirstItem = "margin-left:0;border-left:none";
            $styleLastItem = "margin-right:0;border-right:none";
            $navwidth = $unitwidth/count($navigation);
            if ($this->get('enableborderright') == 1) {
              $navwidth = $navwidth - $this->get('borderwidthright') + $this->get('borderwidthright')/count($navigation);
            }
            if ($this->get('enablemargin') == 1) {
              $navwidth = $navwidth - $this->get('marginright') + $this->get('marginright')/count($navigation);
              $navwidth = $navwidth - $this->get('marginleft') + $this->get('marginleft')/count($testitems);
            } 
            if ($this->get('enablepadding') == 1) {
              $navwidth = $navwidth - $this->get('paddingright');
              $navwidth = $navwidth - $this->get('paddingleft');
            }             
            $navwidth = $navwidth."px";
          } else {
            $styleFirstItem = "margin-top:0;border-top:none";
            $styleLastItem = "margin-bottom:0;border-bottom:none";            
            $navwidth = $unitwidth."px";
          }
        } else {
          $navwidth = 'auto';
        }        
        
        foreach ($navigation as $page) {
          if ($page['id'] == CurrentPage::get('id')) {
            $navselected = "navselected";
          } else {
            $navselected = ""; 
          }
          
          if ($i==0) {
            echo '<li class="navitem '.$navselected.'"><a style="width:'.$navwidth.';'.$styleFirstItem.'" href="'.$page['data']->get('url').'">';
          } else {
            if ($i == (count($navigation)-1)) {
              echo '<li class="navitem '.$navselected.'"><a href="'.$page['data']->get('url').'" style="width:'.$navwidth.';'.$styleLastItem.'">';
            } else {
              echo '<li class="navitem '.$navselected.'"><a href="'.$page['data']->get('url').'" style="width:'.$navwidth.'">';
            }
          }
          echo $page['data']->getNavigationTitle().'</a></li>';
          $i++;          
          
        }
      }
      ?>
  </ul>
  <br style="clear:both" />
</div>