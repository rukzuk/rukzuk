<?php namespace Dual\Render; ?>
