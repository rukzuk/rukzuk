<?php
namespace Rukzuk\Modules;

use \Render\ModuleInterface;

class rz_module_no_1_with_export_version_1_5_0_import implements ModuleInterface
{
  public function provideModuleData($api, $moduleInfo) {}
  public function provideUnitData($api, $unit, $moduleInfo) {}
  public function render($renderApi, $unit, $moduleInfo) {}
  public function css($cssApi, $unit, $moduleInfo) {}
}
